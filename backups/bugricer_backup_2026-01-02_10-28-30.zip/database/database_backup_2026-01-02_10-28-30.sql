-- BugRicer Database Backup
-- Generated: 2026-01-02 10:28:30
-- Database: u262074081_bugfixer_db

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

START TRANSACTION;


-- Table structure for table `activities`
DROP TABLE IF EXISTS `activities`;
CREATE TABLE `activities` (
  `id` varchar(36) NOT NULL,
  `type` varchar(50) NOT NULL,
  `entity_id` varchar(36) NOT NULL,
  `user_id` varchar(36) NOT NULL,
  `action` varchar(255) NOT NULL,
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`details`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `idx_activities_user_type` (`user_id`,`type`),
  KEY `idx_activities_created_at` (`created_at`),
  KEY `idx_activities_user_dashboard` (`user_id`,`type`,`created_at`),
  KEY `idx_activities_type_entity_id` (`type`,`entity_id`),
  CONSTRAINT `activities_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for table `activity_log`
DROP TABLE IF EXISTS `activity_log`;
CREATE TABLE `activity_log` (
  `id` varchar(36) NOT NULL,
  `user_id` varchar(36) NOT NULL,
  `action_type` varchar(50) NOT NULL,
  `entity_type` varchar(50) NOT NULL,
  `entity_id` varchar(36) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `idx_activity_log_user_action` (`user_id`,`action_type`),
  KEY `idx_activity_log_entity` (`entity_type`,`entity_id`),
  KEY `idx_activity_log_created_at` (`created_at`),
  CONSTRAINT `activity_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for table `admin_audit_log`
DROP TABLE IF EXISTS `admin_audit_log`;
CREATE TABLE `admin_audit_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` varchar(36) NOT NULL,
  `action` varchar(100) NOT NULL,
  `target_user_id` varchar(36) DEFAULT NULL,
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`details`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_admin_id` (`admin_id`),
  KEY `idx_action` (`action`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=169 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `admin_audit_log`
INSERT INTO `admin_audit_log` VALUES
('149','608dc9d1-26e0-441d-8144-45f74c53a846','generate_dashboard_link','d84019a3-575f-403c-aa12-02482422bcfa','{\"target_username\":\"developer\",\"target_role\":\"developer\",\"expires_at\":\"2025-11-09 16:39:07\"}','2025-11-02 22:09:07'),
('150','608dc9d1-26e0-441d-8144-45f74c53a846','generate_dashboard_link','d84019a3-575f-403c-aa12-02482422bcfa','{\"target_username\":\"developer\",\"target_role\":\"developer\",\"expires_at\":\"2025-11-09 16:48:06\"}','2025-11-02 22:18:06'),
('151','608dc9d1-26e0-441d-8144-45f74c53a846','generate_dashboard_link','c18ce191-e34b-4ca7-b69b-6a78488d3de5','{\"target_username\":\"tester\",\"target_role\":\"tester\",\"expires_at\":\"2025-11-09 16:48:25\"}','2025-11-02 22:18:25'),
('152','608dc9d1-26e0-441d-8144-45f74c53a846','generate_dashboard_link','d84019a3-575f-403c-aa12-02482422bcfa','{\"target_username\":\"developer\",\"target_role\":\"developer\",\"expires_at\":\"2025-11-09 17:25:32\"}','2025-11-02 22:55:32'),
('153','608dc9d1-26e0-441d-8144-45f74c53a846','generate_dashboard_link','d84019a3-575f-403c-aa12-02482422bcfa','{\"target_username\":\"developer\",\"target_role\":\"developer\",\"expires_at\":\"2025-11-09 18:28:19\"}','2025-11-02 23:58:19'),
('154','608dc9d1-26e0-441d-8144-45f74c53a846','generate_dashboard_link','c18ce191-e34b-4ca7-b69b-6a78488d3de5','{\"target_username\":\"tester\",\"target_role\":\"tester\",\"expires_at\":\"2025-11-09 18:28:28\"}','2025-11-02 23:58:28'),
('155','608dc9d1-26e0-441d-8144-45f74c53a846','generate_dashboard_link','e1e7aecc-96f9-452b-b60c-e9541c27ea3d','{\"target_username\":\"dev\",\"target_role\":\"developer\",\"expires_at\":\"2025-11-09 19:35:18\"}','2025-11-03 01:05:18'),
('156','608dc9d1-26e0-441d-8144-45f74c53a846','generate_dashboard_link','3045985b-50f9-44e5-9adf-bc6879945272','{\"target_username\":\"moajmalnk22\",\"target_role\":\"admin\",\"expires_at\":\"2025-11-10 05:28:46\"}','2025-11-03 10:58:46'),
('157','608dc9d1-26e0-441d-8144-45f74c53a846','generate_dashboard_link','608dc9d1-26e0-441d-8144-45f74c53a846','{\"target_username\":\"moajmalnk\",\"target_role\":\"admin\",\"expires_at\":\"2025-11-10 05:29:20\"}','2025-11-03 10:59:20'),
('158','608dc9d1-26e0-441d-8144-45f74c53a846','exit_impersonate_mode','3045985b-50f9-44e5-9adf-bc6879945272','{\"target_username\":\"moajmalnk22\",\"target_role\":\"admin\",\"exited_at\":\"2025-11-03 05:57:41\"}','2025-11-03 11:27:41'),
('159','608dc9d1-26e0-441d-8144-45f74c53a846','generate_dashboard_link','d84019a3-575f-403c-aa12-02482422bcfa','{\"target_username\":\"developer\",\"target_role\":\"developer\",\"expires_at\":\"2025-11-10 18:09:13\"}','2025-11-03 23:39:13'),
('160','608dc9d1-26e0-441d-8144-45f74c53a846','generate_dashboard_link','3045985b-50f9-44e5-9adf-bc6879945272','{\"target_username\":\"moajmalnk22\",\"target_role\":\"admin\",\"expires_at\":\"2025-11-10 19:49:22\"}','2025-11-04 01:19:23'),
('161','608dc9d1-26e0-441d-8144-45f74c53a846','generate_dashboard_link','3045985b-50f9-44e5-9adf-bc6879945272','{\"target_username\":\"moajmalnk22\",\"target_role\":\"admin\",\"expires_at\":\"2025-12-08 18:51:46\"}','2025-12-02 00:21:46'),
('162','608dc9d1-26e0-441d-8144-45f74c53a846','generate_dashboard_link','d84019a3-575f-403c-aa12-02482422bcfa','{\"target_username\":\"developer\",\"target_role\":\"developer\",\"expires_at\":\"2026-01-07 18:25:04\"}','2025-12-31 18:25:04'),
('163','608dc9d1-26e0-441d-8144-45f74c53a846','generate_dashboard_link','d84019a3-575f-403c-aa12-02482422bcfa','{\"target_username\":\"developer\",\"target_role\":\"developer\",\"expires_at\":\"2026-01-07 18:27:06\"}','2025-12-31 18:27:06'),
('164','608dc9d1-26e0-441d-8144-45f74c53a846','generate_dashboard_link','e1e7aecc-96f9-452b-b60c-e9541c27ea3d','{\"target_username\":\"dev\",\"target_role\":\"developer\",\"expires_at\":\"2026-01-09 00:28:17\"}','2026-01-02 00:28:17'),
('165','608dc9d1-26e0-441d-8144-45f74c53a846','generate_dashboard_link','c18ce191-e34b-4ca7-b69b-6a78488d3de5','{\"target_username\":\"tester\",\"target_role\":\"tester\",\"expires_at\":\"2026-01-09 00:28:26\"}','2026-01-02 00:28:26'),
('166','608dc9d1-26e0-441d-8144-45f74c53a846','generate_dashboard_link','366b0b18-bf5c-4206-b1c6-65aa1c8c084a','{\"target_username\":\"lubaba\",\"target_role\":\"admin\",\"expires_at\":\"2026-01-09 00:28:37\"}','2026-01-02 00:28:37'),
('167','608dc9d1-26e0-441d-8144-45f74c53a846','generate_dashboard_link','d84019a3-575f-403c-aa12-02482422bcfa','{\"target_username\":\"developer\",\"target_role\":\"developer\",\"expires_at\":\"2026-01-09 01:18:28\"}','2026-01-02 01:18:28'),
('168','608dc9d1-26e0-441d-8144-45f74c53a846','exit_impersonate_mode','366b0b18-bf5c-4206-b1c6-65aa1c8c084a','{\"target_username\":\"lubaba\",\"target_role\":\"admin\",\"exited_at\":\"2026-01-02 02:07:41\"}','2026-01-02 02:07:41');


-- Table structure for table `announcements`
DROP TABLE IF EXISTS `announcements`;
CREATE TABLE `announcements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `expiry_date` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `last_broadcast_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_announcements_active_expiry` (`is_active`,`expiry_date`),
  KEY `idx_announcements_created_at` (`created_at`),
  FULLTEXT KEY `ft_announcements_search` (`title`,`content`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Table structure for table `audit_logs`
DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(36) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `details` longtext DEFAULT NULL CHECK (json_valid(`details`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_action` (`action`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_ip_address` (`ip_address`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `audit_logs`
INSERT INTO `audit_logs` VALUES
('24','608dc9d1-26e0-441d-8144-45f74c53a846','password_reset_requested','{\"email\":\"moajmalnk@gmail.com\",\"ip\":\"::1\"}','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2025-11-02 23:28:22'),
('25','608dc9d1-26e0-441d-8144-45f74c53a846','password_reset_requested','{\"email\":\"moajmalnk@gmail.com\",\"ip\":\"::1\"}','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2025-11-02 23:30:05'),
('26','608dc9d1-26e0-441d-8144-45f74c53a846','password_reset_requested','{\"email\":\"moajmalnk@gmail.com\",\"ip\":\"::1\"}','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2025-11-02 23:30:12'),
('27','608dc9d1-26e0-441d-8144-45f74c53a846','password_reset_requested','{\"email\":\"moajmalnk@gmail.com\",\"ip\":\"::1\"}','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2025-11-02 23:31:32'),
('28','608dc9d1-26e0-441d-8144-45f74c53a846','password_reset_requested','{\"email\":\"moajmalnk@gmail.com\",\"ip\":\"::1\"}','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2025-11-02 23:32:37'),
('29','608dc9d1-26e0-441d-8144-45f74c53a846','password_reset_requested','{\"email\":\"moajmalnk@gmail.com\",\"ip\":\"::1\"}','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2025-11-02 23:40:17'),
('30','608dc9d1-26e0-441d-8144-45f74c53a846','password_reset_completed','{\"email\":\"moajmalnk@gmail.com\",\"ip\":\"::1\"}','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2025-11-02 23:40:46');


-- Table structure for table `blocked_users`
DROP TABLE IF EXISTS `blocked_users`;
CREATE TABLE `blocked_users` (
  `id` varchar(36) NOT NULL,
  `blocker_id` varchar(36) NOT NULL COMMENT 'User who blocked',
  `blocked_id` varchar(36) NOT NULL COMMENT 'User who was blocked',
  `blocked_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_blocker_blocked` (`blocker_id`,`blocked_id`),
  KEY `idx_blocked_users_blocker` (`blocker_id`),
  KEY `idx_blocked_users_blocked` (`blocked_id`),
  CONSTRAINT `blocked_users_ibfk_1` FOREIGN KEY (`blocker_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `blocked_users_ibfk_2` FOREIGN KEY (`blocked_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for table `broadcast_lists`
DROP TABLE IF EXISTS `broadcast_lists`;
CREATE TABLE `broadcast_lists` (
  `id` varchar(36) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_by` varchar(36) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_broadcast_lists_creator` (`created_by`),
  CONSTRAINT `broadcast_lists_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for table `broadcast_recipients`
DROP TABLE IF EXISTS `broadcast_recipients`;
CREATE TABLE `broadcast_recipients` (
  `broadcast_id` varchar(36) NOT NULL,
  `user_id` varchar(36) NOT NULL,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`broadcast_id`,`user_id`),
  KEY `idx_broadcast_recipients_user` (`user_id`),
  CONSTRAINT `broadcast_recipients_ibfk_1` FOREIGN KEY (`broadcast_id`) REFERENCES `broadcast_lists` (`id`) ON DELETE CASCADE,
  CONSTRAINT `broadcast_recipients_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for table `bug_attachments`
DROP TABLE IF EXISTS `bug_attachments`;
CREATE TABLE `bug_attachments` (
  `id` varchar(36) NOT NULL,
  `bug_id` varchar(36) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `file_type` varchar(100) DEFAULT NULL,
  `uploaded_by` varchar(36) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `bug_id` (`bug_id`),
  KEY `uploaded_by` (`uploaded_by`),
  KEY `idx_bug_attachments_bug_id` (`bug_id`),
  KEY `idx_bug_attachments_uploaded_by` (`uploaded_by`),
  KEY `idx_bug_attachments_bug_uploaded` (`bug_id`,`uploaded_by`),
  KEY `idx_bug_attachments_created_at` (`created_at`),
  CONSTRAINT `bug_attachments_ibfk_1` FOREIGN KEY (`bug_id`) REFERENCES `bugs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bug_attachments_ibfk_2` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for table `bug_documents`
DROP TABLE IF EXISTS `bug_documents`;
CREATE TABLE `bug_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bug_id` varchar(255) NOT NULL COMMENT 'Reference to bugs table (UUID)',
  `google_doc_id` varchar(255) NOT NULL COMMENT 'Google Document ID',
  `google_doc_url` text NOT NULL COMMENT 'Full URL to the Google Document',
  `document_name` varchar(500) NOT NULL COMMENT 'Name of the document',
  `created_by` varchar(255) NOT NULL COMMENT 'User who created the document (UUID)',
  `template_id` int(11) DEFAULT NULL COMMENT 'Reference to doc_templates if created from template',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `last_accessed_at` timestamp NULL DEFAULT NULL COMMENT 'Last time document was opened',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_bug_doc` (`bug_id`,`google_doc_id`),
  KEY `idx_bug_id` (`bug_id`),
  KEY `idx_created_by` (`created_by`),
  KEY `idx_template` (`template_id`),
  CONSTRAINT `fk_bug_documents_template` FOREIGN KEY (`template_id`) REFERENCES `doc_templates` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `bug_documents`
INSERT INTO `bug_documents` VALUES
('14','9df3b3d0-c9bd-4e49-a796-542f023a7832','1z2dfwBQ-81unKWfHEf6bd8KThtWrK839qSk0ynZhon0','https://docs.google.com/document/d/1z2dfwBQ-81unKWfHEf6bd8KThtWrK839qSk0ynZhon0/edit','Bug - sasas - 9df3b3d0-c9bd-4e49-a796-542f023a7832','608dc9d1-26e0-441d-8144-45f74c53a846',NULL,'2025-11-04 01:54:13','2025-11-04 01:54:13',NULL),
('15','34383982-31ab-44fb-bed2-cb4d4240154a','1ObT-a_3YvO9_J8v44iBQbODd5Zp_uzdpCTASUH9QofE','https://docs.google.com/document/d/1ObT-a_3YvO9_J8v44iBQbODd5Zp_uzdpCTASUH9QofE/edit','Bug - Demo - 34383982-31ab-44fb-bed2-cb4d4240154a','3045985b-50f9-44e5-9adf-bc6879945272',NULL,'2025-11-04 01:58:17','2025-11-04 01:58:17',NULL);


-- Table structure for table `bugs`
DROP TABLE IF EXISTS `bugs`;
CREATE TABLE `bugs` (
  `id` varchar(36) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `expected_result` text DEFAULT NULL,
  `actual_result` text DEFAULT NULL,
  `fix_description` text DEFAULT NULL,
  `project_id` varchar(36) NOT NULL,
  `reported_by` varchar(36) DEFAULT NULL,
  `priority` enum('high','medium','low') DEFAULT 'medium',
  `status` enum('pending','in_progress','fixed','declined','rejected') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_by` varchar(36) DEFAULT NULL,
  `fixed_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`),
  KEY `reported_by` (`reported_by`),
  KEY `idx_bugs_updated_by` (`updated_by`),
  KEY `idx_bugs_status` (`status`),
  KEY `idx_bugs_updated_by_status` (`updated_by`,`status`),
  KEY `idx_bugs_reported_by` (`reported_by`),
  KEY `idx_bugs_project_id` (`project_id`),
  KEY `idx_bugs_created_at` (`created_at`),
  KEY `idx_bugs_project_created` (`project_id`,`created_at`),
  KEY `idx_bugs_status_updated_by` (`status`,`updated_by`),
  KEY `idx_bugs_project_status_created` (`project_id`,`status`,`created_at`),
  KEY `idx_bugs_reporter_created` (`reported_by`,`created_at`),
  KEY `idx_bugs_project_status_priority` (`project_id`,`status`,`priority`),
  KEY `idx_bugs_reported_by_status` (`reported_by`,`status`),
  KEY `idx_bugs_created_at_status` (`created_at`,`status`),
  KEY `idx_bugs_updated_at` (`updated_at`),
  KEY `idx_bugs_priority_status` (`priority`,`status`),
  KEY `idx_bugs_project_created_status` (`project_id`,`created_at`,`status`),
  KEY `idx_bugs_dashboard` (`project_id`,`status`,`priority`,`created_at`),
  KEY `idx_bugs_covering_list` (`project_id`,`status`,`created_at`,`id`,`title`,`priority`,`reported_by`,`updated_by`),
  KEY `idx_bugs_status_id_project_priority_created` (`status`,`id`,`project_id`,`priority`,`created_at`),
  KEY `idx_bugs_expected_result` (`expected_result`(100)),
  KEY `idx_bugs_actual_result` (`actual_result`(100)),
  FULLTEXT KEY `ft_bugs_search` (`title`,`description`),
  CONSTRAINT `bugs_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bugs_ibfk_2` FOREIGN KEY (`reported_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `bugs`
INSERT INTO `bugs` VALUES
('1d8ee0a2-0c99-4d46-b988-0bd60daa0079','MOHAMMED AJMAL NK','demo','dfd','dfdf','Fixed, Can U check Now','63fe666d-82e2-4537-83fc-aa778ce17b08','608dc9d1-26e0-441d-8144-45f74c53a846','medium','fixed','2025-12-02 06:20:30','2025-12-06 01:26:15','608dc9d1-26e0-441d-8144-45f74c53a846','608dc9d1-26e0-441d-8144-45f74c53a846'),
('2bc23920-c0e4-472a-901c-25c86afc1379','dsdsd','sdsds',NULL,NULL,'Fixed, Can U check Now','63fe666d-82e2-4537-83fc-aa778ce17b08','608dc9d1-26e0-441d-8144-45f74c53a846','medium','fixed','2025-11-04 07:20:22','2026-01-02 01:18:00','366b0b18-bf5c-4206-b1c6-65aa1c8c084a','366b0b18-bf5c-4206-b1c6-65aa1c8c084a'),
('34383982-31ab-44fb-bed2-cb4d4240154a','Demo','dcdfcdc',NULL,'cscsx','Fixed, Can U check Now','83f0e57d-6905-49b6-99a4-2b3df2595644','608dc9d1-26e0-441d-8144-45f74c53a846','medium','fixed','2025-11-03 15:56:46','2025-11-04 01:35:05','3045985b-50f9-44e5-9adf-bc6879945272','3045985b-50f9-44e5-9adf-bc6879945272'),
('384bc5bb-92d8-4728-a60b-22511d16b13d','test ajmal','test','test','test','Fixed, Can U check Now','83f0e57d-6905-49b6-99a4-2b3df2595644','608dc9d1-26e0-441d-8144-45f74c53a846','medium','pending','2026-01-02 00:19:01','2026-01-02 02:11:44','608dc9d1-26e0-441d-8144-45f74c53a846','608dc9d1-26e0-441d-8144-45f74c53a846'),
('3d06eb74-e7a9-471c-862f-a2922fed012b','Mobile App Designdsdsd','dsdsd','sdsds','dsdsds','Fixed, Can U check Now','83f0e57d-6905-49b6-99a4-2b3df2595644','c18ce191-e34b-4ca7-b69b-6a78488d3de5','high','fixed','2025-11-03 05:53:31','2025-11-03 10:27:16','608dc9d1-26e0-441d-8144-45f74c53a846','608dc9d1-26e0-441d-8144-45f74c53a846'),
('48dc13d0-e1c1-428d-bfb9-c7da24484a62','CBSE','test','test','test','Fixed, Can U check Now','63fe666d-82e2-4537-83fc-aa778ce17b08','608dc9d1-26e0-441d-8144-45f74c53a846','high','fixed','2025-12-02 09:03:02','2025-12-02 09:21:44','d84019a3-575f-403c-aa12-02482422bcfa','d84019a3-575f-403c-aa12-02482422bcfa'),
('5567793c-e264-45e7-8ab2-2c6f7bd5fde2','test','tervice: Response: {success: true, count: 3, notifications: Array(3)}\r\nnotificationService.ts:279 NotificationService: Response: {success: true, count: 3, notifications: Array(3)}','rvice: Response: {success: true, count: 3, notifications: Array(3)}\r\nnotificationService.ts:279 NotificationService: Response: {success: true, count: 3, notifications: Array(3)}','rvice: Response: {success: true, count: 3, notifications: Array(3)}\r\nnotificationService.ts:279 NotificationService: Response: {success: true, count: 3, notifications: Array(3)}',NULL,'63fe666d-82e2-4537-83fc-aa778ce17b08','608dc9d1-26e0-441d-8144-45f74c53a846','medium','fixed','2025-12-02 06:34:42','2025-12-02 01:47:55','608dc9d1-26e0-441d-8144-45f74c53a846','608dc9d1-26e0-441d-8144-45f74c53a846'),
('599f4a9f-41d6-4446-b4dc-69572ddc5bea','MOHAMMED AJMAL NK','test','test','test','Fixed, Can U check Now','63fe666d-82e2-4537-83fc-aa778ce17b08','608dc9d1-26e0-441d-8144-45f74c53a846','high','fixed','2026-01-02 00:15:10','2026-01-02 01:21:43','d84019a3-575f-403c-aa12-02482422bcfa','d84019a3-575f-403c-aa12-02482422bcfa'),
('78eebeb4-2fbc-419d-b7d2-5e652c80905d','Testing','Testing','Testing','Testing','Fixed, Can U check Now','83f0e57d-6905-49b6-99a4-2b3df2595644','608dc9d1-26e0-441d-8144-45f74c53a846','high','fixed','2025-11-03 02:28:54','2025-11-03 00:26:26','608dc9d1-26e0-441d-8144-45f74c53a846','608dc9d1-26e0-441d-8144-45f74c53a846'),
('8675a113-7ba5-4667-bb8d-e0356e3a6e1b','dwd','scsdcs','sdsd','dsdsd','Fixed, Can U check Now','83f0e57d-6905-49b6-99a4-2b3df2595644','608dc9d1-26e0-441d-8144-45f74c53a846','medium','fixed','2025-11-03 16:22:01','2026-01-02 01:29:27','d84019a3-575f-403c-aa12-02482422bcfa','d84019a3-575f-403c-aa12-02482422bcfa'),
('9df3b3d0-c9bd-4e49-a796-542f023a7832','sasas','asa',NULL,NULL,'Fixed, Can U check Now','83f0e57d-6905-49b6-99a4-2b3df2595644','608dc9d1-26e0-441d-8144-45f74c53a846','medium','fixed','2025-11-04 07:21:45','2026-01-02 01:17:49','366b0b18-bf5c-4206-b1c6-65aa1c8c084a','366b0b18-bf5c-4206-b1c6-65aa1c8c084a'),
('a43aa6dc-477a-4568-8ad5-834d78da901a','MOHAMMED AJMAL NK','test','test','test','Fixed, Can U check Now','63fe666d-82e2-4537-83fc-aa778ce17b08','608dc9d1-26e0-441d-8144-45f74c53a846','high','fixed','2026-01-02 00:18:17','2026-01-02 01:17:13','608dc9d1-26e0-441d-8144-45f74c53a846','608dc9d1-26e0-441d-8144-45f74c53a846'),
('b6739ea3-cccb-40eb-8466-da2758dfe7c5','Task','Demo','asdsd','sdsd','Fixed, Can U check Now','63fe666d-82e2-4537-83fc-aa778ce17b08','608dc9d1-26e0-441d-8144-45f74c53a846','medium','fixed','2025-11-04 07:08:58','2026-01-02 01:25:44','d84019a3-575f-403c-aa12-02482422bcfa','d84019a3-575f-403c-aa12-02482422bcfa'),
('d51d92e3-3074-4351-b04d-42a4f4a4db1e','b vn','ghj',NULL,NULL,'Fixed, Can U check Now','83f0e57d-6905-49b6-99a4-2b3df2595644','608dc9d1-26e0-441d-8144-45f74c53a846','medium','fixed','2025-11-04 07:18:22','2026-01-02 01:23:20','d84019a3-575f-403c-aa12-02482422bcfa','d84019a3-575f-403c-aa12-02482422bcfa'),
('fdd32ddb-517c-4c01-83f6-97b73cf03d5c','MOHAMMED AJMAL NK','test','test','test','Fixed, Can U check Now','63fe666d-82e2-4537-83fc-aa778ce17b08','608dc9d1-26e0-441d-8144-45f74c53a846','high','fixed','2026-01-02 00:16:31','2026-01-02 01:19:59','d84019a3-575f-403c-aa12-02482422bcfa','d84019a3-575f-403c-aa12-02482422bcfa');


-- Table structure for table `call_logs`
DROP TABLE IF EXISTS `call_logs`;
CREATE TABLE `call_logs` (
  `id` varchar(36) NOT NULL,
  `call_type` enum('voice','video') NOT NULL,
  `caller_id` varchar(36) NOT NULL,
  `group_id` varchar(36) DEFAULT NULL COMMENT 'For group calls',
  `duration_seconds` int(11) DEFAULT NULL,
  `status` enum('missed','declined','completed','failed') NOT NULL DEFAULT 'completed',
  `started_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `ended_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_call_logs_caller` (`caller_id`),
  KEY `idx_call_logs_group` (`group_id`),
  KEY `idx_call_logs_started` (`started_at`),
  CONSTRAINT `call_logs_ibfk_1` FOREIGN KEY (`caller_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `call_logs_ibfk_2` FOREIGN KEY (`group_id`) REFERENCES `chat_groups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for table `call_participants`
DROP TABLE IF EXISTS `call_participants`;
CREATE TABLE `call_participants` (
  `call_id` varchar(36) NOT NULL,
  `user_id` varchar(36) NOT NULL,
  `joined_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `left_at` timestamp NULL DEFAULT NULL,
  `status` enum('calling','joined','declined','missed') NOT NULL DEFAULT 'calling',
  PRIMARY KEY (`call_id`,`user_id`),
  KEY `idx_call_participants_user` (`user_id`),
  CONSTRAINT `call_participants_ibfk_1` FOREIGN KEY (`call_id`) REFERENCES `call_logs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `call_participants_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for table `chat_group_members`
DROP TABLE IF EXISTS `chat_group_members`;
CREATE TABLE `chat_group_members` (
  `group_id` varchar(36) NOT NULL,
  `user_id` varchar(36) NOT NULL,
  `joined_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_read_at` timestamp NULL DEFAULT NULL,
  `is_muted` tinyint(1) NOT NULL DEFAULT 0,
  `muted_until` timestamp NULL DEFAULT NULL,
  `show_read_receipts` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`group_id`,`user_id`),
  KEY `idx_chat_group_members_user_id` (`user_id`),
  KEY `idx_chat_group_members_group_id` (`group_id`),
  KEY `idx_chat_group_members_user_group` (`user_id`,`group_id`),
  CONSTRAINT `chat_group_members_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `chat_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `chat_group_members_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `chat_group_members`
INSERT INTO `chat_group_members` VALUES
('b7e91d71-9e0d-44e2-95d9-436f3266ac66','608dc9d1-26e0-441d-8144-45f74c53a846','2026-01-01 23:17:49',NULL,'0',NULL,'1');


-- Table structure for table `chat_groups`
DROP TABLE IF EXISTS `chat_groups`;
CREATE TABLE `chat_groups` (
  `id` varchar(36) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `group_picture` varchar(500) DEFAULT NULL,
  `project_id` varchar(36) NOT NULL,
  `created_by` varchar(36) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_archived` tinyint(1) NOT NULL DEFAULT 0,
  `archived_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_chat_groups_project_id` (`project_id`),
  KEY `idx_chat_groups_created_by` (`created_by`),
  KEY `idx_chat_groups_is_active` (`is_active`),
  KEY `idx_chat_groups_project_active` (`project_id`,`is_active`),
  KEY `idx_chat_groups_is_archived` (`is_archived`),
  CONSTRAINT `chat_groups_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `chat_groups_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `chat_groups`
INSERT INTO `chat_groups` VALUES
('b7e91d71-9e0d-44e2-95d9-436f3266ac66','testz','test',NULL,'291c8841-94a5-4cdb-9eb8-fef40709aee5','608dc9d1-26e0-441d-8144-45f74c53a846','1','0',NULL,'2026-01-01 23:17:49','2026-01-01 23:17:49');


-- Table structure for table `chat_messages`
DROP TABLE IF EXISTS `chat_messages`;
CREATE TABLE `chat_messages` (
  `id` varchar(36) NOT NULL,
  `group_id` varchar(36) NOT NULL,
  `sender_id` varchar(36) NOT NULL,
  `message_type` enum('text','voice','reply','image','video','document','audio','location','contact') NOT NULL DEFAULT 'text',
  `media_type` enum('image','video','document','audio') DEFAULT NULL,
  `media_file_path` varchar(500) DEFAULT NULL,
  `media_file_name` varchar(255) DEFAULT NULL,
  `media_file_size` int(11) DEFAULT NULL COMMENT 'File size in bytes',
  `media_thumbnail` varchar(500) DEFAULT NULL,
  `media_duration` int(11) DEFAULT NULL COMMENT 'For video/audio in seconds',
  `content` text DEFAULT NULL,
  `voice_file_path` varchar(500) DEFAULT NULL,
  `voice_duration` int(11) DEFAULT NULL COMMENT 'Duration in seconds',
  `reply_to_message_id` varchar(36) DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `is_pinned` tinyint(1) NOT NULL DEFAULT 0,
  `is_starred` tinyint(1) NOT NULL DEFAULT 0,
  `starred_at` timestamp NULL DEFAULT NULL,
  `starred_by` varchar(36) DEFAULT NULL,
  `is_forwarded` tinyint(1) NOT NULL DEFAULT 0,
  `original_message_id` varchar(36) DEFAULT NULL,
  `is_edited` tinyint(1) NOT NULL DEFAULT 0,
  `edited_at` timestamp NULL DEFAULT NULL,
  `delivery_status` enum('sent','delivered','read','failed') NOT NULL DEFAULT 'sent',
  `pinned_at` timestamp NULL DEFAULT NULL,
  `pinned_by` varchar(36) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_chat_messages_group_id` (`group_id`),
  KEY `idx_chat_messages_sender_id` (`sender_id`),
  KEY `idx_chat_messages_created_at` (`created_at`),
  KEY `idx_chat_messages_reply_to` (`reply_to_message_id`),
  KEY `idx_chat_messages_is_deleted` (`is_deleted`),
  KEY `idx_chat_messages_is_pinned` (`is_pinned`),
  KEY `chat_messages_ibfk_4` (`pinned_by`),
  KEY `idx_chat_messages_group_created` (`group_id`,`created_at`),
  KEY `idx_chat_messages_sender_created` (`sender_id`,`created_at`),
  KEY `idx_chat_messages_is_starred` (`is_starred`),
  KEY `idx_chat_messages_is_forwarded` (`is_forwarded`),
  KEY `idx_chat_messages_delivery_status` (`delivery_status`),
  KEY `idx_chat_messages_media_type` (`media_type`),
  CONSTRAINT `chat_messages_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `chat_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `chat_messages_ibfk_2` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`),
  CONSTRAINT `chat_messages_ibfk_3` FOREIGN KEY (`reply_to_message_id`) REFERENCES `chat_messages` (`id`) ON DELETE SET NULL,
  CONSTRAINT `chat_messages_ibfk_4` FOREIGN KEY (`pinned_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for table `disappearing_messages_settings`
DROP TABLE IF EXISTS `disappearing_messages_settings`;
CREATE TABLE `disappearing_messages_settings` (
  `group_id` varchar(36) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 0,
  `duration_seconds` int(11) NOT NULL DEFAULT 604800 COMMENT '7 days default',
  `enabled_by` varchar(36) DEFAULT NULL,
  `enabled_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`group_id`),
  KEY `disappearing_messages_settings_ibfk_2` (`enabled_by`),
  CONSTRAINT `disappearing_messages_settings_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `chat_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `disappearing_messages_settings_ibfk_2` FOREIGN KEY (`enabled_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for table `doc_templates`
DROP TABLE IF EXISTS `doc_templates`;
CREATE TABLE `doc_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_name` varchar(255) NOT NULL COMMENT 'Human-readable template name (e.g., Bug Report, Meeting Notes)',
  `google_doc_id` varchar(255) NOT NULL COMMENT 'Google Document ID of the template file',
  `description` text DEFAULT NULL COMMENT 'Template description',
  `category` varchar(100) DEFAULT 'general' COMMENT 'Template category: bug, general, meeting, etc.',
  `is_active` tinyint(1) DEFAULT 1 COMMENT 'Whether template is active and available for use',
  `created_by` varchar(255) DEFAULT NULL COMMENT 'User who created the template',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_category` (`category`),
  KEY `idx_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Document templates for BugDocs';

-- Dumping data for table `doc_templates`
INSERT INTO `doc_templates` VALUES
('1','Bug Report Template','TEMPLATE_BUG_REPORT_ID','Professional bug investigation and reporting template with placeholders for bug details','bug','1',NULL,'2025-10-20 22:57:23','2025-10-20 22:57:23'),
('2','Meeting Notes Template','TEMPLATE_MEETING_NOTES_ID','Structured meeting notes with agenda, attendees, and action items','meeting','1',NULL,'2025-10-20 22:57:23','2025-10-20 22:57:23'),
('3','General Document','TEMPLATE_GENERAL_DOC_ID','Blank document for general purposes','general','1',NULL,'2025-10-20 22:57:23','2025-10-20 22:57:23'),
('4','Technical Specification','TEMPLATE_TECH_SPEC_ID','Technical specification document template','technical','1',NULL,'2025-10-20 22:57:23','2025-10-20 22:57:23');


-- Table structure for table `google_tokens`
DROP TABLE IF EXISTS `google_tokens`;
CREATE TABLE `google_tokens` (
  `google_user_id` varchar(255) NOT NULL COMMENT 'Google User ID (from OAuth)',
  `bugricer_user_id` varchar(255) NOT NULL COMMENT 'BugRicer user ID reference (UUID)',
  `refresh_token` text NOT NULL COMMENT 'Google OAuth Refresh Token (long-lived)',
  `access_token_expiry` timestamp NULL DEFAULT NULL COMMENT 'When the current access token expires',
  `email` varchar(255) DEFAULT NULL COMMENT 'Google account email',
  `scope` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`google_user_id`),
  KEY `idx_bugricer_user` (`bugricer_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `google_tokens`
INSERT INTO `google_tokens` VALUES
('107382277436991019043','608dc9d1-26e0-441d-8144-45f74c53a846','1//0gVjqSioHHMQqCgYIARAAGBASNwF-L9IrMSsiqj8CVpJFUmv8xxqFKRfIn6aDHrinNlYoX5o1hYWc5_AR4jfmvLGzBQBX8Bm_JFI','2026-01-02 02:56:07','ajmalnk10091@gmail.com',NULL,'2025-12-02 10:38:21','2026-01-02 01:56:08'),
('110151591091305682967','e1e7aecc-96f9-452b-b60c-e9541c27ea3d','1//0gYIik_EwIpVuCgYIARAAGBASNwF-L9IrSieHSD_pRwvRitqIodNyZMNWkRIgZEW2zCM6D2OCqpiJbneCcW1DrkqPalF4UgrT_BQ','2025-11-03 02:45:42','moajmalnk@gmail.com',NULL,'2025-11-03 00:19:47','2025-11-03 01:45:43'),
('113600984433691675744','d84019a3-575f-403c-aa12-02482422bcfa','1//0gKT26jtdGxsoCgYIARAAGBASNwF-L9IrWOzRGZJVCoapaIG0SmyWOvwABdG4GZeGweBVNiWFUeWUIgGqZi6yPP_JGFFEQ8QpB3A','2026-01-02 02:29:41','ai.codomail@gmail.com',NULL,'2025-12-02 08:48:04','2026-01-02 01:29:42');


-- Table structure for table `group_admins`
DROP TABLE IF EXISTS `group_admins`;
CREATE TABLE `group_admins` (
  `group_id` varchar(36) NOT NULL,
  `user_id` varchar(36) NOT NULL,
  `granted_by` varchar(36) NOT NULL,
  `granted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`group_id`,`user_id`),
  KEY `idx_group_admins_user` (`user_id`),
  KEY `group_admins_ibfk_3` (`granted_by`),
  CONSTRAINT `group_admins_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `chat_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `group_admins_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `group_admins_ibfk_3` FOREIGN KEY (`granted_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for table `magic_links`
DROP TABLE IF EXISTS `magic_links`;
CREATE TABLE `magic_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `token` varchar(64) NOT NULL,
  `email` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  KEY `idx_token` (`token`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_expires_at` (`expires_at`),
  KEY `idx_cleanup` (`expires_at`,`used_at`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Stores magic link tokens for passwordless email authentication';

-- Dumping data for table `magic_links`
INSERT INTO `magic_links` VALUES
('25','608','603a7d82ca43acfc17b8b27f51f354ac332f2646b46b2385d21aca26149c9ad5','moajmalnk@gmail.com','2025-11-02 13:13:57',NULL,'2025-11-02 11:58:57');


-- Table structure for table `meeting_messages`
DROP TABLE IF EXISTS `meeting_messages`;
CREATE TABLE `meeting_messages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `meeting_id` bigint(20) unsigned NOT NULL,
  `sender_id` varchar(36) DEFAULT NULL,
  `sender_name` varchar(255) DEFAULT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_messages_meeting` (`meeting_id`),
  FULLTEXT KEY `idx_messages_text` (`message`),
  CONSTRAINT `fk_message_meeting` FOREIGN KEY (`meeting_id`) REFERENCES `meetings` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Table structure for table `meeting_participants`
DROP TABLE IF EXISTS `meeting_participants`;
CREATE TABLE `meeting_participants` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `meeting_id` bigint(20) unsigned NOT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  `display_name` varchar(255) DEFAULT NULL,
  `role` enum('host','cohost','participant') NOT NULL DEFAULT 'participant',
  `joined_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `left_at` timestamp NULL DEFAULT NULL,
  `is_connected` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_participants_meeting` (`meeting_id`),
  KEY `idx_participants_user` (`user_id`),
  CONSTRAINT `fk_participant_meeting` FOREIGN KEY (`meeting_id`) REFERENCES `meetings` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3606 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Table structure for table `meeting_recordings`
DROP TABLE IF EXISTS `meeting_recordings`;
CREATE TABLE `meeting_recordings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `meeting_id` bigint(20) unsigned NOT NULL,
  `storage_path` varchar(512) NOT NULL,
  `duration_seconds` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_recordings_meeting` (`meeting_id`),
  CONSTRAINT `fk_recording_meeting` FOREIGN KEY (`meeting_id`) REFERENCES `meetings` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Table structure for table `meetings`
DROP TABLE IF EXISTS `meetings`;
CREATE TABLE `meetings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `meeting_code` varchar(16) NOT NULL,
  `title` varchar(255) NOT NULL,
  `created_by` varchar(36) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `meeting_code` (`meeting_code`),
  KEY `idx_meetings_code` (`meeting_code`),
  KEY `idx_meetings_creator` (`created_by`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Table structure for table `message_delivery_status`
DROP TABLE IF EXISTS `message_delivery_status`;
CREATE TABLE `message_delivery_status` (
  `id` varchar(36) NOT NULL,
  `message_id` varchar(36) NOT NULL,
  `user_id` varchar(36) NOT NULL,
  `status` enum('delivered','read') NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_message_status` (`message_id`,`user_id`,`status`),
  KEY `idx_delivery_status_message` (`message_id`),
  KEY `idx_delivery_status_user` (`user_id`),
  KEY `idx_delivery_status_timestamp` (`timestamp`),
  CONSTRAINT `message_delivery_status_ibfk_1` FOREIGN KEY (`message_id`) REFERENCES `chat_messages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `message_delivery_status_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for table `message_mentions`
DROP TABLE IF EXISTS `message_mentions`;
CREATE TABLE `message_mentions` (
  `id` varchar(36) NOT NULL,
  `message_id` varchar(36) NOT NULL,
  `mentioned_user_id` varchar(36) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_message_mentions_message_id` (`message_id`),
  KEY `idx_message_mentions_user_id` (`mentioned_user_id`),
  CONSTRAINT `message_mentions_ibfk_1` FOREIGN KEY (`message_id`) REFERENCES `chat_messages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `message_mentions_ibfk_2` FOREIGN KEY (`mentioned_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for table `message_polls`
DROP TABLE IF EXISTS `message_polls`;
CREATE TABLE `message_polls` (
  `id` varchar(36) NOT NULL,
  `message_id` varchar(36) NOT NULL,
  `question` text NOT NULL,
  `created_by` varchar(36) NOT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `allow_multiple_answers` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_message_polls_message` (`message_id`),
  KEY `idx_message_polls_creator` (`created_by`),
  CONSTRAINT `message_polls_ibfk_1` FOREIGN KEY (`message_id`) REFERENCES `chat_messages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `message_polls_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for table `message_reactions`
DROP TABLE IF EXISTS `message_reactions`;
CREATE TABLE `message_reactions` (
  `id` varchar(36) NOT NULL,
  `message_id` varchar(36) NOT NULL,
  `user_id` varchar(36) NOT NULL,
  `emoji` varchar(10) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_message_emoji` (`message_id`,`user_id`,`emoji`),
  KEY `idx_message_reactions_message_id` (`message_id`),
  KEY `idx_message_reactions_user_id` (`user_id`),
  KEY `idx_message_reactions_emoji` (`emoji`),
  CONSTRAINT `message_reactions_ibfk_1` FOREIGN KEY (`message_id`) REFERENCES `chat_messages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `message_reactions_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for table `message_read_status`
DROP TABLE IF EXISTS `message_read_status`;
CREATE TABLE `message_read_status` (
  `message_id` varchar(36) NOT NULL,
  `user_id` varchar(36) NOT NULL,
  `read_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`message_id`,`user_id`),
  KEY `idx_message_read_status_user_id` (`user_id`),
  KEY `idx_message_read_status_read_at` (`read_at`),
  CONSTRAINT `message_read_status_ibfk_1` FOREIGN KEY (`message_id`) REFERENCES `chat_messages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `message_read_status_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for table `notifications`
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` enum('new_bug','status_change','new_update','bug_created','bug_fixed','update_created','task_created','meet_created','doc_created','project_created','task_assigned','task_completed','meeting_reminder','info') NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `bug_id` varchar(36) DEFAULT NULL,
  `bug_title` varchar(255) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `created_by` varchar(100) DEFAULT 'system',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `entity_type` varchar(50) DEFAULT NULL COMMENT 'Type of entity: bug, task, meet, doc, update, project',
  `entity_id` varchar(36) DEFAULT NULL COMMENT 'ID of the related entity',
  `project_id` varchar(36) DEFAULT NULL COMMENT 'Related project ID',
  PRIMARY KEY (`id`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_type` (`type`),
  KEY `idx_bug_id` (`bug_id`),
  KEY `idx_notifications_type_created` (`type`,`created_at`),
  KEY `idx_notifications_bug_status` (`bug_id`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=198 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `notifications`
INSERT INTO `notifications` VALUES
('112','status_change','Bug Status Updated','Bug has been fixed: Sample','0','Sample','fixed','BugRicer User','2025-11-03 00:26:25',NULL,NULL,NULL),
('113','status_change','Bug Status Updated','Bug has been fixed: Testing','78','Testing','fixed','BugRicer','2025-11-03 00:26:31',NULL,NULL,NULL),
('114','new_bug','New Bug Reported','A new bug has been reported: Demo','34383982-31ab-44fb-bed2-cb4d4240154a','Demo',NULL,'moajmalnk','2025-11-03 10:26:46','bug','34383982-31ab-44fb-bed2-cb4d4240154a','83f0e57d-6905-49b6-99a4-2b3df2595644'),
('115','new_bug','Bug Fixed','Bug \'Mobile App Designdsdsd\' has been marked as fixed','3d06eb74-e7a9-471c-862f-a2922fed012b','Mobile App Designdsdsd','fixed','moajmalnk','2025-11-03 10:27:16','bug','3d06eb74-e7a9-471c-862f-a2922fed012b','83f0e57d-6905-49b6-99a4-2b3df2595644'),
('116','status_change','Bug Status Updated','Bug has been fixed: Mobile App Designdsdsd','3','Mobile App Designdsdsd','fixed','BugRicer','2025-11-03 10:27:21',NULL,NULL,NULL),
('117','new_bug','New Update Posted','A new update has been posted: demo',NULL,NULL,NULL,'moajmalnk','2025-11-03 10:27:45','update','3fd21fb0-b608-4d73-ba4c-9383f682c221','83f0e57d-6905-49b6-99a4-2b3df2595644'),
('118','new_bug','New Update Posted','A new update has been posted: ddd',NULL,NULL,NULL,'moajmalnk','2025-11-03 10:29:52','update','98b63287-9c08-4990-a06e-2bb6fe1ae918','83f0e57d-6905-49b6-99a4-2b3df2595644'),
('119','new_bug','New Update Posted','A new update has been posted: ddd',NULL,NULL,NULL,'moajmalnk','2025-11-03 10:40:37','update','cb5eef4a-993e-4e1b-bf37-cb881176f139','83f0e57d-6905-49b6-99a4-2b3df2595644'),
('120','new_bug','New Update Posted','A new update has been posted: sdsd',NULL,NULL,NULL,'moajmalnk','2025-11-03 10:43:12','update','ef69e245-8d3a-4597-b8b0-d3fb30ef654e','83f0e57d-6905-49b6-99a4-2b3df2595644'),
('121','new_update','New Update Posted','A new update has been posted: dddd','0','dddd',NULL,'BugRicer','2025-11-03 10:46:13',NULL,NULL,NULL),
('123','new_bug','Test Notification','This is a test notification to verify the system is working',NULL,NULL,NULL,'System Test','2025-11-03 11:14:43','test',NULL,'project-1'),
('124','new_bug','Test Notification','This is a test notification to verify the system is working',NULL,NULL,NULL,'System Test','2025-11-03 11:15:14','test',NULL,'project-1'),
('125','bug_created','Test Notification','This is a test notification to verify the system is working',NULL,NULL,NULL,'System Test','2025-11-03 11:16:27','test',NULL,'project-1'),
('126','bug_fixed','Bug Fixed','Bug \'dwd\' has been marked as fixed','8675a113-7ba5-4667-bb8d-e0356e3a6e1b','dwd','fixed','developer','2025-11-03 23:49:07','bug','8675a113-7ba5-4667-bb8d-e0356e3a6e1b','83f0e57d-6905-49b6-99a4-2b3df2595644'),
('127','status_change','Bug Status Updated','Bug has been fixed: dwd','8675','dwd','fixed','BugRicer User','2025-11-03 23:49:08',NULL,NULL,NULL),
('128','bug_fixed','Bug Fixed','Bug \'Demo\' has been marked as fixed','34383982-31ab-44fb-bed2-cb4d4240154a','Demo','fixed','moajmalnk22','2025-11-04 01:33:11','bug','34383982-31ab-44fb-bed2-cb4d4240154a','83f0e57d-6905-49b6-99a4-2b3df2595644'),
('129','status_change','Bug Status Updated','Bug has been fixed: Demo','34383982','Demo','fixed','BugRicer','2025-11-04 01:33:11',NULL,NULL,NULL),
('130','bug_fixed','Bug Fixed','Bug \'Demo\' has been marked as fixed','34383982-31ab-44fb-bed2-cb4d4240154a','Demo','fixed','moajmalnk22','2025-11-04 01:34:18','bug','34383982-31ab-44fb-bed2-cb4d4240154a','83f0e57d-6905-49b6-99a4-2b3df2595644'),
('131','bug_fixed','Bug Fixed','Bug \'Demo\' has been marked as fixed','34383982-31ab-44fb-bed2-cb4d4240154a','Demo','fixed','moajmalnk22','2025-11-04 01:35:05','bug','34383982-31ab-44fb-bed2-cb4d4240154a','83f0e57d-6905-49b6-99a4-2b3df2595644'),
('132','bug_created','New Bug Reported','A new bug has been reported: Task','b6739ea3-cccb-40eb-8466-da2758dfe7c5','Task',NULL,'moajmalnk','2025-11-04 01:38:58','bug','b6739ea3-cccb-40eb-8466-da2758dfe7c5','63fe666d-82e2-4537-83fc-aa778ce17b08'),
('133','bug_created','New Bug Reported','A new bug has been reported: b vn','d51d92e3-3074-4351-b04d-42a4f4a4db1e','b vn',NULL,'moajmalnk','2025-11-04 01:48:22','bug','d51d92e3-3074-4351-b04d-42a4f4a4db1e','83f0e57d-6905-49b6-99a4-2b3df2595644'),
('134','bug_created','New Bug Reported','A new bug has been reported: dsdsd','2bc23920-c0e4-472a-901c-25c86afc1379','dsdsd',NULL,'moajmalnk','2025-11-04 01:50:22','bug','2bc23920-c0e4-472a-901c-25c86afc1379','63fe666d-82e2-4537-83fc-aa778ce17b08'),
('135','bug_created','New Bug Reported','A new bug has been reported: sasas','9df3b3d0-c9bd-4e49-a796-542f023a7832','sasas',NULL,'moajmalnk','2025-11-04 01:51:45','bug','9df3b3d0-c9bd-4e49-a796-542f023a7832','83f0e57d-6905-49b6-99a4-2b3df2595644'),
('136','task_created','New Task Assigned','A new task has been created: Test',NULL,NULL,NULL,'moajmalnk','2025-12-02 00:09:31','task','17','291c8841-94a5-4cdb-9eb8-fef40709aee5'),
('137','task_created','New Task Assigned','A new task has been created: Test',NULL,NULL,NULL,'moajmalnk','2025-12-02 00:14:35','task','18','63fe666d-82e2-4537-83fc-aa778ce17b08'),
('138','update_created','New Update Posted','A new update has been posted: test',NULL,NULL,NULL,'moajmalnk','2025-12-02 00:39:20','update','23226f53-0e92-4d32-b146-571b987761b0','63fe666d-82e2-4537-83fc-aa778ce17b08'),
('139','new_update','New Update Posted','A new update has been posted: test','23226','test',NULL,'BugRicer','2025-12-02 00:39:22',NULL,NULL,NULL),
('140','bug_created','New Bug Reported','A new bug has been reported: MOHAMMED AJMAL NK','1d8ee0a2-0c99-4d46-b988-0bd60daa0079','MOHAMMED AJMAL NK',NULL,'moajmalnk','2025-12-02 00:50:30','bug','1d8ee0a2-0c99-4d46-b988-0bd60daa0079','63fe666d-82e2-4537-83fc-aa778ce17b08'),
('141','bug_created','New Bug Reported','A new bug has been reported: test','5567793c-e264-45e7-8ab2-2c6f7bd5fde2','test',NULL,'moajmalnk','2025-12-02 01:04:42','bug','5567793c-e264-45e7-8ab2-2c6f7bd5fde2','63fe666d-82e2-4537-83fc-aa778ce17b08'),
('142','bug_fixed','Bug Fixed','Bug \'test\' has been marked as fixed','5567793c-e264-45e7-8ab2-2c6f7bd5fde2','test','fixed','moajmalnk','2025-12-02 01:47:55','bug','5567793c-e264-45e7-8ab2-2c6f7bd5fde2','63fe666d-82e2-4537-83fc-aa778ce17b08'),
('143','status_change','Bug Status Updated','Bug has been fixed: test','5567793','test','fixed','BugRicer User','2025-12-02 01:47:56',NULL,NULL,NULL),
('144','bug_fixed','Bug Fixed','Bug \'sasas\' has been marked as fixed','9df3b3d0-c9bd-4e49-a796-542f023a7832','sasas','fixed','moajmalnk','2025-12-02 01:48:10','bug','9df3b3d0-c9bd-4e49-a796-542f023a7832','83f0e57d-6905-49b6-99a4-2b3df2595644'),
('145','status_change','Bug Status Updated','Bug has been fixed: sasas','9','sasas','fixed','BugRicer User','2025-12-02 01:48:10',NULL,NULL,NULL),
('146','bug_fixed','Bug Fixed','Bug \'sasas\' has been marked as fixed','9df3b3d0-c9bd-4e49-a796-542f023a7832','sasas','fixed','moajmalnk','2025-12-02 01:49:21','bug','9df3b3d0-c9bd-4e49-a796-542f023a7832','83f0e57d-6905-49b6-99a4-2b3df2595644'),
('147','status_change','Bug Status Updated','Bug has been fixed: sasas','9','sasas','fixed','BugRicer User','2025-12-02 01:49:21',NULL,NULL,NULL),
('148','bug_fixed','Bug Fixed','Bug \'sasas\' has been marked as fixed','9df3b3d0-c9bd-4e49-a796-542f023a7832','sasas','fixed','moajmalnk','2025-12-02 01:52:01','bug','9df3b3d0-c9bd-4e49-a796-542f023a7832','83f0e57d-6905-49b6-99a4-2b3df2595644'),
('149','status_change','Bug Status Updated','Bug has been fixed: sasas','9','sasas','fixed','BugRicer','2025-12-02 01:52:01',NULL,NULL,NULL),
('150','bug_fixed','Bug Fixed','Bug \'sasas\' has been marked as fixed','9df3b3d0-c9bd-4e49-a796-542f023a7832','sasas','fixed','moajmalnk','2025-12-02 01:52:53','bug','9df3b3d0-c9bd-4e49-a796-542f023a7832','83f0e57d-6905-49b6-99a4-2b3df2595644'),
('151','status_change','Bug Status Updated','Bug has been fixed: sasas','9','sasas','fixed','BugRicer User','2025-12-02 01:52:53',NULL,NULL,NULL),
('152','bug_fixed','Bug Fixed','Bug \'sasas\' has been marked as fixed','9df3b3d0-c9bd-4e49-a796-542f023a7832','sasas','fixed','moajmalnk','2025-12-02 01:56:23','bug','9df3b3d0-c9bd-4e49-a796-542f023a7832','83f0e57d-6905-49b6-99a4-2b3df2595644'),
('153','status_change','Bug Status Updated','Bug has been fixed: sasas','9','sasas','fixed','BugRicer User','2025-12-02 01:56:24',NULL,NULL,NULL),
('154','bug_fixed','Bug Fixed','Bug \'sasas\' has been marked as fixed','9df3b3d0-c9bd-4e49-a796-542f023a7832','sasas','fixed','moajmalnk','2025-12-02 01:56:39','bug','9df3b3d0-c9bd-4e49-a796-542f023a7832','83f0e57d-6905-49b6-99a4-2b3df2595644'),
('155','status_change','Bug Status Updated','Bug has been fixed: sasas','9','sasas','fixed','BugRicer User','2025-12-02 01:56:39',NULL,NULL,NULL),
('156','bug_created','New Bug Reported','A new bug has been reported: CBSE','48dc13d0-e1c1-428d-bfb9-c7da24484a62','CBSE',NULL,'moajmalnk','2025-12-02 09:03:02','bug','48dc13d0-e1c1-428d-bfb9-c7da24484a62','63fe666d-82e2-4537-83fc-aa778ce17b08'),
('157','task_created','New Task Assigned','A new task has been created: test',NULL,NULL,NULL,'moajmalnk','2025-12-02 09:04:42','task','19','63fe666d-82e2-4537-83fc-aa778ce17b08'),
('158','bug_fixed','Bug Fixed','Bug \'CBSE\' has been marked as fixed','48dc13d0-e1c1-428d-bfb9-c7da24484a62','CBSE','fixed','moajmalnk','2025-12-02 09:20:22','bug','48dc13d0-e1c1-428d-bfb9-c7da24484a62','63fe666d-82e2-4537-83fc-aa778ce17b08'),
('159','status_change','Bug Status Updated','Bug has been fixed: CBSE','48','CBSE','fixed','BugRicer','2025-12-02 09:20:22',NULL,NULL,NULL),
('160','bug_fixed','Bug Fixed','Bug \'CBSE\' has been marked as fixed','48dc13d0-e1c1-428d-bfb9-c7da24484a62','CBSE','fixed','developer','2025-12-02 09:21:44','bug','48dc13d0-e1c1-428d-bfb9-c7da24484a62','63fe666d-82e2-4537-83fc-aa778ce17b08'),
('161','status_change','Bug Status Updated','Bug has been fixed: CBSE','48','CBSE','fixed','BugRicer','2025-12-02 09:21:44',NULL,NULL,NULL),
('162','bug_fixed','Bug Fixed','Bug \'MOHAMMED AJMAL NK\' has been marked as fixed','1d8ee0a2-0c99-4d46-b988-0bd60daa0079','MOHAMMED AJMAL NK','fixed','moajmalnk','2025-12-06 01:26:15','bug','1d8ee0a2-0c99-4d46-b988-0bd60daa0079','63fe666d-82e2-4537-83fc-aa778ce17b08'),
('163','status_change','Bug Status Updated','Bug has been fixed: MOHAMMED AJMAL NK','1','MOHAMMED AJMAL NK','fixed','BugRicer','2025-12-06 01:26:16',NULL,NULL,NULL),
('164','bug_created','New Bug Reported','A new bug has been reported: MOHAMMED AJMAL NK','599f4a9f-41d6-4446-b4dc-69572ddc5bea','MOHAMMED AJMAL NK',NULL,'moajmalnk','2026-01-02 00:15:10','bug','599f4a9f-41d6-4446-b4dc-69572ddc5bea','63fe666d-82e2-4537-83fc-aa778ce17b08'),
('165','bug_created','New Bug Reported','A new bug has been reported: MOHAMMED AJMAL NK','fdd32ddb-517c-4c01-83f6-97b73cf03d5c','MOHAMMED AJMAL NK',NULL,'moajmalnk','2026-01-02 00:16:31','bug','fdd32ddb-517c-4c01-83f6-97b73cf03d5c','63fe666d-82e2-4537-83fc-aa778ce17b08'),
('166','new_bug','New Bug Reported','A new bug has been reported: MOHAMMED AJMAL NK','0','MOHAMMED AJMAL NK',NULL,'BugRicer','2026-01-02 00:18:17',NULL,NULL,NULL),
('167','new_bug','New Bug Reported','A new bug has been reported: test ajmal','384','test ajmal',NULL,'BugRicer','2026-01-02 00:19:02',NULL,NULL,NULL),
('168','bug_fixed','Bug Fixed','Bug \'test ajmal\' has been marked as fixed','384bc5bb-92d8-4728-a60b-22511d16b13d','test ajmal','fixed','moajmalnk','2026-01-02 01:14:16','bug','384bc5bb-92d8-4728-a60b-22511d16b13d','83f0e57d-6905-49b6-99a4-2b3df2595644'),
('169','status_change','Bug Status Updated','Bug has been fixed: test ajmal','384','test ajmal','fixed','BugRicer','2026-01-02 01:14:22',NULL,NULL,NULL),
('170','bug_fixed','Bug Fixed','Bug \'test ajmal\' has been marked as fixed','384bc5bb-92d8-4728-a60b-22511d16b13d','test ajmal','fixed','moajmalnk','2026-01-02 01:15:43','bug','384bc5bb-92d8-4728-a60b-22511d16b13d','83f0e57d-6905-49b6-99a4-2b3df2595644'),
('171','status_change','Bug Status Updated','Bug has been fixed: test ajmal','384','test ajmal','fixed','BugRicer User','2026-01-02 01:15:48',NULL,NULL,NULL),
('172','bug_fixed','Bug Fixed','Bug \'MOHAMMED AJMAL NK\' has been marked as fixed','a43aa6dc-477a-4568-8ad5-834d78da901a','MOHAMMED AJMAL NK','fixed','moajmalnk','2026-01-02 01:17:13','bug','a43aa6dc-477a-4568-8ad5-834d78da901a','63fe666d-82e2-4537-83fc-aa778ce17b08'),
('173','status_change','Bug Status Updated','Bug has been fixed: MOHAMMED AJMAL NK','0','MOHAMMED AJMAL NK','fixed','BugRicer','2026-01-02 01:17:13',NULL,NULL,NULL),
('174','bug_fixed','Bug Fixed','Bug \'sasas\' has been marked as fixed','9df3b3d0-c9bd-4e49-a796-542f023a7832','sasas','fixed','lubaba','2026-01-02 01:17:49','bug','9df3b3d0-c9bd-4e49-a796-542f023a7832','83f0e57d-6905-49b6-99a4-2b3df2595644'),
('175','status_change','Bug Status Updated','Bug has been fixed: sasas','9','sasas','fixed','BugRicer User','2026-01-02 01:17:54',NULL,NULL,NULL),
('176','bug_fixed','Bug Fixed','Bug \'dsdsd\' has been marked as fixed','2bc23920-c0e4-472a-901c-25c86afc1379','dsdsd','fixed','lubaba','2026-01-02 01:18:00','bug','2bc23920-c0e4-472a-901c-25c86afc1379','63fe666d-82e2-4537-83fc-aa778ce17b08'),
('177','status_change','Bug Status Updated','Bug has been fixed: dsdsd','2','dsdsd','fixed','BugRicer','2026-01-02 01:18:01',NULL,NULL,NULL),
('178','bug_fixed','Bug Fixed','Bug \'MOHAMMED AJMAL NK\' has been marked as fixed','fdd32ddb-517c-4c01-83f6-97b73cf03d5c','MOHAMMED AJMAL NK','fixed','developer','2026-01-02 01:19:59','bug','fdd32ddb-517c-4c01-83f6-97b73cf03d5c','63fe666d-82e2-4537-83fc-aa778ce17b08'),
('179','status_change','Bug Status Updated','Bug has been fixed: MOHAMMED AJMAL NK','0','MOHAMMED AJMAL NK','fixed','BugRicer','2026-01-02 01:19:59',NULL,NULL,NULL),
('180','bug_fixed','Bug Fixed','Bug \'MOHAMMED AJMAL NK\' has been marked as fixed','599f4a9f-41d6-4446-b4dc-69572ddc5bea','MOHAMMED AJMAL NK','fixed','developer','2026-01-02 01:20:48','bug','599f4a9f-41d6-4446-b4dc-69572ddc5bea','63fe666d-82e2-4537-83fc-aa778ce17b08'),
('181','status_change','Bug Status Updated','Bug has been fixed: MOHAMMED AJMAL NK','599','MOHAMMED AJMAL NK','fixed','BugRicer','2026-01-02 01:20:49',NULL,NULL,NULL),
('182','bug_fixed','Bug Fixed','Bug \'MOHAMMED AJMAL NK\' has been marked as fixed','599f4a9f-41d6-4446-b4dc-69572ddc5bea','MOHAMMED AJMAL NK','fixed','developer','2026-01-02 01:21:43','bug','599f4a9f-41d6-4446-b4dc-69572ddc5bea','63fe666d-82e2-4537-83fc-aa778ce17b08'),
('183','status_change','Bug Status Updated','Bug has been fixed: MOHAMMED AJMAL NK','599','MOHAMMED AJMAL NK','fixed','BugRicer User','2026-01-02 01:21:48',NULL,NULL,NULL),
('184','bug_fixed','Bug Fixed','Bug \'b vn\' has been marked as fixed','d51d92e3-3074-4351-b04d-42a4f4a4db1e','b vn','fixed','developer','2026-01-02 01:23:20','bug','d51d92e3-3074-4351-b04d-42a4f4a4db1e','83f0e57d-6905-49b6-99a4-2b3df2595644'),
('185','status_change','Bug Status Updated','Bug has been fixed: b vn','0','b vn','fixed','BugRicer','2026-01-02 01:23:20',NULL,NULL,NULL),
('186','bug_fixed','Bug Fixed','Bug \'Task\' has been marked as fixed','b6739ea3-cccb-40eb-8466-da2758dfe7c5','Task','fixed','developer','2026-01-02 01:25:44','bug','b6739ea3-cccb-40eb-8466-da2758dfe7c5','63fe666d-82e2-4537-83fc-aa778ce17b08'),
('187','status_change','Bug Status Updated','Bug has been fixed: Task','0','Task','fixed','BugRicer','2026-01-02 01:25:44',NULL,NULL,NULL),
('188','bug_fixed','Bug Fixed','Bug \'dwd\' has been marked as fixed','8675a113-7ba5-4667-bb8d-e0356e3a6e1b','dwd','fixed','developer','2026-01-02 01:28:05','bug','8675a113-7ba5-4667-bb8d-e0356e3a6e1b','83f0e57d-6905-49b6-99a4-2b3df2595644'),
('189','status_change','Bug Status Updated','Bug has been fixed: dwd','8675','dwd','fixed','BugRicer','2026-01-02 01:28:05',NULL,NULL,NULL),
('190','bug_fixed','Bug Fixed','Bug \'dwd\' has been marked as fixed','8675a113-7ba5-4667-bb8d-e0356e3a6e1b','dwd','fixed','developer','2026-01-02 01:29:27','bug','8675a113-7ba5-4667-bb8d-e0356e3a6e1b','83f0e57d-6905-49b6-99a4-2b3df2595644'),
('191','status_change','Bug Status Updated','Bug has been fixed: dwd','8675','dwd','fixed','BugRicer','2026-01-02 01:29:27',NULL,NULL,NULL),
('192','new_update','New Update Posted','A new update has been posted: dddd','8700000000','dddd',NULL,'BugRicer','2026-01-02 02:25:06',NULL,NULL,NULL),
('193','new_update','New Update Posted','A new update has been posted: dddddddd','71','dddddddd',NULL,'BugRicer','2026-01-02 02:46:55',NULL,NULL,NULL),
('194','new_update','New Update Posted','A new update has been posted: sdsdsdsdsd','7','sdsdsdsdsd',NULL,'BugRicer','2026-01-02 02:50:46',NULL,NULL,NULL),
('195','new_update','New Update Posted','A new update has been posted: dddddd','500','dddddd',NULL,'BugRicer','2026-01-02 02:53:35',NULL,NULL,NULL),
('196','new_update','New Update Posted','A new update has been posted: dddwww','358','dddwww',NULL,'BugRicer','2026-01-02 02:56:01',NULL,NULL,NULL),
('197','new_update','New Update Posted','A new update has been posted: ddsdsdsddsd','65','ddsdsdsddsd',NULL,'BugRicer','2026-01-02 03:02:01',NULL,NULL,NULL);


-- Table structure for table `password_resets`
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(36) NOT NULL COMMENT 'References users.id (UUID)',
  `email` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  KEY `idx_token` (`token`),
  KEY `idx_email` (`email`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_expires_at` (`expires_at`),
  KEY `idx_used_at` (`used_at`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `password_resets`
INSERT INTO `password_resets` VALUES
('16','608dc9d1-26e0-441d-8144-45f74c53a846','moajmalnk@gmail.com','335dcbd3d030d3dd895b2ace9a99bc35f1c3a4b6232f2b8ff84f603bae2c1040','2025-11-02 13:50:13',NULL,'2025-11-02 17:20:13','2025-11-02 17:20:13'),
('17','608dc9d1-26e0-441d-8144-45f74c53a846','moajmalnk@gmail.com','13cecc34a2148571901aaaedacdd66bafaa2127f902154ee1836e813e207e23d','2025-11-02 13:58:36',NULL,'2025-11-02 17:28:36','2025-11-02 17:28:36'),
('18','608dc9d1-26e0-441d-8144-45f74c53a846','moajmalnk@gmail.com','44e59faa65322699a270921c10fc0d8c5d47697a51f3f1d420423807339d6152','2025-11-02 13:59:00',NULL,'2025-11-02 17:29:00','2025-11-02 17:29:00'),
('19','608dc9d1-26e0-441d-8144-45f74c53a846','moajmalnk@gmail.com','05e20b0181f6626606dac656cb3565a4848afd87ec9f671478e0bd4725ffdaeb','2025-11-02 13:59:33',NULL,'2025-11-02 17:29:33','2025-11-02 17:29:33'),
('20','608dc9d1-26e0-441d-8144-45f74c53a846','moajmalnk@gmail.com','6c94f685cda96fb5fb9b5b446b87522e1d1535b67dff7283f7d0674f539a8adf','2025-11-02 19:58:17',NULL,'2025-11-02 23:28:17','2025-11-02 23:28:17'),
('21','608dc9d1-26e0-441d-8144-45f74c53a846','moajmalnk@gmail.com','a9a7708ced2740c11b7f1e08d24b9c51637bd1989b8e35c3157c6e35168a8442','2025-11-02 20:00:01',NULL,'2025-11-02 23:30:01','2025-11-02 23:30:01'),
('22','608dc9d1-26e0-441d-8144-45f74c53a846','moajmalnk@gmail.com','d127cd91855e77fa9eaec441a60c4dfe4404099398430e1e2731ec29ae633399','2025-11-02 20:00:07',NULL,'2025-11-02 23:30:07','2025-11-02 23:30:07'),
('23','608dc9d1-26e0-441d-8144-45f74c53a846','moajmalnk@gmail.com','c953849bf572e13d4e200a52b9a760d8603c5ddfabd6b91ef2dda3d06e89c52d','2025-11-02 20:01:26',NULL,'2025-11-02 23:31:26','2025-11-02 23:31:26'),
('24','608dc9d1-26e0-441d-8144-45f74c53a846','moajmalnk@gmail.com','29d4ea2c88d9b1e003607d9a538f97eaeee2db99d1dc44597dafb928c3641662','2025-11-02 20:02:33',NULL,'2025-11-02 23:32:33','2025-11-02 23:32:33'),
('25','608dc9d1-26e0-441d-8144-45f74c53a846','moajmalnk@gmail.com','8b33d55b8ab2f44518d679e97290a884f52476decbd785283a5546c4500c6dee','2025-11-02 20:10:12','2025-11-02 18:10:46','2025-11-02 23:40:12','2025-11-02 23:40:46');


-- Table structure for table `permissions`
DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permission_key` varchar(100) NOT NULL,
  `permission_name` varchar(100) NOT NULL,
  `permission_description` text DEFAULT NULL,
  `category` varchar(50) NOT NULL,
  `scope` enum('global','project') NOT NULL DEFAULT 'global',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `permission_key` (`permission_key`),
  KEY `idx_permissions_category` (`category`),
  KEY `idx_permissions_scope` (`scope`),
  KEY `idx_permissions_key` (`permission_key`)
) ENGINE=InnoDB AUTO_INCREMENT=149 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `permissions`
INSERT INTO `permissions` VALUES
('1','BUGS_VIEW_ALL','View All Bugs','View all bugs across all projects','Bugs','global','2025-10-25 17:21:00'),
('2','BUGS_VIEW_OWN','View Own Bugs','View only bugs reported by the user','Bugs','global','2025-10-25 17:21:00'),
('3','BUGS_CREATE','Create Bugs','Create new bug reports','Bugs','global','2025-10-25 17:21:00'),
('4','BUGS_EDIT_ALL','Edit All Bugs','Edit any bug report','Bugs','global','2025-10-25 17:21:00'),
('5','BUGS_EDIT_OWN','Edit Own Bugs','Edit only bugs reported by the user','Bugs','global','2025-10-25 17:21:00'),
('6','BUGS_DELETE','Delete Bugs','Delete bug reports','Bugs','global','2025-10-25 17:21:00'),
('7','BUGS_CHANGE_STATUS','Change Bug Status','Update bug status (pending, in_progress, fixed, etc.)','Bugs','global','2025-10-25 17:21:00'),
('8','BUGS_ASSIGN','Assign Bugs','Assign bugs to other users','Bugs','global','2025-10-25 17:21:00'),
('9','USERS_VIEW','View Users','View user list and details','Users','global','2025-10-25 17:21:00'),
('10','USERS_CREATE','Create Users','Create new user accounts','Users','global','2025-10-25 17:21:00'),
('11','USERS_EDIT','Edit Users','Edit user information','Users','global','2025-10-25 17:21:00'),
('12','USERS_DELETE','Delete Users','Delete user accounts','Users','global','2025-10-25 17:21:00'),
('13','USERS_CHANGE_PASSWORD','Change User Passwords','Reset or change user passwords','Users','global','2025-10-25 17:21:00'),
('14','USERS_MANAGE_PERMISSIONS','Manage User Permissions','Assign and modify user permissions','Users','global','2025-10-25 17:21:00'),
('15','USERS_IMPERSONATE','Impersonate Users','Login as another user for support','Users','global','2025-10-25 17:21:00'),
('16','PROJECTS_VIEW_ALL','View All Projects','View all projects in the system','Projects','global','2025-10-25 17:21:00'),
('17','PROJECTS_VIEW_ASSIGNED','View Assigned Projects','View only projects where user is a member','Projects','global','2025-10-25 17:21:00'),
('18','PROJECTS_CREATE','Create Projects','Create new projects','Projects','global','2025-10-25 17:21:00'),
('19','PROJECTS_EDIT','Edit Projects','Edit project information','Projects','global','2025-10-25 17:21:00'),
('20','PROJECTS_DELETE','Delete Projects','Delete projects','Projects','global','2025-10-25 17:21:00'),
('21','PROJECTS_MANAGE_MEMBERS','Manage Project Members','Add/remove members from projects','Projects','global','2025-10-25 17:21:00'),
('22','PROJECTS_ARCHIVE','Archive Projects','Archive or unarchive projects','Projects','global','2025-10-25 17:21:00'),
('23','DOCS_VIEW','View Documentation','View project documentation','Documentation','global','2025-10-25 17:21:00'),
('24','DOCS_CREATE','Create Documentation','Create new documentation','Documentation','global','2025-10-25 17:21:00'),
('25','DOCS_EDIT','Edit Documentation','Edit existing documentation','Documentation','global','2025-10-25 17:21:00'),
('26','DOCS_DELETE','Delete Documentation','Delete documentation','Documentation','global','2025-10-25 17:21:00'),
('27','TASKS_VIEW_ALL','View All Tasks','View all tasks across all projects','Tasks','global','2025-10-25 17:21:00'),
('28','TASKS_VIEW_ASSIGNED','View Assigned Tasks','View only tasks assigned to the user','Tasks','global','2025-10-25 17:21:00'),
('29','TASKS_CREATE','Create Tasks','Create new tasks','Tasks','global','2025-10-25 17:21:00'),
('30','TASKS_EDIT','Edit Tasks','Edit task information','Tasks','global','2025-10-25 17:21:00'),
('31','TASKS_DELETE','Delete Tasks','Delete tasks','Tasks','global','2025-10-25 17:21:00'),
('32','TASKS_ASSIGN','Assign Tasks','Assign tasks to users','Tasks','global','2025-10-25 17:21:00'),
('33','UPDATES_VIEW','View Updates','View project updates and changelogs','Updates','global','2025-10-25 17:21:00'),
('34','UPDATES_CREATE','Create Updates','Create new project updates','Updates','global','2025-10-25 17:21:00'),
('35','UPDATES_EDIT','Edit Updates','Edit existing updates','Updates','global','2025-10-25 17:21:00'),
('36','UPDATES_DELETE','Delete Updates','Delete updates','Updates','global','2025-10-25 17:21:00'),
('37','UPDATES_APPROVE','Approve Updates','Approve or reject update requests','Updates','global','2025-10-25 17:21:00'),
('38','SETTINGS_VIEW','View Settings','View application settings','Settings','global','2025-10-25 17:21:00'),
('39','SETTINGS_EDIT','Edit Settings','Modify application settings','Settings','global','2025-10-25 17:21:00'),
('40','ROLES_MANAGE','Manage Roles','Create, edit, and delete custom roles','Settings','global','2025-10-25 17:21:00'),
('41','ANNOUNCEMENTS_MANAGE','Manage Announcements','Create and manage system announcements','Settings','global','2025-10-25 17:21:00'),
('42','MESSAGING_VIEW','View Messages','View chat messages and conversations','Messaging','global','2025-10-25 17:21:00'),
('43','MESSAGING_SEND','Send Messages','Send messages in chat groups','Messaging','global','2025-10-25 17:21:00'),
('44','MESSAGING_DELETE','Delete Messages','Delete chat messages','Messaging','global','2025-10-25 17:21:00'),
('45','MESSAGING_MANAGE_GROUPS','Manage Chat Groups','Create and manage chat groups','Messaging','global','2025-10-25 17:21:00'),
('46','MEETINGS_CREATE','Create Meetings','Create new meetings','Meetings','global','2025-10-25 17:21:00'),
('47','MEETINGS_JOIN','Join Meetings','Join existing meetings','Meetings','global','2025-10-25 17:21:00'),
('48','MEETINGS_MANAGE','Manage Meetings','Manage meeting settings and participants','Meetings','global','2025-10-25 17:21:00'),
('49','SUPER_ADMIN','Super Administrator','Bypass all permission checks - full system access','System','global','2025-10-25 17:21:00');


-- Table structure for table `poll_options`
DROP TABLE IF EXISTS `poll_options`;
CREATE TABLE `poll_options` (
  `id` varchar(36) NOT NULL,
  `poll_id` varchar(36) NOT NULL,
  `option_text` varchar(255) NOT NULL,
  `option_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_poll_options_poll` (`poll_id`),
  CONSTRAINT `poll_options_ibfk_1` FOREIGN KEY (`poll_id`) REFERENCES `message_polls` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for table `poll_votes`
DROP TABLE IF EXISTS `poll_votes`;
CREATE TABLE `poll_votes` (
  `id` varchar(36) NOT NULL,
  `poll_id` varchar(36) NOT NULL,
  `option_id` varchar(36) NOT NULL,
  `user_id` varchar(36) NOT NULL,
  `voted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_poll_votes_poll` (`poll_id`),
  KEY `idx_poll_votes_option` (`option_id`),
  KEY `idx_poll_votes_user` (`user_id`),
  CONSTRAINT `poll_votes_ibfk_1` FOREIGN KEY (`poll_id`) REFERENCES `message_polls` (`id`) ON DELETE CASCADE,
  CONSTRAINT `poll_votes_ibfk_2` FOREIGN KEY (`option_id`) REFERENCES `poll_options` (`id`) ON DELETE CASCADE,
  CONSTRAINT `poll_votes_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for table `project_activities`
DROP TABLE IF EXISTS `project_activities`;
CREATE TABLE `project_activities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(255) NOT NULL COMMENT 'References users.id',
  `project_id` varchar(36) DEFAULT NULL,
  `activity_type` varchar(50) NOT NULL COMMENT 'Type of activity (bug_reported, member_added, etc.)',
  `description` text NOT NULL COMMENT 'Human-readable description of the activity',
  `related_id` varchar(255) DEFAULT NULL COMMENT 'Optional reference to related entity (bug, task, etc.)',
  `metadata` text DEFAULT NULL COMMENT 'JSON metadata for additional activity context',
  `created_at` timestamp NULL DEFAULT current_timestamp() COMMENT 'When the activity occurred',
  PRIMARY KEY (`id`),
  KEY `pa_project_id` (`project_id`),
  KEY `pa_user_id` (`user_id`),
  KEY `pa_activity_type` (`activity_type`),
  KEY `pa_created_at` (`created_at`),
  KEY `pa_related_id` (`related_id`),
  KEY `pa_project_created` (`project_id`,`created_at`),
  KEY `pa_user_created` (`user_id`,`created_at`),
  KEY `idx_project_activities_project_user` (`project_id`,`user_id`),
  KEY `idx_project_activities_type_created` (`activity_type`,`created_at`),
  KEY `idx_project_activities_related` (`related_id`),
  KEY `idx_project_activities_project_id` (`project_id`),
  KEY `idx_project_activities_type` (`activity_type`),
  KEY `idx_project_activities_created_at` (`created_at`),
  KEY `idx_project_activities_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=875 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `project_activities`
INSERT INTO `project_activities` VALUES
('753','32f9e3be-4029-486a-a1e0-9ba62f97bd99',NULL,'feedback_created','Feedback created: User Feedback (Rating: 5)','15ddbf00-04e5-48a2-9acb-3017f6f6e57b','{\"rating\":5,\"has_text\":false,\"action\":\"create\"}','2025-11-02 16:46:45'),
('754','608dc9d1-26e0-441d-8144-45f74c53a846',NULL,'feedback_created','Feedback created: User Feedback (Rating: 5)','fa8688d2-dc47-4332-9226-5feffa3c4460','{\"rating\":5,\"has_text\":true,\"action\":\"create\"}','2025-11-02 18:34:50'),
('755','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','project_created','Project created: Albedo Educator','83f0e57d-6905-49b6-99a4-2b3df2595644','{\"description\":\"Albedo Educator\",\"status\":\"active\",\"action\":\"create\"}','2025-11-02 18:35:13'),
('756','608dc9d1-26e0-441d-8144-45f74c53a846','291c8841-94a5-4cdb-9eb8-fef40709aee5','project_created','Project created: Albedo Calc','291c8841-94a5-4cdb-9eb8-fef40709aee5','{\"description\":\"Albedo Educator\",\"status\":\"active\",\"action\":\"create\"}','2025-11-02 18:35:22'),
('757','608dc9d1-26e0-441d-8144-45f74c53a846','a5dd0abd-b5cc-43ff-a22e-652e30ab7d28','project_created','Project created: Albedo Web','a5dd0abd-b5cc-43ff-a22e-652e30ab7d28','{\"description\":\"Albedo Educator\",\"status\":\"active\",\"action\":\"create\"}','2025-11-02 18:35:37'),
('758','608dc9d1-26e0-441d-8144-45f74c53a846','63fe666d-82e2-4537-83fc-aa778ce17b08','project_created','Project created: MedocSuite','63fe666d-82e2-4537-83fc-aa778ce17b08','{\"description\":\"MedocSuite\",\"status\":\"active\",\"action\":\"create\"}','2025-11-02 18:35:59'),
('759','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','member_added','added developer to the project',NULL,'{\"member_username\":\"developer\",\"role\":\"developer\"}','2025-11-02 21:31:30'),
('760','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','member_added','added tester to the project',NULL,'{\"member_username\":\"tester\",\"role\":\"tester\"}','2025-11-02 21:31:34'),
('761','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','member_added','added codoaiinnovations to the project',NULL,'{\"member_username\":\"codoaiinnovations\",\"role\":\"tester\"}','2025-11-02 21:31:37'),
('762','d84019a3-575f-403c-aa12-02482422bcfa','83f0e57d-6905-49b6-99a4-2b3df2595644','update_created','Update created: Testing','6d575450-8f13-4205-ab49-6e3b96ed1853','{\"type\":\"maintenance\",\"description\":\"Demo...\",\"action\":\"create\"}','2025-11-02 22:11:23'),
('763','d84019a3-575f-403c-aa12-02482422bcfa',NULL,'feedback_created','Feedback created: User Feedback (Rating: 5)','d7a4d6ad-a1c2-4863-9a7c-3c7e851f307f','{\"rating\":5,\"has_text\":true,\"action\":\"create\"}','2025-11-02 23:00:05'),
('764','d84019a3-575f-403c-aa12-02482422bcfa',NULL,'user_updated','User updated: developer','d84019a3-575f-403c-aa12-02482422bcfa','{\"updated_fields\":[\"id\",\"username\",\"email\",\"role\",\"role_id\",\"phone\"],\"role\":\"developer\",\"action\":\"update\",\"username\":\"developer\"}','2025-11-02 23:53:50'),
('765','d84019a3-575f-403c-aa12-02482422bcfa',NULL,'user_updated','User updated: developer','d84019a3-575f-403c-aa12-02482422bcfa','{\"updated_fields\":[\"id\",\"username\",\"email\",\"phone\",\"role\",\"role_id\",\"created_at\",\"updated_at\",\"last_active_at\",\"status\",\"name\",\"avatar\"],\"role\":\"developer\",\"action\":\"update\",\"username\":\"developer\"}','2025-11-02 23:53:50'),
('766','c18ce191-e34b-4ca7-b69b-6a78488d3de5',NULL,'user_updated','User updated: tester','c18ce191-e34b-4ca7-b69b-6a78488d3de5','{\"updated_fields\":[\"id\",\"username\",\"email\",\"role\",\"role_id\",\"phone\"],\"role\":\"tester\",\"action\":\"update\",\"username\":\"tester\"}','2025-11-02 23:54:08'),
('767','c18ce191-e34b-4ca7-b69b-6a78488d3de5',NULL,'user_updated','User updated: tester','c18ce191-e34b-4ca7-b69b-6a78488d3de5','{\"updated_fields\":[\"id\",\"username\",\"email\",\"phone\",\"role\",\"role_id\",\"created_at\",\"updated_at\",\"last_active_at\",\"status\",\"name\",\"avatar\"],\"role\":\"tester\",\"action\":\"update\",\"username\":\"tester\"}','2025-11-02 23:54:08'),
('768','e1e7aecc-96f9-452b-b60c-e9541c27ea3d',NULL,'user_created','User created: dev','e1e7aecc-96f9-452b-b60c-e9541c27ea3d','{\"email\":\"ajmalnk04@gmail.com\",\"role\":\"developer\",\"phone\":\"+919526272123\",\"action\":\"create\",\"username\":\"dev\"}','2025-11-03 00:14:52'),
('769','e1e7aecc-96f9-452b-b60c-e9541c27ea3d',NULL,'feedback_created','Feedback created: User Feedback (Rating: 5)','ac18051c-d454-41cf-95b4-6cba1c8d06a1','{\"rating\":5,\"has_text\":false,\"action\":\"create\"}','2025-11-03 00:19:32'),
('770','c18ce191-e34b-4ca7-b69b-6a78488d3de5',NULL,'feedback_created','Feedback created: User Feedback (Rating: 5)','12157b83-b051-4c20-aaa1-4b07901fec87','{\"rating\":5,\"has_text\":true,\"action\":\"create\"}','2025-11-03 00:23:42'),
('771','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: Sample','f720776c-62cc-4c52-92ed-3311ba1d992d','{\"priority\":\"high\",\"status\":\"fixed\",\"updated_fields\":[\"id\",\"title\",\"description\",\"expected_result\",\"actual_result\",\"fix_description\",\"project_id\",\"reported_by\",\"priority\",\"status\",\"created_at\",\"updated_at\",\"updated_by\",\"fixed_by\",\"project_name\",\"reporter_name\",\"updated_by_name\",\"fixed_by_name\",\"attachments\",\"screenshots\",\"files\"],\"action\":\"update\"}','2025-11-03 00:26:20'),
('772','608dc9d1-26e0-441d-8144-45f74c53a846',NULL,'bug_updated','Bug updated: ','78eebeb4-2fbc-419d-b7d2-5e652c80905d','{\"priority\":null,\"status\":\"fixed\",\"updated_fields\":[\"id\",\"status\",\"fix_description\",\"fixed_by\",\"updated_by\"],\"action\":\"update\"}','2025-11-03 00:26:26'),
('773','c18ce191-e34b-4ca7-b69b-6a78488d3de5','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: Mobile App Design','3d06eb74-e7a9-471c-862f-a2922fed012b','{\"priority\":\"high\",\"status\":\"pending\",\"action\":\"update\"}','2025-11-03 00:27:15'),
('774','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: Mobile App Designdsdsd','3d06eb74-e7a9-471c-862f-a2922fed012b','{\"priority\":\"high\",\"status\":\"pending\",\"updated_fields\":[\"id\",\"title\",\"description\",\"expected_result\",\"actual_result\",\"priority\",\"status\",\"project_id\",\"updated_by\"],\"action\":\"update\"}','2025-11-03 00:27:41'),
('775','c18ce191-e34b-4ca7-b69b-6a78488d3de5','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: Mobile App Designdsdsd','3d06eb74-e7a9-471c-862f-a2922fed012b','{\"priority\":\"high\",\"status\":\"pending\",\"action\":\"update\"}','2025-11-03 00:27:59'),
('776','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_deleted','Bug deleted: Sample','f720776c-62cc-4c52-92ed-3311ba1d992d','{\"attachments_count\":0,\"deleted_by_role\":\"admin\",\"action\":\"delete\"}','2025-11-03 00:58:50'),
('777','f78f9246-48e3-4a9d-a5fb-1b70d4bc7d68',NULL,'user_created','User created: aju','f78f9246-48e3-4a9d-a5fb-1b70d4bc7d68','{\"email\":\"premium.codomail@gmail.com\",\"role\":\"developer\",\"phone\":\"+918590961281\",\"action\":\"create\",\"username\":\"aju\"}','2025-11-03 01:17:45'),
('778','608dc9d1-26e0-441d-8144-45f74c53a846',NULL,'task_updated','Task updated: Task','12','{\"updated_fields\":[\"id\",\"status\"],\"priority\":null,\"status\":\"done\",\"action\":\"update\"}','2025-11-03 01:28:18'),
('779','e1e7aecc-96f9-452b-b60c-e9541c27ea3d',NULL,'task_updated','Task updated: Task','13','{\"updated_fields\":[\"id\",\"status\"],\"priority\":null,\"status\":\"done\",\"action\":\"update\"}','2025-11-03 01:47:17'),
('780','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: Mobile App Designdsdsd','3d06eb74-e7a9-471c-862f-a2922fed012b','{\"priority\":\"high\",\"status\":\"fixed\",\"updated_fields\":[\"id\",\"status\",\"fix_description\",\"fixed_by\",\"updated_by\"],\"action\":\"update\"}','2025-11-03 10:27:16'),
('781','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','update_created','Update created: demo','3fd21fb0-b608-4d73-ba4c-9383f682c221','{\"type\":\"feature\",\"description\":\"dsdsd...\",\"action\":\"create\"}','2025-11-03 10:27:45'),
('782','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','update_created','Update created: ddd','98b63287-9c08-4990-a06e-2bb6fe1ae918','{\"type\":\"updation\",\"description\":\"ddd...\",\"action\":\"create\"}','2025-11-03 10:29:52'),
('783','608dc9d1-26e0-441d-8144-45f74c53a846','63fe666d-82e2-4537-83fc-aa778ce17b08','update_created','Update created: ddd','8aad920e-687a-4647-837c-4890ea4cb23f','{\"type\":\"maintenance\",\"description\":\"dd...\",\"action\":\"create\"}','2025-11-03 10:37:38'),
('784','608dc9d1-26e0-441d-8144-45f74c53a846','63fe666d-82e2-4537-83fc-aa778ce17b08','update_created','Update created: ddd','2548d2dc-78f2-48f0-956e-8be15f60231d','{\"type\":\"maintenance\",\"description\":\"ddd...\",\"action\":\"create\"}','2025-11-03 10:39:33'),
('785','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','update_created','Update created: ddd','cb5eef4a-993e-4e1b-bf37-cb881176f139','{\"type\":\"updation\",\"description\":\"ddd...\",\"action\":\"create\"}','2025-11-03 10:40:37'),
('786','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','update_created','Update created: sdsd','ef69e245-8d3a-4597-b8b0-d3fb30ef654e','{\"type\":\"updation\",\"description\":\"sdsdsd...\",\"action\":\"create\"}','2025-11-03 10:43:12'),
('787','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','update_created','Update created: dddd','bc48ed33-963e-46ce-8478-28daa4d091bf','{\"type\":\"updation\",\"description\":\"ddd...\",\"action\":\"create\"}','2025-11-03 10:46:13'),
('788','3045985b-50f9-44e5-9adf-bc6879945272',NULL,'user_created','User created: moajmalnk22','3045985b-50f9-44e5-9adf-bc6879945272','{\"email\":\"ajmalnk10091@gmail.com\",\"role\":\"admin\",\"phone\":\"+919526272223\",\"action\":\"create\",\"username\":\"moajmalnk22\"}','2025-11-03 10:58:37'),
('789','d84019a3-575f-403c-aa12-02482422bcfa','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: dwd','8675a113-7ba5-4667-bb8d-e0356e3a6e1b','{\"priority\":\"medium\",\"status\":\"fixed\",\"updated_fields\":[\"id\",\"title\",\"description\",\"expected_result\",\"actual_result\",\"fix_description\",\"project_id\",\"reported_by\",\"priority\",\"status\",\"created_at\",\"updated_at\",\"updated_by\",\"fixed_by\",\"project_name\",\"reporter_name\",\"updated_by_name\",\"fixed_by_name\",\"attachments\",\"screenshots\",\"files\"],\"action\":\"update\"}','2025-11-03 23:49:07'),
('790','3045985b-50f9-44e5-9adf-bc6879945272','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: Demo','34383982-31ab-44fb-bed2-cb4d4240154a','{\"priority\":\"medium\",\"status\":\"pending\",\"action\":\"update\"}','2025-11-04 01:27:23'),
('791','3045985b-50f9-44e5-9adf-bc6879945272','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: Demo','34383982-31ab-44fb-bed2-cb4d4240154a','{\"priority\":\"medium\",\"status\":\"pending\",\"action\":\"update\"}','2025-11-04 01:29:38'),
('792','3045985b-50f9-44e5-9adf-bc6879945272','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: Demo','34383982-31ab-44fb-bed2-cb4d4240154a','{\"priority\":\"medium\",\"status\":\"pending\",\"action\":\"update\"}','2025-11-04 01:30:42'),
('793','3045985b-50f9-44e5-9adf-bc6879945272','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: Demo','34383982-31ab-44fb-bed2-cb4d4240154a','{\"priority\":\"medium\",\"status\":\"fixed\",\"updated_fields\":[\"id\",\"status\",\"fix_description\",\"fixed_by\",\"updated_by\"],\"action\":\"update\"}','2025-11-04 01:33:11'),
('794','3045985b-50f9-44e5-9adf-bc6879945272','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: Demo','34383982-31ab-44fb-bed2-cb4d4240154a','{\"priority\":\"medium\",\"status\":\"fixed\",\"action\":\"update\"}','2025-11-04 01:34:18'),
('795','3045985b-50f9-44e5-9adf-bc6879945272','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: Demo','34383982-31ab-44fb-bed2-cb4d4240154a','{\"priority\":\"medium\",\"status\":\"fixed\",\"action\":\"update\"}','2025-11-04 01:35:05'),
('796','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: dwd','8675a113-7ba5-4667-bb8d-e0356e3a6e1b','{\"priority\":\"medium\",\"status\":\"pending\",\"updated_fields\":[\"id\",\"title\",\"description\",\"expected_result\",\"actual_result\",\"fix_description\",\"project_id\",\"reported_by\",\"priority\",\"status\",\"created_at\",\"updated_at\",\"updated_by\",\"project_name\",\"reporter_name\",\"updated_by_name\",\"fixed_by_name\",\"attachments\",\"screenshots\",\"files\"],\"action\":\"update\"}','2025-11-04 01:37:26'),
('797','608dc9d1-26e0-441d-8144-45f74c53a846','63fe666d-82e2-4537-83fc-aa778ce17b08','bug_updated','Bug updated: Task','b6739ea3-cccb-40eb-8466-da2758dfe7c5','{\"priority\":\"medium\",\"status\":\"pending\",\"action\":\"update\"}','2025-11-04 01:43:09'),
('798','608dc9d1-26e0-441d-8144-45f74c53a846','63fe666d-82e2-4537-83fc-aa778ce17b08','bug_updated','Bug updated: Task','b6739ea3-cccb-40eb-8466-da2758dfe7c5','{\"priority\":\"medium\",\"status\":\"pending\",\"action\":\"update\"}','2025-11-04 01:44:50'),
('799','608dc9d1-26e0-441d-8144-45f74c53a846','63fe666d-82e2-4537-83fc-aa778ce17b08','bug_updated','Bug updated: Task','b6739ea3-cccb-40eb-8466-da2758dfe7c5','{\"priority\":\"medium\",\"status\":\"pending\",\"action\":\"update\"}','2025-11-04 01:45:40'),
('800','608dc9d1-26e0-441d-8144-45f74c53a846','63fe666d-82e2-4537-83fc-aa778ce17b08','bug_updated','Bug updated: Task','b6739ea3-cccb-40eb-8466-da2758dfe7c5','{\"priority\":\"medium\",\"status\":\"pending\",\"action\":\"update\"}','2025-11-04 01:47:17'),
('801','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: sasas','9df3b3d0-c9bd-4e49-a796-542f023a7832','{\"priority\":\"medium\",\"status\":\"pending\",\"updated_fields\":[\"id\",\"title\",\"description\",\"expected_result\",\"actual_result\",\"priority\",\"status\",\"project_id\",\"screenshots\",\"files\",\"voice_notes\",\"updated_by\"],\"action\":\"update\"}','2025-11-04 01:52:37'),
('802','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: sasas','9df3b3d0-c9bd-4e49-a796-542f023a7832','{\"priority\":\"medium\",\"status\":\"pending\",\"action\":\"update\"}','2025-11-04 01:56:49'),
('803','608dc9d1-26e0-441d-8144-45f74c53a846','63fe666d-82e2-4537-83fc-aa778ce17b08','bug_updated','Bug updated: dsdsd','2bc23920-c0e4-472a-901c-25c86afc1379','{\"priority\":\"medium\",\"status\":\"in_progress\",\"updated_fields\":[\"id\",\"title\",\"description\",\"expected_result\",\"actual_result\",\"fix_description\",\"project_id\",\"reported_by\",\"priority\",\"status\",\"created_at\",\"updated_at\",\"updated_by\",\"project_name\",\"reporter_name\",\"updated_by_name\",\"fixed_by_name\",\"attachments\",\"screenshots\",\"files\",\"_debug\"],\"action\":\"update\"}','2025-11-05 21:39:34'),
('804','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: b vn','d51d92e3-3074-4351-b04d-42a4f4a4db1e','{\"priority\":\"medium\",\"status\":\"pending\",\"action\":\"update\"}','2025-11-09 19:47:45'),
('805','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: sasas','9df3b3d0-c9bd-4e49-a796-542f023a7832','{\"priority\":\"medium\",\"status\":\"pending\",\"action\":\"update\"}','2025-12-01 19:41:52'),
('806','608dc9d1-26e0-441d-8144-45f74c53a846',NULL,'user_updated','User updated: moajmalnk','608dc9d1-26e0-441d-8144-45f74c53a846','{\"updated_fields\":[\"id\",\"username\",\"email\",\"role\",\"role_id\",\"phone\"],\"role\":\"admin\",\"action\":\"update\",\"username\":\"moajmalnk\"}','2025-12-01 23:56:33'),
('807','608dc9d1-26e0-441d-8144-45f74c53a846',NULL,'user_updated','User updated: moajmalnk','608dc9d1-26e0-441d-8144-45f74c53a846','{\"updated_fields\":[\"id\",\"username\",\"email\",\"phone\",\"role\",\"role_id\",\"created_at\",\"updated_at\",\"last_active_at\",\"status\",\"name\",\"avatar\"],\"role\":\"admin\",\"action\":\"update\",\"username\":\"moajmalnk\"}','2025-12-01 23:56:33'),
('808','3045985b-50f9-44e5-9adf-bc6879945272',NULL,'user_updated','User updated: moajmalnk22','3045985b-50f9-44e5-9adf-bc6879945272','{\"updated_fields\":[\"id\",\"username\",\"email\",\"role\",\"role_id\",\"phone\"],\"role\":\"admin\",\"action\":\"update\",\"username\":\"moajmalnk22\"}','2025-12-01 23:56:48'),
('809','3045985b-50f9-44e5-9adf-bc6879945272',NULL,'user_updated','User updated: moajmalnk22','3045985b-50f9-44e5-9adf-bc6879945272','{\"updated_fields\":[\"id\",\"username\",\"email\",\"phone\",\"role\",\"role_id\",\"created_at\",\"updated_at\",\"last_active_at\",\"status\",\"name\",\"avatar\"],\"role\":\"admin\",\"action\":\"update\",\"username\":\"moajmalnk22\"}','2025-12-01 23:56:48'),
('810','d84019a3-575f-403c-aa12-02482422bcfa',NULL,'user_updated','User updated: developer','d84019a3-575f-403c-aa12-02482422bcfa','{\"updated_fields\":[\"id\",\"username\",\"email\",\"role\",\"role_id\",\"phone\"],\"role\":\"developer\",\"action\":\"update\",\"username\":\"developer\"}','2025-12-01 23:58:09'),
('811','d84019a3-575f-403c-aa12-02482422bcfa',NULL,'user_updated','User updated: developer','d84019a3-575f-403c-aa12-02482422bcfa','{\"updated_fields\":[\"id\",\"username\",\"email\",\"phone\",\"role\",\"role_id\",\"created_at\",\"updated_at\",\"last_active_at\",\"status\",\"name\",\"avatar\"],\"role\":\"developer\",\"action\":\"update\",\"username\":\"developer\"}','2025-12-01 23:58:09'),
('812','608dc9d1-26e0-441d-8144-45f74c53a846','63fe666d-82e2-4537-83fc-aa778ce17b08','member_added','added developer to the project',NULL,'{\"member_username\":\"developer\",\"role\":\"developer\"}','2025-12-02 00:39:04'),
('813','608dc9d1-26e0-441d-8144-45f74c53a846','63fe666d-82e2-4537-83fc-aa778ce17b08','update_created','Update created: test','23226f53-0e92-4d32-b146-571b987761b0','{\"type\":\"feature\",\"description\":\"test...\",\"action\":\"create\"}','2025-12-02 00:39:20'),
('814','f78f9246-48e3-4a9d-a5fb-1b70d4bc7d68',NULL,'user_updated','User updated: aju','f78f9246-48e3-4a9d-a5fb-1b70d4bc7d68','{\"updated_fields\":[\"id\",\"username\",\"email\",\"role\",\"role_id\",\"phone\"],\"role\":\"admin\",\"action\":\"update\",\"username\":\"aju\"}','2025-12-02 01:18:15'),
('815','f78f9246-48e3-4a9d-a5fb-1b70d4bc7d68',NULL,'user_updated','User updated: aju','f78f9246-48e3-4a9d-a5fb-1b70d4bc7d68','{\"updated_fields\":[\"id\",\"username\",\"email\",\"phone\",\"role\",\"role_id\",\"created_at\",\"updated_at\",\"last_active_at\",\"status\",\"name\",\"avatar\"],\"role\":\"admin\",\"action\":\"update\",\"username\":\"aju\"}','2025-12-02 01:18:15'),
('816','f78f9246-48e3-4a9d-a5fb-1b70d4bc7d68',NULL,'user_updated','User updated: aju','f78f9246-48e3-4a9d-a5fb-1b70d4bc7d68','{\"updated_fields\":[\"id\",\"username\",\"email\",\"role\",\"role_id\",\"phone\"],\"role\":\"admin\",\"action\":\"update\",\"username\":\"aju\"}','2025-12-02 01:20:42'),
('817','f78f9246-48e3-4a9d-a5fb-1b70d4bc7d68',NULL,'user_updated','User updated: aju','f78f9246-48e3-4a9d-a5fb-1b70d4bc7d68','{\"updated_fields\":[\"id\",\"username\",\"email\",\"phone\",\"role\",\"role_id\",\"created_at\",\"updated_at\",\"last_active_at\",\"status\",\"name\",\"avatar\"],\"role\":\"admin\",\"action\":\"update\",\"username\":\"aju\"}','2025-12-02 01:20:42'),
('818','f78f9246-48e3-4a9d-a5fb-1b70d4bc7d68',NULL,'user_updated','User updated: aju','f78f9246-48e3-4a9d-a5fb-1b70d4bc7d68','{\"updated_fields\":[\"id\",\"username\",\"email\",\"role\",\"role_id\",\"phone\"],\"role\":\"marketer\",\"action\":\"update\",\"username\":\"aju\"}','2025-12-02 01:20:56'),
('819','f78f9246-48e3-4a9d-a5fb-1b70d4bc7d68',NULL,'user_updated','User updated: aju','f78f9246-48e3-4a9d-a5fb-1b70d4bc7d68','{\"updated_fields\":[\"id\",\"username\",\"email\",\"phone\",\"role\",\"role_id\",\"created_at\",\"updated_at\",\"last_active_at\",\"status\",\"name\",\"avatar\"],\"role\":\"user\",\"action\":\"update\",\"username\":\"aju\"}','2025-12-02 01:20:56'),
('820','608dc9d1-26e0-441d-8144-45f74c53a846',NULL,'user_updated','User updated: moajmalnk','608dc9d1-26e0-441d-8144-45f74c53a846','{\"updated_fields\":[\"id\",\"username\",\"email\",\"role\",\"role_id\",\"phone\"],\"role\":\"admin\",\"action\":\"update\",\"username\":\"moajmalnk\"}','2025-12-02 01:21:29'),
('821','608dc9d1-26e0-441d-8144-45f74c53a846',NULL,'user_updated','User updated: moajmalnk','608dc9d1-26e0-441d-8144-45f74c53a846','{\"updated_fields\":[\"id\",\"username\",\"email\",\"phone\",\"role\",\"role_id\",\"created_at\",\"updated_at\",\"last_active_at\",\"status\",\"name\",\"avatar\"],\"role\":\"admin\",\"action\":\"update\",\"username\":\"moajmalnk\"}','2025-12-02 01:21:29'),
('822','608dc9d1-26e0-441d-8144-45f74c53a846','63fe666d-82e2-4537-83fc-aa778ce17b08','member_removed','removed developer from the project',NULL,'{\"member_username\":\"developer\",\"role\":\"developer\"}','2025-12-02 01:22:29'),
('823','cd95cbc1-be9d-44aa-b357-5cc67400c95d',NULL,'user_created','User created: example','cd95cbc1-be9d-44aa-b357-5cc67400c95d','{\"email\":\"info.ajmalnsk@gmail.com\",\"role\":\"admin\",\"phone\":\"+918848676627\",\"action\":\"create\",\"username\":\"example\"}','2025-12-02 01:25:27'),
('824','608dc9d1-26e0-441d-8144-45f74c53a846','63fe666d-82e2-4537-83fc-aa778ce17b08','member_added','added developer to the project',NULL,'{\"member_username\":\"developer\",\"role\":\"developer\"}','2025-12-02 01:33:17'),
('825','cd95cbc1-be9d-44aa-b357-5cc67400c95d',NULL,'user_updated','User updated: example','cd95cbc1-be9d-44aa-b357-5cc67400c95d','{\"updated_fields\":[\"id\",\"username\",\"email\",\"role\",\"role_id\",\"phone\"],\"role\":\"developer\",\"action\":\"update\",\"username\":\"example\"}','2025-12-02 01:37:19'),
('826','cd95cbc1-be9d-44aa-b357-5cc67400c95d',NULL,'user_updated','User updated: example','cd95cbc1-be9d-44aa-b357-5cc67400c95d','{\"updated_fields\":[\"id\",\"username\",\"email\",\"phone\",\"role\",\"role_id\",\"created_at\",\"updated_at\",\"last_active_at\",\"status\",\"name\",\"avatar\"],\"role\":\"developer\",\"action\":\"update\",\"username\":\"example\"}','2025-12-02 01:37:19'),
('827','436f9705-5c13-4f8c-934a-65bff6693885',NULL,'user_created','User created: lubaba','436f9705-5c13-4f8c-934a-65bff6693885','{\"email\":\"info.ajsmalnk@gmail.com\",\"role\":\"admin\",\"phone\":\"+918848676627\",\"action\":\"create\",\"username\":\"lubaba\"}','2025-12-02 01:37:40'),
('828','436f9705-5c13-4f8c-934a-65bff6693885',NULL,'user_updated','User updated: lubaba','436f9705-5c13-4f8c-934a-65bff6693885','{\"updated_fields\":[\"id\",\"username\",\"email\",\"role\",\"role_id\",\"phone\"],\"role\":\"developer\",\"action\":\"update\",\"username\":\"lubaba\"}','2025-12-02 01:42:09'),
('829','436f9705-5c13-4f8c-934a-65bff6693885',NULL,'user_updated','User updated: lubaba','436f9705-5c13-4f8c-934a-65bff6693885','{\"updated_fields\":[\"id\",\"username\",\"email\",\"phone\",\"role\",\"role_id\",\"created_at\",\"updated_at\",\"last_active_at\",\"status\",\"name\",\"avatar\"],\"role\":\"developer\",\"action\":\"update\",\"username\":\"lubaba\"}','2025-12-02 01:42:09'),
('830','608dc9d1-26e0-441d-8144-45f74c53a846','63fe666d-82e2-4537-83fc-aa778ce17b08','bug_updated','Bug updated: test','5567793c-e264-45e7-8ab2-2c6f7bd5fde2','{\"priority\":\"medium\",\"status\":\"fixed\",\"updated_fields\":[\"id\",\"title\",\"description\",\"expected_result\",\"actual_result\",\"fix_description\",\"project_id\",\"reported_by\",\"priority\",\"status\",\"created_at\",\"updated_at\",\"updated_by\",\"fixed_by\",\"project_name\",\"reporter_name\",\"updated_by_name\",\"fixed_by_name\",\"attachments\",\"screenshots\",\"files\",\"_debug\"],\"action\":\"update\"}','2025-12-02 01:47:55'),
('831','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: sasas','9df3b3d0-c9bd-4e49-a796-542f023a7832','{\"priority\":\"medium\",\"status\":\"fixed\",\"updated_fields\":[\"id\",\"title\",\"description\",\"expected_result\",\"actual_result\",\"fix_description\",\"project_id\",\"reported_by\",\"priority\",\"status\",\"created_at\",\"updated_at\",\"updated_by\",\"fixed_by\",\"project_name\",\"reporter_name\",\"updated_by_name\",\"fixed_by_name\",\"attachments\",\"screenshots\",\"files\",\"_debug\"],\"action\":\"update\"}','2025-12-02 01:48:09'),
('832','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: sasas','9df3b3d0-c9bd-4e49-a796-542f023a7832','{\"priority\":\"medium\",\"status\":\"pending\",\"updated_fields\":[\"id\",\"title\",\"description\",\"expected_result\",\"actual_result\",\"fix_description\",\"project_id\",\"reported_by\",\"priority\",\"status\",\"created_at\",\"updated_at\",\"updated_by\",\"project_name\",\"reporter_name\",\"updated_by_name\",\"fixed_by_name\",\"attachments\",\"screenshots\",\"files\",\"_debug\"],\"action\":\"update\"}','2025-12-02 01:49:07'),
('833','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: sasas','9df3b3d0-c9bd-4e49-a796-542f023a7832','{\"priority\":\"medium\",\"status\":\"in_progress\",\"updated_fields\":[\"id\",\"title\",\"description\",\"expected_result\",\"actual_result\",\"fix_description\",\"project_id\",\"reported_by\",\"priority\",\"status\",\"created_at\",\"updated_at\",\"updated_by\",\"project_name\",\"reporter_name\",\"updated_by_name\",\"fixed_by_name\",\"attachments\",\"screenshots\",\"files\",\"_debug\"],\"action\":\"update\"}','2025-12-02 01:49:08'),
('834','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: sasas','9df3b3d0-c9bd-4e49-a796-542f023a7832','{\"priority\":\"medium\",\"status\":\"pending\",\"updated_fields\":[\"id\",\"title\",\"description\",\"expected_result\",\"actual_result\",\"fix_description\",\"project_id\",\"reported_by\",\"priority\",\"status\",\"created_at\",\"updated_at\",\"updated_by\",\"project_name\",\"reporter_name\",\"updated_by_name\",\"fixed_by_name\",\"attachments\",\"screenshots\",\"files\",\"_debug\"],\"action\":\"update\"}','2025-12-02 01:49:10'),
('835','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: sasas','9df3b3d0-c9bd-4e49-a796-542f023a7832','{\"priority\":\"medium\",\"status\":\"fixed\",\"updated_fields\":[\"id\",\"title\",\"description\",\"expected_result\",\"actual_result\",\"fix_description\",\"project_id\",\"reported_by\",\"priority\",\"status\",\"created_at\",\"updated_at\",\"updated_by\",\"fixed_by\",\"project_name\",\"reporter_name\",\"updated_by_name\",\"fixed_by_name\",\"attachments\",\"screenshots\",\"files\",\"_debug\"],\"action\":\"update\"}','2025-12-02 01:49:21'),
('836','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: sasas','9df3b3d0-c9bd-4e49-a796-542f023a7832','{\"priority\":\"medium\",\"status\":\"pending\",\"updated_fields\":[\"id\",\"title\",\"description\",\"expected_result\",\"actual_result\",\"fix_description\",\"project_id\",\"reported_by\",\"priority\",\"status\",\"created_at\",\"updated_at\",\"updated_by\",\"project_name\",\"reporter_name\",\"updated_by_name\",\"fixed_by_name\",\"attachments\",\"screenshots\",\"files\",\"_debug\"],\"action\":\"update\"}','2025-12-02 01:51:55'),
('837','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: sasas','9df3b3d0-c9bd-4e49-a796-542f023a7832','{\"priority\":\"medium\",\"status\":\"fixed\",\"updated_fields\":[\"id\",\"status\",\"fix_description\",\"fixed_by\",\"updated_by\"],\"action\":\"update\"}','2025-12-02 01:52:01'),
('838','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: sasas','9df3b3d0-c9bd-4e49-a796-542f023a7832','{\"priority\":\"medium\",\"status\":\"pending\",\"updated_fields\":[\"id\",\"title\",\"description\",\"expected_result\",\"actual_result\",\"fix_description\",\"project_id\",\"reported_by\",\"priority\",\"status\",\"created_at\",\"updated_at\",\"updated_by\",\"project_name\",\"reporter_name\",\"updated_by_name\",\"fixed_by_name\",\"attachments\",\"screenshots\",\"files\",\"_debug\"],\"action\":\"update\"}','2025-12-02 01:52:51'),
('839','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: sasas','9df3b3d0-c9bd-4e49-a796-542f023a7832','{\"priority\":\"medium\",\"status\":\"fixed\",\"updated_fields\":[\"id\",\"title\",\"description\",\"expected_result\",\"actual_result\",\"fix_description\",\"project_id\",\"reported_by\",\"priority\",\"status\",\"created_at\",\"updated_at\",\"updated_by\",\"fixed_by\",\"project_name\",\"reporter_name\",\"updated_by_name\",\"fixed_by_name\",\"attachments\",\"screenshots\",\"files\",\"_debug\"],\"action\":\"update\"}','2025-12-02 01:52:53'),
('840','366b0b18-bf5c-4206-b1c6-65aa1c8c084a',NULL,'user_created','User created: lubaba','366b0b18-bf5c-4206-b1c6-65aa1c8c084a','{\"email\":\"info.ajmaslnk@gmail.com\",\"role\":\"admin\",\"phone\":\"+918848676627\",\"action\":\"create\",\"username\":\"lubaba\"}','2025-12-02 01:53:57'),
('841','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: sasas','9df3b3d0-c9bd-4e49-a796-542f023a7832','{\"priority\":\"medium\",\"status\":\"pending\",\"updated_fields\":[\"id\",\"title\",\"description\",\"expected_result\",\"actual_result\",\"fix_description\",\"project_id\",\"reported_by\",\"priority\",\"status\",\"created_at\",\"updated_at\",\"updated_by\",\"project_name\",\"reporter_name\",\"updated_by_name\",\"fixed_by_name\",\"attachments\",\"screenshots\",\"files\",\"_debug\"],\"action\":\"update\"}','2025-12-02 01:56:21'),
('842','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: sasas','9df3b3d0-c9bd-4e49-a796-542f023a7832','{\"priority\":\"medium\",\"status\":\"fixed\",\"updated_fields\":[\"id\",\"title\",\"description\",\"expected_result\",\"actual_result\",\"fix_description\",\"project_id\",\"reported_by\",\"priority\",\"status\",\"created_at\",\"updated_at\",\"updated_by\",\"fixed_by\",\"project_name\",\"reporter_name\",\"updated_by_name\",\"fixed_by_name\",\"attachments\",\"screenshots\",\"files\",\"_debug\"],\"action\":\"update\"}','2025-12-02 01:56:23'),
('843','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: sasas','9df3b3d0-c9bd-4e49-a796-542f023a7832','{\"priority\":\"medium\",\"status\":\"in_progress\",\"updated_fields\":[\"id\",\"title\",\"description\",\"expected_result\",\"actual_result\",\"fix_description\",\"project_id\",\"reported_by\",\"priority\",\"status\",\"created_at\",\"updated_at\",\"updated_by\",\"project_name\",\"reporter_name\",\"updated_by_name\",\"fixed_by_name\",\"attachments\",\"screenshots\",\"files\",\"_debug\"],\"action\":\"update\"}','2025-12-02 01:56:37'),
('844','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: sasas','9df3b3d0-c9bd-4e49-a796-542f023a7832','{\"priority\":\"medium\",\"status\":\"fixed\",\"updated_fields\":[\"id\",\"title\",\"description\",\"expected_result\",\"actual_result\",\"fix_description\",\"project_id\",\"reported_by\",\"priority\",\"status\",\"created_at\",\"updated_at\",\"updated_by\",\"fixed_by\",\"project_name\",\"reporter_name\",\"updated_by_name\",\"fixed_by_name\",\"attachments\",\"screenshots\",\"files\",\"_debug\"],\"action\":\"update\"}','2025-12-02 01:56:39'),
('845','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: sasas','9df3b3d0-c9bd-4e49-a796-542f023a7832','{\"priority\":\"medium\",\"status\":\"declined\",\"updated_fields\":[\"id\",\"title\",\"description\",\"expected_result\",\"actual_result\",\"fix_description\",\"project_id\",\"reported_by\",\"priority\",\"status\",\"created_at\",\"updated_at\",\"updated_by\",\"project_name\",\"reporter_name\",\"updated_by_name\",\"fixed_by_name\",\"attachments\",\"screenshots\",\"files\",\"_debug\"],\"action\":\"update\"}','2025-12-02 01:57:35'),
('846','608dc9d1-26e0-441d-8144-45f74c53a846','63fe666d-82e2-4537-83fc-aa778ce17b08','bug_updated','Bug updated: CBSE','48dc13d0-e1c1-428d-bfb9-c7da24484a62','{\"priority\":\"high\",\"status\":\"fixed\",\"updated_fields\":[\"id\",\"status\",\"fix_description\",\"fixed_by\",\"updated_by\"],\"action\":\"update\"}','2025-12-02 09:20:22'),
('847','d84019a3-575f-403c-aa12-02482422bcfa','63fe666d-82e2-4537-83fc-aa778ce17b08','bug_updated','Bug updated: CBSE','48dc13d0-e1c1-428d-bfb9-c7da24484a62','{\"priority\":\"high\",\"status\":\"pending\",\"updated_fields\":[\"id\",\"title\",\"description\",\"expected_result\",\"actual_result\",\"fix_description\",\"project_id\",\"reported_by\",\"priority\",\"status\",\"created_at\",\"updated_at\",\"updated_by\",\"project_name\",\"reporter_name\",\"updated_by_name\",\"fixed_by_name\",\"attachments\",\"screenshots\",\"files\",\"_debug\"],\"action\":\"update\"}','2025-12-02 09:21:29'),
('848','d84019a3-575f-403c-aa12-02482422bcfa','63fe666d-82e2-4537-83fc-aa778ce17b08','bug_updated','Bug updated: CBSE','48dc13d0-e1c1-428d-bfb9-c7da24484a62','{\"priority\":\"high\",\"status\":\"fixed\",\"updated_fields\":[\"id\",\"status\",\"fix_description\",\"fixed_by\",\"updated_by\"],\"action\":\"update\"}','2025-12-02 09:21:44'),
('849','608dc9d1-26e0-441d-8144-45f74c53a846','63fe666d-82e2-4537-83fc-aa778ce17b08','bug_updated','Bug updated: MOHAMMED AJMAL NK','1d8ee0a2-0c99-4d46-b988-0bd60daa0079','{\"priority\":\"medium\",\"status\":\"fixed\",\"updated_fields\":[\"id\",\"status\",\"fix_description\",\"fixed_by\",\"updated_by\"],\"action\":\"update\"}','2025-12-06 01:26:15'),
('850','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: test ajmal','384bc5bb-92d8-4728-a60b-22511d16b13d','{\"priority\":\"medium\",\"status\":\"fixed\",\"updated_fields\":[\"id\",\"status\",\"fix_description\",\"fixed_by\",\"updated_by\"],\"action\":\"update\"}','2026-01-02 01:14:16'),
('851','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: test ajmal','384bc5bb-92d8-4728-a60b-22511d16b13d','{\"priority\":\"medium\",\"status\":\"pending\",\"updated_fields\":[\"id\",\"title\",\"description\",\"expected_result\",\"actual_result\",\"fix_description\",\"project_id\",\"reported_by\",\"priority\",\"status\",\"created_at\",\"updated_at\",\"updated_by\",\"project_name\",\"reporter_name\",\"updated_by_name\",\"fixed_by_name\",\"attachments\",\"screenshots\",\"files\",\"_debug\"],\"action\":\"update\"}','2026-01-02 01:15:41'),
('852','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: test ajmal','384bc5bb-92d8-4728-a60b-22511d16b13d','{\"priority\":\"medium\",\"status\":\"fixed\",\"updated_fields\":[\"id\",\"title\",\"description\",\"expected_result\",\"actual_result\",\"fix_description\",\"project_id\",\"reported_by\",\"priority\",\"status\",\"created_at\",\"updated_at\",\"updated_by\",\"fixed_by\",\"project_name\",\"reporter_name\",\"updated_by_name\",\"fixed_by_name\",\"attachments\",\"screenshots\",\"files\",\"_debug\"],\"action\":\"update\"}','2026-01-02 01:15:43'),
('853','608dc9d1-26e0-441d-8144-45f74c53a846','63fe666d-82e2-4537-83fc-aa778ce17b08','bug_updated','Bug updated: MOHAMMED AJMAL NK','a43aa6dc-477a-4568-8ad5-834d78da901a','{\"priority\":\"high\",\"status\":\"fixed\",\"updated_fields\":[\"id\",\"status\",\"fix_description\",\"fixed_by\",\"updated_by\"],\"action\":\"update\"}','2026-01-02 01:17:13'),
('854','366b0b18-bf5c-4206-b1c6-65aa1c8c084a','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: sasas','9df3b3d0-c9bd-4e49-a796-542f023a7832','{\"priority\":\"medium\",\"status\":\"fixed\",\"updated_fields\":[\"id\",\"title\",\"description\",\"expected_result\",\"actual_result\",\"fix_description\",\"project_id\",\"reported_by\",\"priority\",\"status\",\"created_at\",\"updated_at\",\"updated_by\",\"fixed_by\",\"project_name\",\"reporter_name\",\"updated_by_name\",\"fixed_by_name\",\"attachments\",\"screenshots\",\"files\",\"_debug\",\"impersonate_user_id\"],\"action\":\"update\"}','2026-01-02 01:17:49'),
('855','366b0b18-bf5c-4206-b1c6-65aa1c8c084a','63fe666d-82e2-4537-83fc-aa778ce17b08','bug_updated','Bug updated: dsdsd','2bc23920-c0e4-472a-901c-25c86afc1379','{\"priority\":\"medium\",\"status\":\"fixed\",\"updated_fields\":[\"id\",\"status\",\"fix_description\",\"fixed_by\",\"updated_by\"],\"action\":\"update\"}','2026-01-02 01:18:00'),
('856','d84019a3-575f-403c-aa12-02482422bcfa','63fe666d-82e2-4537-83fc-aa778ce17b08','bug_updated','Bug updated: MOHAMMED AJMAL NK','fdd32ddb-517c-4c01-83f6-97b73cf03d5c','{\"priority\":\"high\",\"status\":\"fixed\",\"updated_fields\":[\"id\",\"status\",\"fix_description\",\"fixed_by\",\"updated_by\"],\"action\":\"update\"}','2026-01-02 01:19:59'),
('857','d84019a3-575f-403c-aa12-02482422bcfa','63fe666d-82e2-4537-83fc-aa778ce17b08','bug_updated','Bug updated: MOHAMMED AJMAL NK','599f4a9f-41d6-4446-b4dc-69572ddc5bea','{\"priority\":\"high\",\"status\":\"fixed\",\"updated_fields\":[\"id\",\"status\",\"fix_description\",\"fixed_by\",\"updated_by\"],\"action\":\"update\"}','2026-01-02 01:20:48'),
('858','d84019a3-575f-403c-aa12-02482422bcfa','63fe666d-82e2-4537-83fc-aa778ce17b08','bug_updated','Bug updated: MOHAMMED AJMAL NK','599f4a9f-41d6-4446-b4dc-69572ddc5bea','{\"priority\":\"high\",\"status\":\"pending\",\"updated_fields\":[\"id\",\"title\",\"description\",\"expected_result\",\"actual_result\",\"fix_description\",\"project_id\",\"reported_by\",\"priority\",\"status\",\"created_at\",\"updated_at\",\"updated_by\",\"project_name\",\"reporter_name\",\"updated_by_name\",\"fixed_by_name\",\"attachments\",\"screenshots\",\"files\",\"_debug\"],\"action\":\"update\"}','2026-01-02 01:21:41'),
('859','d84019a3-575f-403c-aa12-02482422bcfa','63fe666d-82e2-4537-83fc-aa778ce17b08','bug_updated','Bug updated: MOHAMMED AJMAL NK','599f4a9f-41d6-4446-b4dc-69572ddc5bea','{\"priority\":\"high\",\"status\":\"fixed\",\"updated_fields\":[\"id\",\"title\",\"description\",\"expected_result\",\"actual_result\",\"fix_description\",\"project_id\",\"reported_by\",\"priority\",\"status\",\"created_at\",\"updated_at\",\"updated_by\",\"fixed_by\",\"project_name\",\"reporter_name\",\"updated_by_name\",\"fixed_by_name\",\"attachments\",\"screenshots\",\"files\",\"_debug\"],\"action\":\"update\"}','2026-01-02 01:21:43'),
('860','d84019a3-575f-403c-aa12-02482422bcfa','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: b vn','d51d92e3-3074-4351-b04d-42a4f4a4db1e','{\"priority\":\"medium\",\"status\":\"fixed\",\"updated_fields\":[\"id\",\"status\",\"fix_description\",\"fixed_by\",\"updated_by\"],\"action\":\"update\"}','2026-01-02 01:23:20'),
('861','d84019a3-575f-403c-aa12-02482422bcfa','63fe666d-82e2-4537-83fc-aa778ce17b08','bug_updated','Bug updated: Task','b6739ea3-cccb-40eb-8466-da2758dfe7c5','{\"priority\":\"medium\",\"status\":\"fixed\",\"updated_fields\":[\"id\",\"status\",\"fix_description\",\"fixed_by\",\"updated_by\"],\"action\":\"update\"}','2026-01-02 01:25:44'),
('862','d84019a3-575f-403c-aa12-02482422bcfa','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: dwd','8675a113-7ba5-4667-bb8d-e0356e3a6e1b','{\"priority\":\"medium\",\"status\":\"fixed\",\"updated_fields\":[\"id\",\"status\",\"fix_description\",\"fixed_by\",\"updated_by\"],\"action\":\"update\"}','2026-01-02 01:28:05'),
('863','d84019a3-575f-403c-aa12-02482422bcfa','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: dwd','8675a113-7ba5-4667-bb8d-e0356e3a6e1b','{\"priority\":\"medium\",\"status\":\"in_progress\",\"updated_fields\":[\"id\",\"title\",\"description\",\"expected_result\",\"actual_result\",\"fix_description\",\"project_id\",\"reported_by\",\"priority\",\"status\",\"created_at\",\"updated_at\",\"updated_by\",\"project_name\",\"reporter_name\",\"updated_by_name\",\"fixed_by_name\",\"attachments\",\"screenshots\",\"files\",\"_debug\"],\"action\":\"update\"}','2026-01-02 01:29:23'),
('864','d84019a3-575f-403c-aa12-02482422bcfa','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: dwd','8675a113-7ba5-4667-bb8d-e0356e3a6e1b','{\"priority\":\"medium\",\"status\":\"fixed\",\"updated_fields\":[\"id\",\"status\",\"fix_description\",\"fixed_by\",\"updated_by\"],\"action\":\"update\"}','2026-01-02 01:29:27'),
('865','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','bug_updated','Bug updated: test ajmal','384bc5bb-92d8-4728-a60b-22511d16b13d','{\"priority\":\"medium\",\"status\":\"pending\",\"updated_fields\":[\"id\",\"title\",\"description\",\"expected_result\",\"actual_result\",\"fix_description\",\"project_id\",\"reported_by\",\"priority\",\"status\",\"created_at\",\"updated_at\",\"updated_by\",\"project_name\",\"reporter_name\",\"updated_by_name\",\"fixed_by_name\",\"attachments\",\"screenshots\",\"files\",\"_debug\"],\"action\":\"update\"}','2026-01-02 02:11:44'),
('866','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','member_added','added dev to the project',NULL,'{\"member_username\":\"dev\",\"role\":\"developer\"}','2026-01-02 02:12:22'),
('867','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','member_removed','removed tester from the project',NULL,'{\"member_username\":\"tester\",\"role\":\"tester\"}','2026-01-02 02:13:55'),
('868','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','member_added','added tester to the project',NULL,'{\"member_username\":\"tester\",\"role\":\"tester\"}','2026-01-02 02:13:58'),
('869','608dc9d1-26e0-441d-8144-45f74c53a846','291c8841-94a5-4cdb-9eb8-fef40709aee5','update_created','Update created: dddd','087e8cb5-106f-455e-88e7-1ab56914b074','{\"type\":\"updation\",\"description\":\"dddd...\",\"attachments_count\":0,\"action\":\"create\"}','2026-01-02 02:25:05'),
('870','608dc9d1-26e0-441d-8144-45f74c53a846','63fe666d-82e2-4537-83fc-aa778ce17b08','update_created','Update created: dddddddd','71aa7f76-a788-416d-82ef-647e1d8092fd','{\"type\":\"updation\",\"description\":\"ddddddd...\",\"attachments_count\":0,\"action\":\"create\"}','2026-01-02 02:46:55'),
('871','608dc9d1-26e0-441d-8144-45f74c53a846','a5dd0abd-b5cc-43ff-a22e-652e30ab7d28','update_created','Update created: sdsdsdsdsd','7d641d93-5965-4bc1-a361-f7d171a8d321','{\"type\":\"maintenance\",\"description\":\"adadd...\",\"attachments_count\":0,\"action\":\"create\"}','2026-01-02 02:50:45'),
('872','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','update_created','Update created: dddddd','500ee5e2-4382-4acc-b451-4ff2af163ab8','{\"type\":\"maintenance\",\"description\":\"ddddd...\",\"attachments_count\":0,\"action\":\"create\"}','2026-01-02 02:53:35'),
('873','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','update_created','Update created: dddwww','358f23ce-b4fc-4b46-8881-3f1c3f15cd24','{\"type\":\"maintenance\",\"description\":\"wwwww...\",\"attachments_count\":0,\"action\":\"create\"}','2026-01-02 02:56:01'),
('874','608dc9d1-26e0-441d-8144-45f74c53a846','83f0e57d-6905-49b6-99a4-2b3df2595644','update_created','Update created: ddsdsdsddsd','65ec5c5d-b8ee-4918-ad3c-99229a485b58','{\"type\":\"updation\",\"description\":\"sdsdsdsd...\",\"attachments_count\":0,\"action\":\"create\"}','2026-01-02 03:02:00');


-- Table structure for table `project_members`
DROP TABLE IF EXISTS `project_members`;
CREATE TABLE `project_members` (
  `project_id` varchar(36) NOT NULL,
  `user_id` varchar(36) NOT NULL,
  `role` enum('manager','developer','tester') NOT NULL,
  `joined_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`project_id`,`user_id`),
  KEY `user_id` (`user_id`),
  KEY `idx_project_members_user_id` (`user_id`),
  KEY `idx_project_members_project_id` (`project_id`),
  KEY `idx_project_members_user_project` (`user_id`,`project_id`),
  KEY `idx_project_members_joined_at` (`joined_at`),
  KEY `idx_project_members_user_role` (`user_id`,`role`),
  KEY `idx_project_members_project_role` (`project_id`,`role`),
  KEY `idx_project_members_dashboard` (`project_id`,`role`,`joined_at`),
  CONSTRAINT `project_members_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`),
  CONSTRAINT `project_members_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `project_members`
INSERT INTO `project_members` VALUES
('63fe666d-82e2-4537-83fc-aa778ce17b08','d84019a3-575f-403c-aa12-02482422bcfa','developer','2025-12-02 01:33:12'),
('83f0e57d-6905-49b6-99a4-2b3df2595644','d84019a3-575f-403c-aa12-02482422bcfa','developer','2025-11-02 21:31:30'),
('83f0e57d-6905-49b6-99a4-2b3df2595644','e1e7aecc-96f9-452b-b60c-e9541c27ea3d','developer','2026-01-02 02:12:08'),
('83f0e57d-6905-49b6-99a4-2b3df2595644','c18ce191-e34b-4ca7-b69b-6a78488d3de5','tester','2026-01-02 02:13:58');


-- Table structure for table `projects`
DROP TABLE IF EXISTS `projects`;
CREATE TABLE `projects` (
  `id` varchar(36) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('active','completed','archived') NOT NULL DEFAULT 'active',
  `created_by` varchar(36) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `idx_projects_created_by` (`created_by`),
  KEY `idx_projects_name` (`name`),
  KEY `idx_projects_status_created` (`status`,`created_at`),
  KEY `idx_projects_created_by_status` (`created_by`,`status`),
  KEY `idx_projects_name_status` (`name`,`status`),
  KEY `idx_projects_status_id_name_created_by` (`status`,`id`,`name`,`created_by`),
  FULLTEXT KEY `ft_projects_search` (`name`,`description`),
  CONSTRAINT `projects_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `projects`
INSERT INTO `projects` VALUES
('291c8841-94a5-4cdb-9eb8-fef40709aee5','Albedo Calc','Albedo Educator','active','608dc9d1-26e0-441d-8144-45f74c53a846','2025-11-02 18:35:22','2025-11-02 18:35:22'),
('63fe666d-82e2-4537-83fc-aa778ce17b08','MedocSuite','MedocSuite','active','608dc9d1-26e0-441d-8144-45f74c53a846','2025-11-02 18:35:59','2025-11-02 18:35:59'),
('83f0e57d-6905-49b6-99a4-2b3df2595644','Albedo Educator','Albedo Educator','active','608dc9d1-26e0-441d-8144-45f74c53a846','2025-11-02 18:35:13','2025-11-02 18:35:13'),
('a5dd0abd-b5cc-43ff-a22e-652e30ab7d28','Albedo Web','Albedo Educator','active','608dc9d1-26e0-441d-8144-45f74c53a846','2025-11-02 18:35:37','2025-11-02 18:35:37');


-- Table structure for table `role_permissions`
DROP TABLE IF EXISTS `role_permissions`;
CREATE TABLE `role_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_role_permission` (`role_id`,`permission_id`),
  KEY `idx_role_permissions_role` (`role_id`),
  KEY `idx_role_permissions_permission` (`permission_id`),
  CONSTRAINT `fk_role_permissions_permission` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_role_permissions_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1476 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `role_permissions`
INSERT INTO `role_permissions` VALUES
('1298','1','8','2025-10-28 01:43:49'),
('1299','1','7','2025-10-28 01:43:49'),
('1300','1','3','2025-10-28 01:43:49'),
('1301','1','6','2025-10-28 01:43:49'),
('1302','1','4','2025-10-28 01:43:49'),
('1303','1','5','2025-10-28 01:43:49'),
('1304','1','1','2025-10-28 01:43:49'),
('1305','1','2','2025-10-28 01:43:49'),
('1306','1','24','2025-10-28 01:43:49'),
('1307','1','26','2025-10-28 01:43:49'),
('1308','1','25','2025-10-28 01:43:49'),
('1309','1','23','2025-10-28 01:43:49'),
('1310','1','46','2025-10-28 01:43:49'),
('1311','1','47','2025-10-28 01:43:49'),
('1312','1','48','2025-10-28 01:43:49'),
('1313','1','44','2025-10-28 01:43:49'),
('1314','1','45','2025-10-28 01:43:49'),
('1315','1','43','2025-10-28 01:43:49'),
('1316','1','42','2025-10-28 01:43:49'),
('1317','1','22','2025-10-28 01:43:49'),
('1318','1','18','2025-10-28 01:43:49'),
('1319','1','20','2025-10-28 01:43:49'),
('1320','1','19','2025-10-28 01:43:49'),
('1321','1','21','2025-10-28 01:43:49'),
('1322','1','16','2025-10-28 01:43:49'),
('1323','1','17','2025-10-28 01:43:49'),
('1324','1','39','2025-10-28 01:43:49'),
('1325','1','41','2025-10-28 01:43:49'),
('1326','1','40','2025-10-28 01:43:49'),
('1327','1','38','2025-10-28 01:43:49'),
('1328','1','49','2025-10-28 01:43:49'),
('1329','1','32','2025-10-28 01:43:49'),
('1330','1','29','2025-10-28 01:43:49'),
('1331','1','31','2025-10-28 01:43:49'),
('1332','1','30','2025-10-28 01:43:49'),
('1333','1','27','2025-10-28 01:43:49'),
('1334','1','28','2025-10-28 01:43:49'),
('1335','1','37','2025-10-28 01:43:49'),
('1336','1','34','2025-10-28 01:43:49'),
('1337','1','36','2025-10-28 01:43:49'),
('1338','1','35','2025-10-28 01:43:49'),
('1339','1','33','2025-10-28 01:43:49'),
('1340','1','13','2025-10-28 01:43:49'),
('1341','1','10','2025-10-28 01:43:49'),
('1342','1','12','2025-10-28 01:43:49'),
('1343','1','11','2025-10-28 01:43:49'),
('1344','1','15','2025-10-28 01:43:49'),
('1345','1','14','2025-10-28 01:43:49'),
('1346','1','9','2025-10-28 01:43:49'),
('1373','3','7','2025-10-28 01:45:07'),
('1374','3','3','2025-10-28 01:45:07'),
('1375','3','4','2025-10-28 01:45:07'),
('1376','3','5','2025-10-28 01:45:07'),
('1377','3','1','2025-10-28 01:45:07'),
('1378','3','24','2025-10-28 01:45:07'),
('1379','3','26','2025-10-28 01:45:07'),
('1380','3','25','2025-10-28 01:45:07'),
('1381','3','23','2025-10-28 01:45:07'),
('1382','3','46','2025-10-28 01:45:07'),
('1383','3','47','2025-10-28 01:45:07'),
('1384','3','48','2025-10-28 01:45:07'),
('1385','3','22','2025-10-28 01:45:07'),
('1386','3','18','2025-10-28 01:45:07'),
('1387','3','17','2025-10-28 01:45:07'),
('1388','3','32','2025-10-28 01:45:07'),
('1389','3','29','2025-10-28 01:45:07'),
('1390','3','31','2025-10-28 01:45:07'),
('1391','3','30','2025-10-28 01:45:07'),
('1392','3','27','2025-10-28 01:45:07'),
('1393','3','28','2025-10-28 01:45:07'),
('1394','3','37','2025-10-28 01:45:07'),
('1395','3','34','2025-10-28 01:45:07'),
('1396','3','36','2025-10-28 01:45:07'),
('1397','3','35','2025-10-28 01:45:07'),
('1398','3','33','2025-10-28 01:45:07'),
('1399','16','8','2025-11-02 22:14:41'),
('1400','16','7','2025-11-02 22:14:41'),
('1401','16','3','2025-11-02 22:14:41'),
('1402','16','6','2025-11-02 22:14:41'),
('1403','16','4','2025-11-02 22:14:41'),
('1404','16','5','2025-11-02 22:14:41'),
('1405','16','1','2025-11-02 22:14:41'),
('1406','16','2','2025-11-02 22:14:41'),
('1407','16','24','2025-11-02 22:14:41'),
('1408','16','26','2025-11-02 22:14:41'),
('1409','16','25','2025-11-02 22:14:41'),
('1410','16','23','2025-11-02 22:14:41'),
('1411','16','46','2025-11-02 22:14:41'),
('1412','16','47','2025-11-02 22:14:41'),
('1413','16','48','2025-11-02 22:14:41'),
('1414','16','44','2025-11-02 22:14:41'),
('1415','16','45','2025-11-02 22:14:41'),
('1416','16','43','2025-11-02 22:14:41'),
('1417','16','42','2025-11-02 22:14:41'),
('1418','16','22','2025-11-02 22:14:41'),
('1419','16','18','2025-11-02 22:14:41'),
('1420','16','20','2025-11-02 22:14:41'),
('1421','16','19','2025-11-02 22:14:41'),
('1422','16','21','2025-11-02 22:14:41'),
('1423','16','16','2025-11-02 22:14:41'),
('1424','16','17','2025-11-02 22:14:41'),
('1425','16','39','2025-11-02 22:14:41'),
('1426','16','41','2025-11-02 22:14:41'),
('1427','16','40','2025-11-02 22:14:41'),
('1428','16','38','2025-11-02 22:14:41'),
('1429','16','49','2025-11-02 22:14:41'),
('1430','16','32','2025-11-02 22:14:41'),
('1431','16','29','2025-11-02 22:14:41'),
('1432','16','31','2025-11-02 22:14:41'),
('1433','16','30','2025-11-02 22:14:41'),
('1434','16','27','2025-11-02 22:14:41'),
('1435','16','28','2025-11-02 22:14:41'),
('1436','16','37','2025-11-02 22:14:41'),
('1437','16','34','2025-11-02 22:14:41'),
('1438','16','36','2025-11-02 22:14:41'),
('1439','16','35','2025-11-02 22:14:41'),
('1440','16','33','2025-11-02 22:14:41'),
('1441','16','13','2025-11-02 22:14:41'),
('1442','16','10','2025-11-02 22:14:41'),
('1443','16','12','2025-11-02 22:14:41'),
('1444','16','11','2025-11-02 22:14:41'),
('1445','16','15','2025-11-02 22:14:41'),
('1446','16','14','2025-11-02 22:14:41'),
('1447','16','9','2025-11-02 22:14:41'),
('1448','2','8','2025-11-03 23:41:12'),
('1449','2','7','2025-11-03 23:41:12'),
('1450','2','3','2025-11-03 23:41:12'),
('1451','2','6','2025-11-03 23:41:12'),
('1452','2','4','2025-11-03 23:41:12'),
('1453','2','5','2025-11-03 23:41:12'),
('1454','2','1','2025-11-03 23:41:12'),
('1455','2','2','2025-11-03 23:41:12'),
('1456','2','26','2025-11-03 23:41:12'),
('1457','2','25','2025-11-03 23:41:12'),
('1458','2','23','2025-11-03 23:41:12'),
('1459','2','22','2025-11-03 23:41:12'),
('1460','2','18','2025-11-03 23:41:12'),
('1461','2','20','2025-11-03 23:41:12'),
('1462','2','19','2025-11-03 23:41:12'),
('1463','2','16','2025-11-03 23:41:12'),
('1464','2','17','2025-11-03 23:41:12'),
('1465','2','32','2025-11-03 23:41:12'),
('1466','2','29','2025-11-03 23:41:12'),
('1467','2','31','2025-11-03 23:41:12'),
('1468','2','30','2025-11-03 23:41:12'),
('1469','2','27','2025-11-03 23:41:12'),
('1470','2','28','2025-11-03 23:41:12'),
('1471','2','37','2025-11-03 23:41:12'),
('1472','2','34','2025-11-03 23:41:12'),
('1473','2','36','2025-11-03 23:41:12'),
('1474','2','35','2025-11-03 23:41:12'),
('1475','2','33','2025-11-03 23:41:12');


-- Table structure for table `roles`
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `is_system_role` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_name` (`role_name`),
  KEY `idx_roles_system` (`is_system_role`),
  KEY `idx_roles_name` (`role_name`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `roles`
INSERT INTO `roles` VALUES
('1','Admin','System administrator with full access','1','2025-10-25 17:21:00','2025-10-25 17:21:00'),
('2','Developer','Software developer with project and bug management access','1','2025-10-25 17:21:00','2025-10-25 17:21:00'),
('3','Tester','Quality assurance tester with bug reporting and testing access','1','2025-10-25 17:21:00','2025-10-25 17:21:00'),
('16','Marketer','Marketer | CODO AI Innovations','0','2025-11-02 22:14:41','2025-11-02 22:14:41');


-- Table structure for table `session_activities`
DROP TABLE IF EXISTS `session_activities`;
CREATE TABLE `session_activities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` int(11) NOT NULL,
  `activity_type` enum('work','break','meeting','training','other') DEFAULT 'work',
  `start_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `end_time` timestamp NULL DEFAULT NULL,
  `activity_notes` text DEFAULT NULL,
  `project_id` varchar(36) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_session` (`session_id`),
  KEY `idx_activity_type` (`activity_type`),
  KEY `idx_project` (`project_id`),
  CONSTRAINT `session_activities_ibfk_1` FOREIGN KEY (`session_id`) REFERENCES `work_sessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for table `session_pauses`
DROP TABLE IF EXISTS `session_pauses`;
CREATE TABLE `session_pauses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` int(11) NOT NULL,
  `pause_start` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `pause_end` timestamp NULL DEFAULT NULL,
  `pause_reason` varchar(255) DEFAULT 'break',
  `duration_seconds` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_session` (`session_id`),
  KEY `idx_active_pause` (`session_id`,`is_active`),
  CONSTRAINT `session_pauses_ibfk_1` FOREIGN KEY (`session_id`) REFERENCES `work_sessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for table `settings`
DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key_name` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_name` (`key_name`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `settings`
INSERT INTO `settings` VALUES
('1','email_notifications_enabled','1');


-- Table structure for table `shared_task_assignees`
DROP TABLE IF EXISTS `shared_task_assignees`;
CREATE TABLE `shared_task_assignees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shared_task_id` int(11) NOT NULL,
  `assigned_to` varchar(36) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `completed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_task_assignee` (`shared_task_id`,`assigned_to`),
  KEY `idx_shared_task_id` (`shared_task_id`),
  KEY `idx_assigned_to` (`assigned_to`),
  KEY `idx_completed_at` (`completed_at`),
  CONSTRAINT `fk_sta_task` FOREIGN KEY (`shared_task_id`) REFERENCES `shared_tasks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `shared_task_assignees`
INSERT INTO `shared_task_assignees` VALUES
('103','15','608dc9d1-26e0-441d-8144-45f74c53a846','2025-11-03 01:18:09',NULL),
('104','15','d84019a3-575f-403c-aa12-02482422bcfa','2025-11-03 01:18:09',NULL),
('105','15','e1e7aecc-96f9-452b-b60c-e9541c27ea3d','2025-11-03 01:18:09',NULL),
('106','15','f78f9246-48e3-4a9d-a5fb-1b70d4bc7d68','2025-11-03 01:18:09',NULL),
('115','16','608dc9d1-26e0-441d-8144-45f74c53a846','2025-11-03 01:35:31',NULL),
('116','16','e1e7aecc-96f9-452b-b60c-e9541c27ea3d','2025-11-03 01:35:31',NULL),
('117','16','f78f9246-48e3-4a9d-a5fb-1b70d4bc7d68','2025-11-03 01:35:31',NULL),
('118','17','3045985b-50f9-44e5-9adf-bc6879945272','2025-12-02 00:09:31',NULL),
('119','17','608dc9d1-26e0-441d-8144-45f74c53a846','2025-12-02 00:09:31',NULL),
('120','17','d84019a3-575f-403c-aa12-02482422bcfa','2025-12-02 00:09:31',NULL),
('121','18','3045985b-50f9-44e5-9adf-bc6879945272','2025-12-02 00:14:35',NULL),
('122','18','608dc9d1-26e0-441d-8144-45f74c53a846','2025-12-02 00:14:35',NULL),
('123','18','d84019a3-575f-403c-aa12-02482422bcfa','2025-12-02 00:14:35',NULL),
('124','19','3045985b-50f9-44e5-9adf-bc6879945272','2025-12-02 09:04:42',NULL),
('125','19','366b0b18-bf5c-4206-b1c6-65aa1c8c084a','2025-12-02 09:04:42',NULL);


-- Table structure for table `shared_task_projects`
DROP TABLE IF EXISTS `shared_task_projects`;
CREATE TABLE `shared_task_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shared_task_id` int(11) NOT NULL,
  `project_id` varchar(36) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_task_project` (`shared_task_id`,`project_id`),
  KEY `idx_shared_task_id` (`shared_task_id`),
  KEY `idx_project_id` (`project_id`),
  CONSTRAINT `shared_task_projects_ibfk_1` FOREIGN KEY (`shared_task_id`) REFERENCES `shared_tasks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `shared_task_projects`
INSERT INTO `shared_task_projects` VALUES
('40','15','83f0e57d-6905-49b6-99a4-2b3df2595644','2025-11-03 01:18:09'),
('43','16','83f0e57d-6905-49b6-99a4-2b3df2595644','2025-11-03 01:35:31'),
('44','17','291c8841-94a5-4cdb-9eb8-fef40709aee5','2025-12-02 00:09:31'),
('45','18','63fe666d-82e2-4537-83fc-aa778ce17b08','2025-12-02 00:14:35'),
('46','19','63fe666d-82e2-4537-83fc-aa778ce17b08','2025-12-02 09:04:42');


-- Table structure for table `shared_tasks`
DROP TABLE IF EXISTS `shared_tasks`;
CREATE TABLE `shared_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `created_by` varchar(36) NOT NULL,
  `assigned_to` varchar(36) NOT NULL,
  `approved_by` varchar(36) DEFAULT NULL,
  `completed_by` varchar(36) DEFAULT NULL,
  `project_id` varchar(36) DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `status` enum('pending','in_progress','completed','approved') DEFAULT 'pending',
  `priority` enum('low','medium','high') DEFAULT 'medium',
  `completed_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `approved_by` (`approved_by`),
  KEY `completed_by` (`completed_by`),
  KEY `idx_assigned_to` (`assigned_to`),
  KEY `idx_created_by` (`created_by`),
  KEY `idx_status` (`status`),
  KEY `idx_project_id` (`project_id`),
  CONSTRAINT `shared_tasks_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `shared_tasks_ibfk_2` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `shared_tasks_ibfk_3` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `shared_tasks_ibfk_4` FOREIGN KEY (`completed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `shared_tasks`
INSERT INTO `shared_tasks` VALUES
('15','Sample','Hello','608dc9d1-26e0-441d-8144-45f74c53a846','608dc9d1-26e0-441d-8144-45f74c53a846','608dc9d1-26e0-441d-8144-45f74c53a846',NULL,NULL,'2025-11-30','pending','high',NULL,'2025-11-03 00:53:38','2025-11-03 01:16:25'),
('16','sdsdsd','sdsdsd','608dc9d1-26e0-441d-8144-45f74c53a846','608dc9d1-26e0-441d-8144-45f74c53a846',NULL,NULL,NULL,'2025-11-19','pending','medium',NULL,'2025-11-03 01:19:08','2025-11-03 01:35:24'),
('17','Test','Test','608dc9d1-26e0-441d-8144-45f74c53a846','3045985b-50f9-44e5-9adf-bc6879945272',NULL,NULL,NULL,'2025-12-10','pending','medium',NULL,'2025-12-02 00:09:31','2025-12-02 00:09:31'),
('18','Test','test','608dc9d1-26e0-441d-8144-45f74c53a846','3045985b-50f9-44e5-9adf-bc6879945272',NULL,NULL,NULL,'2025-12-26','pending','medium',NULL,'2025-12-02 00:14:35','2025-12-02 00:14:35'),
('19','test','test','608dc9d1-26e0-441d-8144-45f74c53a846','3045985b-50f9-44e5-9adf-bc6879945272',NULL,NULL,NULL,'2025-12-18','pending','medium',NULL,'2025-12-02 09:04:42','2025-12-02 09:04:42');


-- Table structure for table `starred_messages`
DROP TABLE IF EXISTS `starred_messages`;
CREATE TABLE `starred_messages` (
  `id` varchar(36) NOT NULL,
  `message_id` varchar(36) NOT NULL,
  `user_id` varchar(36) NOT NULL,
  `group_id` varchar(36) NOT NULL,
  `starred_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_message_starred` (`message_id`,`user_id`),
  KEY `idx_starred_messages_user` (`user_id`),
  KEY `idx_starred_messages_message` (`message_id`),
  KEY `idx_starred_messages_group` (`group_id`),
  CONSTRAINT `starred_messages_ibfk_1` FOREIGN KEY (`message_id`) REFERENCES `chat_messages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `starred_messages_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `starred_messages_ibfk_3` FOREIGN KEY (`group_id`) REFERENCES `chat_groups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for table `status_views`
DROP TABLE IF EXISTS `status_views`;
CREATE TABLE `status_views` (
  `id` varchar(36) NOT NULL,
  `status_id` varchar(36) NOT NULL,
  `viewer_id` varchar(36) NOT NULL,
  `viewed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_status_viewer` (`status_id`,`viewer_id`),
  KEY `idx_status_views_status` (`status_id`),
  KEY `idx_status_views_viewer` (`viewer_id`),
  CONSTRAINT `status_views_ibfk_1` FOREIGN KEY (`status_id`) REFERENCES `user_status` (`id`) ON DELETE CASCADE,
  CONSTRAINT `status_views_ibfk_2` FOREIGN KEY (`viewer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for table `typing_indicators`
DROP TABLE IF EXISTS `typing_indicators`;
CREATE TABLE `typing_indicators` (
  `id` varchar(36) NOT NULL,
  `group_id` varchar(36) NOT NULL,
  `user_id` varchar(36) NOT NULL,
  `is_typing` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_typing_indicators_group_id` (`group_id`),
  KEY `idx_typing_indicators_user_id` (`user_id`),
  KEY `idx_typing_indicators_expires_at` (`expires_at`),
  CONSTRAINT `typing_indicators_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `chat_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `typing_indicators_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for table `update_attachments`
DROP TABLE IF EXISTS `update_attachments`;
CREATE TABLE `update_attachments` (
  `id` varchar(36) NOT NULL,
  `update_id` varchar(36) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_type` enum('screenshot','attachment','voice_note') NOT NULL DEFAULT 'attachment',
  `file_size` bigint(20) DEFAULT NULL,
  `duration` int(11) DEFAULT NULL COMMENT 'Duration in seconds for voice notes',
  `uploaded_by` varchar(36) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_update_id` (`update_id`),
  KEY `idx_file_type` (`file_type`),
  KEY `idx_uploaded_by` (`uploaded_by`),
  CONSTRAINT `update_attachments_ibfk_1` FOREIGN KEY (`update_id`) REFERENCES `updates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `update_attachments_ibfk_2` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for table `updates`
DROP TABLE IF EXISTS `updates`;
CREATE TABLE `updates` (
  `id` varchar(36) NOT NULL,
  `project_id` varchar(36) NOT NULL,
  `title` varchar(255) NOT NULL,
  `type` enum('feature','updation','maintenance') NOT NULL,
  `description` text NOT NULL,
  `created_by` varchar(36) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  `status` enum('pending','approved','declined','completed') DEFAULT 'pending',
  `expected_date` date DEFAULT NULL,
  `expected_time` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `idx_type` (`type`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_status` (`status`),
  KEY `idx_project_id` (`project_id`),
  KEY `idx_updates_project_status` (`project_id`,`status`),
  KEY `idx_updates_created_by_status` (`created_by`,`status`),
  KEY `idx_updates_created_at_status` (`created_at`,`status`),
  KEY `idx_updates_type_status` (`type`,`status`),
  CONSTRAINT `updates_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `updates_ibfk_2` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `updates`
INSERT INTO `updates` VALUES
('087e8cb5-106f-455e-88e7-1ab56914b074','291c8841-94a5-4cdb-9eb8-fef40709aee5','dddd','updation','dddd','608dc9d1-26e0-441d-8144-45f74c53a846','2026-01-02 02:25:05','2026-01-02 02:49:29','approved','2026-01-15','00:00:00'),
('23226f53-0e92-4d32-b146-571b987761b0','63fe666d-82e2-4537-83fc-aa778ce17b08','test','feature','test','608dc9d1-26e0-441d-8144-45f74c53a846','2025-12-01 19:09:20','2026-01-02 00:27:18','completed',NULL,NULL),
('2548d2dc-78f2-48f0-956e-8be15f60231d','63fe666d-82e2-4537-83fc-aa778ce17b08','ddd','maintenance','ddd','608dc9d1-26e0-441d-8144-45f74c53a846','2025-11-03 05:09:33',NULL,'pending',NULL,NULL),
('3492c89e-dbfe-48c8-befc-06de7f99c78a','291c8841-94a5-4cdb-9eb8-fef40709aee5','ddd','updation','dddd','608dc9d1-26e0-441d-8144-45f74c53a846','2026-01-02 02:20:33',NULL,'pending','2026-01-09','00:00:00'),
('358f23ce-b4fc-4b46-8881-3f1c3f15cd24','83f0e57d-6905-49b6-99a4-2b3df2595644','dddwww','maintenance','wwwww','608dc9d1-26e0-441d-8144-45f74c53a846','2026-01-02 02:56:01',NULL,'pending','2026-01-14','00:00:00'),
('3fd21fb0-b608-4d73-ba4c-9383f682c221','83f0e57d-6905-49b6-99a4-2b3df2595644','demo','feature','dsdsd','608dc9d1-26e0-441d-8144-45f74c53a846','2025-11-03 04:57:45',NULL,'approved',NULL,NULL),
('500ee5e2-4382-4acc-b451-4ff2af163ab8','83f0e57d-6905-49b6-99a4-2b3df2595644','dddddd','maintenance','ddddd','608dc9d1-26e0-441d-8144-45f74c53a846','2026-01-02 02:53:35',NULL,'pending','2026-01-28','00:00:00'),
('65ec5c5d-b8ee-4918-ad3c-99229a485b58','83f0e57d-6905-49b6-99a4-2b3df2595644','ddsdsdsddsd','updation','sdsdsdsd','608dc9d1-26e0-441d-8144-45f74c53a846','2026-01-02 03:02:00','2026-01-02 03:02:29','approved','2026-01-29','00:00:00'),
('6d575450-8f13-4205-ab49-6e3b96ed1853','83f0e57d-6905-49b6-99a4-2b3df2595644','Testing','maintenance','Demo','d84019a3-575f-403c-aa12-02482422bcfa','2025-11-02 16:41:23',NULL,'pending',NULL,NULL),
('71aa7f76-a788-416d-82ef-647e1d8092fd','63fe666d-82e2-4537-83fc-aa778ce17b08','dddddddd','updation','ddddddd','608dc9d1-26e0-441d-8144-45f74c53a846','2026-01-02 02:46:55',NULL,'pending','2026-01-15','00:00:00'),
('7d641d93-5965-4bc1-a361-f7d171a8d321','a5dd0abd-b5cc-43ff-a22e-652e30ab7d28','sdsdsdsdsd','maintenance','adadd','608dc9d1-26e0-441d-8144-45f74c53a846','2026-01-02 02:50:45',NULL,'pending','2026-01-22','00:00:00'),
('8aad920e-687a-4647-837c-4890ea4cb23f','63fe666d-82e2-4537-83fc-aa778ce17b08','ddd','maintenance','dd','608dc9d1-26e0-441d-8144-45f74c53a846','2025-11-03 05:07:38',NULL,'pending',NULL,NULL),
('988bd60a-40ac-452b-be00-d8cd8edb66da','291c8841-94a5-4cdb-9eb8-fef40709aee5','sdsdwd','updation','sdsdsd','608dc9d1-26e0-441d-8144-45f74c53a846','2026-01-02 02:21:43',NULL,'pending','2026-01-16','00:00:00'),
('98b63287-9c08-4990-a06e-2bb6fe1ae918','83f0e57d-6905-49b6-99a4-2b3df2595644','ddd','updation','ddd','608dc9d1-26e0-441d-8144-45f74c53a846','2025-11-03 04:59:52',NULL,'pending',NULL,NULL),
('bc48ed33-963e-46ce-8478-28daa4d091bf','83f0e57d-6905-49b6-99a4-2b3df2595644','dddd','updation','ddd','608dc9d1-26e0-441d-8144-45f74c53a846','2025-11-03 05:16:13',NULL,'pending',NULL,NULL),
('cb5eef4a-993e-4e1b-bf37-cb881176f139','83f0e57d-6905-49b6-99a4-2b3df2595644','ddd','updation','ddd','608dc9d1-26e0-441d-8144-45f74c53a846','2025-11-03 05:10:36',NULL,'pending',NULL,NULL),
('ef69e245-8d3a-4597-b8b0-d3fb30ef654e','83f0e57d-6905-49b6-99a4-2b3df2595644','sdsd','updation','sdsdsd','608dc9d1-26e0-441d-8144-45f74c53a846','2025-11-03 05:13:12',NULL,'pending',NULL,NULL);


-- Table structure for table `user_activity_sessions`
DROP TABLE IF EXISTS `user_activity_sessions`;
CREATE TABLE `user_activity_sessions` (
  `id` varchar(36) NOT NULL,
  `user_id` varchar(36) NOT NULL,
  `session_start` datetime NOT NULL,
  `session_end` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `session_duration_minutes` int(11) DEFAULT NULL,
  `activity_type` enum('work','break','meeting','other') DEFAULT 'work',
  `project_id` varchar(36) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_activity_user_id` (`user_id`),
  KEY `idx_user_activity_session_start` (`session_start`),
  KEY `idx_user_activity_session_end` (`session_end`),
  KEY `idx_user_activity_user_date` (`user_id`,`session_start`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Tracks user activity sessions for calculating active hours and presence';


-- Table structure for table `user_documents`
DROP TABLE IF EXISTS `user_documents`;
CREATE TABLE `user_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `doc_title` varchar(500) NOT NULL COMMENT 'Document title',
  `google_doc_id` varchar(255) NOT NULL COMMENT 'Google Document ID',
  `google_doc_url` text NOT NULL COMMENT 'Full Google Docs edit URL',
  `creator_user_id` varchar(255) NOT NULL COMMENT 'BugRicer user ID (UUID)',
  `template_id` int(11) DEFAULT NULL COMMENT 'Reference to doc_templates if created from template',
  `doc_type` varchar(50) DEFAULT 'general' COMMENT 'Document type: general, meeting, notes, etc.',
  `is_archived` tinyint(1) DEFAULT 0 COMMENT 'Whether document is archived',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `last_accessed_at` timestamp NULL DEFAULT NULL COMMENT 'Last time document was opened',
  `project_id` varchar(500) DEFAULT NULL COMMENT 'Reference to projects.id (comma-separated for multiple projects)',
  `role` varchar(100) DEFAULT 'all' COMMENT 'Role access: all, admins, developers, testers (comma-separated for multiple)',
  PRIMARY KEY (`id`),
  UNIQUE KEY `google_doc_id` (`google_doc_id`),
  KEY `idx_creator` (`creator_user_id`),
  KEY `idx_template` (`template_id`),
  KEY `idx_type` (`doc_type`),
  KEY `idx_archived` (`is_archived`),
  CONSTRAINT `user_documents_ibfk_1` FOREIGN KEY (`template_id`) REFERENCES `doc_templates` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='User-created general documents';

-- Dumping data for table `user_documents`
INSERT INTO `user_documents` VALUES
('14','Ajmal','16REecdIVi_crJ98G5CzvAYqYg_SyogRyDrbBZUeL4TQ','https://docs.google.com/document/d/16REecdIVi_crJ98G5CzvAYqYg_SyogRyDrbBZUeL4TQ/edit','608dc9d1-26e0-441d-8144-45f74c53a846',NULL,'general','0','2025-11-02 23:11:14','2025-11-02 23:11:14',NULL,'291c8841-94a5-4cdb-9eb8-fef40709aee5','all'),
('15','demo','1U-sbgEhGEURCX3cFpl5gfVlvgS3XwCFLmnpzfqTDsfw','https://docs.google.com/document/d/1U-sbgEhGEURCX3cFpl5gfVlvgS3XwCFLmnpzfqTDsfw/edit','608dc9d1-26e0-441d-8144-45f74c53a846',NULL,'general','0','2025-11-02 23:13:23','2025-11-03 11:02:53',NULL,'a5dd0abd-b5cc-43ff-a22e-652e30ab7d28','all'),
('16','sssss','1WAHYOpF6sO7pPWLKBYHCe_MgqmTo_yquvm4bz8b5sUE','https://docs.google.com/document/d/1WAHYOpF6sO7pPWLKBYHCe_MgqmTo_yquvm4bz8b5sUE/edit','d84019a3-575f-403c-aa12-02482422bcfa',NULL,'general','0','2025-11-03 00:12:42','2025-11-03 00:12:42',NULL,'83f0e57d-6905-49b6-99a4-2b3df2595644','all'),
('17','sample','1tG3BRIav2NL_Em4VC5GaqHhhGBGZDAyKeHhn8iusWTs','https://docs.google.com/document/d/1tG3BRIav2NL_Em4VC5GaqHhhGBGZDAyKeHhn8iusWTs/edit','608dc9d1-26e0-441d-8144-45f74c53a846','1','general','0','2025-11-03 10:48:25','2025-11-03 11:03:07',NULL,'63fe666d-82e2-4537-83fc-aa778ce17b08','all'),
('18','demooooooo','11dNJZYX52MGBFHU1eMJyftTNzdpCh2gkwjOXG7Sfczs','https://docs.google.com/document/d/11dNJZYX52MGBFHU1eMJyftTNzdpCh2gkwjOXG7Sfczs/edit','d84019a3-575f-403c-aa12-02482422bcfa',NULL,'general','0','2025-12-02 08:53:05','2025-12-02 08:53:05',NULL,'63fe666d-82e2-4537-83fc-aa778ce17b08','all'),
('19','ddd','1RpalcqR1o2g90tCRpP-63j_DamOSrtG5Be71n-xomUY','https://docs.google.com/document/d/1RpalcqR1o2g90tCRpP-63j_DamOSrtG5Be71n-xomUY/edit','608dc9d1-26e0-441d-8144-45f74c53a846',NULL,'general','0','2025-12-31 18:24:41','2025-12-31 18:24:41',NULL,NULL,'all'),
('20','Developers','1BCrxVpcdRVirDhSJ1LhlYGUbCtjDSqiXQ0rsyzyQG9U','https://docs.google.com/document/d/1BCrxVpcdRVirDhSJ1LhlYGUbCtjDSqiXQ0rsyzyQG9U/edit','608dc9d1-26e0-441d-8144-45f74c53a846',NULL,'general','0','2025-12-31 18:26:32','2025-12-31 18:26:32',NULL,NULL,'developers'),
('21','dev','1yALwvGBf_eRa7pZOEZTQjKQbAjfJYGkps5IOMhCJUF8','https://docs.google.com/document/d/1yALwvGBf_eRa7pZOEZTQjKQbAjfJYGkps5IOMhCJUF8/edit','608dc9d1-26e0-441d-8144-45f74c53a846',NULL,'general','0','2025-12-31 18:28:51','2025-12-31 18:28:51',NULL,NULL,'developers'),
('22','deve','1FKpYjAFFf-4nHzopzSoXWJHX1ALrPK1MAmE91XmioaI','https://docs.google.com/document/d/1FKpYjAFFf-4nHzopzSoXWJHX1ALrPK1MAmE91XmioaI/edit','608dc9d1-26e0-441d-8144-45f74c53a846',NULL,'general','0','2025-12-31 18:50:56','2025-12-31 18:50:56',NULL,NULL,'developers'),
('23','devel','1_qQgmudp5cA3q-ffEiJ0HAVgrtZINwbsWR7uKArZ7g4','https://docs.google.com/document/d/1_qQgmudp5cA3q-ffEiJ0HAVgrtZINwbsWR7uKArZ7g4/edit','608dc9d1-26e0-441d-8144-45f74c53a846',NULL,'general','0','2025-12-31 18:53:41','2025-12-31 18:53:41',NULL,NULL,'developers'),
('24','test 01','1kClVtXVjVf9udAj6d0vvG93e43BZoCqHh1JDQuZdk08','https://docs.google.com/document/d/1kClVtXVjVf9udAj6d0vvG93e43BZoCqHh1JDQuZdk08/edit','608dc9d1-26e0-441d-8144-45f74c53a846',NULL,'general','0','2025-12-31 18:54:57','2025-12-31 18:54:57',NULL,NULL,'all'),
('25','d','1f49dCbc9jSxEhlhQd-JwMKBoRp4aolRAGOPVTl8VYyo','https://docs.google.com/document/d/1f49dCbc9jSxEhlhQd-JwMKBoRp4aolRAGOPVTl8VYyo/edit','608dc9d1-26e0-441d-8144-45f74c53a846',NULL,'general','0','2025-12-31 19:04:07','2025-12-31 19:04:07',NULL,NULL,'developers'),
('26','e','1BB5kXUpCz9aI4I1NVWqGOrRMTTWLGKP3G0Fpi87idNs','https://docs.google.com/document/d/1BB5kXUpCz9aI4I1NVWqGOrRMTTWLGKP3G0Fpi87idNs/edit','608dc9d1-26e0-441d-8144-45f74c53a846',NULL,'general','0','2025-12-31 19:09:45','2025-12-31 19:12:22',NULL,NULL,'testers'),
('27','rrsfjnsdfjdf','19bCEvHIfMLlZdM-AI_1IvqZhgL4Vy0EXn9tqKd9rD2o','https://docs.google.com/document/d/19bCEvHIfMLlZdM-AI_1IvqZhgL4Vy0EXn9tqKd9rD2o/edit','608dc9d1-26e0-441d-8144-45f74c53a846',NULL,'general','0','2026-01-02 00:42:27','2026-01-02 01:05:20',NULL,'63fe666d-82e2-4537-83fc-aa778ce17b08','all'),
('28','tes','1T_9Xo5TrrORu2srKrbJPmhDbSqEMQp1zNa01Jzn2MlI','https://docs.google.com/document/d/1T_9Xo5TrrORu2srKrbJPmhDbSqEMQp1zNa01Jzn2MlI/edit','608dc9d1-26e0-441d-8144-45f74c53a846',NULL,'general','0','2026-01-02 01:08:40','2026-01-02 01:11:46',NULL,'291c8841-94a5-4cdb-9eb8-fef40709aee5,63fe666d-82e2-4537-83fc-aa778ce17b08,83f0e57d-6905-49b6-99a4-2b3df2595644','all'),
('29','tetdtatsztstd','1i1QmkKKADj6HyqCKCG1dHcrWb1eyz4ygCm6FN31c_O4','https://docs.google.com/document/d/1i1QmkKKADj6HyqCKCG1dHcrWb1eyz4ygCm6FN31c_O4/edit','608dc9d1-26e0-441d-8144-45f74c53a846',NULL,'general','0','2026-01-02 01:12:31','2026-01-02 01:13:49',NULL,'63fe666d-82e2-4537-83fc-aa778ce17b08,83f0e57d-6905-49b6-99a4-2b3df2595644,a5dd0abd-b5cc-43ff-a22e-652e30ab7d28','admins,developers');


-- Table structure for table `user_feedback`
DROP TABLE IF EXISTS `user_feedback`;
CREATE TABLE `user_feedback` (
  `id` varchar(36) NOT NULL,
  `user_id` varchar(36) NOT NULL,
  `rating` tinyint(1) NOT NULL COMMENT 'Rating from 1-5 (1=angry, 2=sad, 3=neutral, 4=happy, 5=star-struck)',
  `feedback_text` text DEFAULT NULL COMMENT 'Optional text feedback',
  `submitted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_feedback_user_id` (`user_id`),
  KEY `idx_user_feedback_submitted_at` (`submitted_at`),
  KEY `idx_user_feedback_rating` (`rating`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `user_feedback`
INSERT INTO `user_feedback` VALUES
('12157b83-b051-4c20-aaa1-4b07901fec87','c18ce191-e34b-4ca7-b69b-6a78488d3de5','5','jjk','2025-11-03 00:23:42'),
('15ddbf00-04e5-48a2-9acb-3017f6f6e57b','32f9e3be-4029-486a-a1e0-9ba62f97bd99','5',NULL,'2025-11-02 16:46:45'),
('ac18051c-d454-41cf-95b4-6cba1c8d06a1','e1e7aecc-96f9-452b-b60c-e9541c27ea3d','5',NULL,'2025-11-03 00:19:32'),
('d7a4d6ad-a1c2-4863-9a7c-3c7e851f307f','d84019a3-575f-403c-aa12-02482422bcfa','5','sdsdsd','2025-11-02 23:00:05'),
('fa8688d2-dc47-4332-9226-5feffa3c4460','608dc9d1-26e0-441d-8144-45f74c53a846','5','Hello','2025-11-02 18:34:50');


-- Table structure for table `user_feedback_tracking`
DROP TABLE IF EXISTS `user_feedback_tracking`;
CREATE TABLE `user_feedback_tracking` (
  `user_id` varchar(36) NOT NULL,
  `has_submitted_feedback` tinyint(1) NOT NULL DEFAULT 0,
  `first_submission_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`user_id`),
  KEY `idx_user_feedback_tracking_submitted` (`has_submitted_feedback`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `user_feedback_tracking`
INSERT INTO `user_feedback_tracking` VALUES
('3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2025-11-03 10:58:37'),
('32f9e3be-4029-486a-a1e0-9ba62f97bd99','1','2025-11-02 16:46:45','2025-11-02 16:46:45'),
('366b0b18-bf5c-4206-b1c6-65aa1c8c084a','0',NULL,'2025-12-02 01:53:57'),
('436f9705-5c13-4f8c-934a-65bff6693885','0',NULL,'2025-12-02 01:37:40'),
('608dc9d1-26e0-441d-8144-45f74c53a846','1','2025-11-02 18:34:50','2025-11-02 18:34:50'),
('c18ce191-e34b-4ca7-b69b-6a78488d3de5','1','2025-11-03 00:23:42','2025-11-03 00:23:42'),
('cd95cbc1-be9d-44aa-b357-5cc67400c95d','0',NULL,'2025-12-02 01:25:27'),
('d84019a3-575f-403c-aa12-02482422bcfa','1','2025-11-02 23:00:05','2025-11-02 23:00:05'),
('e1e7aecc-96f9-452b-b60c-e9541c27ea3d','1','2025-11-03 00:19:32','2025-11-03 00:19:32'),
('f78f9246-48e3-4a9d-a5fb-1b70d4bc7d68','0',NULL,'2025-11-03 01:17:45');


-- Table structure for table `user_notifications`
DROP TABLE IF EXISTS `user_notifications`;
CREATE TABLE `user_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `notification_id` int(11) NOT NULL,
  `user_id` varchar(36) NOT NULL,
  `read` tinyint(1) NOT NULL DEFAULT 0,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_notification` (`user_id`,`notification_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_notification_id` (`notification_id`),
  KEY `idx_read` (`read`),
  KEY `idx_user_read` (`user_id`,`read`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `user_notifications_ibfk_1` FOREIGN KEY (`notification_id`) REFERENCES `notifications` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_notifications_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=192 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `user_notifications`
INSERT INTO `user_notifications` VALUES
('1','114','d84019a3-575f-403c-aa12-02482422bcfa','1','2025-11-03 19:43:57','2025-11-03 10:26:46'),
('2','115','c18ce191-e34b-4ca7-b69b-6a78488d3de5','0',NULL,'2025-11-03 10:27:16'),
('3','117','d84019a3-575f-403c-aa12-02482422bcfa','1','2025-11-03 19:43:57','2025-11-03 10:27:45'),
('4','117','c18ce191-e34b-4ca7-b69b-6a78488d3de5','0',NULL,'2025-11-03 10:27:45'),
('5','118','d84019a3-575f-403c-aa12-02482422bcfa','1','2025-11-03 19:43:57','2025-11-03 10:29:52'),
('6','118','c18ce191-e34b-4ca7-b69b-6a78488d3de5','0',NULL,'2025-11-03 10:29:52'),
('7','119','d84019a3-575f-403c-aa12-02482422bcfa','1','2025-11-03 19:43:57','2025-11-03 10:40:37'),
('8','119','c18ce191-e34b-4ca7-b69b-6a78488d3de5','0',NULL,'2025-11-03 10:40:37'),
('9','120','d84019a3-575f-403c-aa12-02482422bcfa','1','2025-11-03 19:43:57','2025-11-03 10:43:12'),
('10','120','c18ce191-e34b-4ca7-b69b-6a78488d3de5','0',NULL,'2025-11-03 10:43:12'),
('15','126','c18ce191-e34b-4ca7-b69b-6a78488d3de5','0',NULL,'2025-11-03 23:49:07'),
('16','126','3045985b-50f9-44e5-9adf-bc6879945272','1','2025-11-04 01:21:51','2025-11-03 23:49:07'),
('18','114','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2025-11-03 10:26:46'),
('20','114','e1e7aecc-96f9-452b-b60c-e9541c27ea3d','0',NULL,'2025-11-03 10:26:46'),
('21','114','f78f9246-48e3-4a9d-a5fb-1b70d4bc7d68','0',NULL,'2025-11-03 10:26:46'),
('22','115','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2025-11-03 10:27:16'),
('24','115','d84019a3-575f-403c-aa12-02482422bcfa','0',NULL,'2025-11-03 10:27:16'),
('25','115','e1e7aecc-96f9-452b-b60c-e9541c27ea3d','0',NULL,'2025-11-03 10:27:16'),
('26','115','f78f9246-48e3-4a9d-a5fb-1b70d4bc7d68','0',NULL,'2025-11-03 10:27:16'),
('27','117','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2025-11-03 10:27:45'),
('29','117','e1e7aecc-96f9-452b-b60c-e9541c27ea3d','0',NULL,'2025-11-03 10:27:45'),
('30','117','f78f9246-48e3-4a9d-a5fb-1b70d4bc7d68','0',NULL,'2025-11-03 10:27:45'),
('31','118','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2025-11-03 10:29:52'),
('33','118','e1e7aecc-96f9-452b-b60c-e9541c27ea3d','0',NULL,'2025-11-03 10:29:52'),
('34','118','f78f9246-48e3-4a9d-a5fb-1b70d4bc7d68','0',NULL,'2025-11-03 10:29:52'),
('35','119','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2025-11-03 10:40:37'),
('37','119','e1e7aecc-96f9-452b-b60c-e9541c27ea3d','0',NULL,'2025-11-03 10:40:37'),
('38','119','f78f9246-48e3-4a9d-a5fb-1b70d4bc7d68','0',NULL,'2025-11-03 10:40:37'),
('39','120','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2025-11-03 10:43:12'),
('41','120','e1e7aecc-96f9-452b-b60c-e9541c27ea3d','0',NULL,'2025-11-03 10:43:12'),
('42','120','f78f9246-48e3-4a9d-a5fb-1b70d4bc7d68','0',NULL,'2025-11-03 10:43:12'),
('43','123','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2025-11-03 11:14:43'),
('44','123','d84019a3-575f-403c-aa12-02482422bcfa','0',NULL,'2025-11-03 11:14:43'),
('45','123','e1e7aecc-96f9-452b-b60c-e9541c27ea3d','0',NULL,'2025-11-03 11:14:43'),
('46','123','f78f9246-48e3-4a9d-a5fb-1b70d4bc7d68','0',NULL,'2025-11-03 11:14:43'),
('47','124','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2025-11-03 11:15:14'),
('48','124','d84019a3-575f-403c-aa12-02482422bcfa','0',NULL,'2025-11-03 11:15:14'),
('49','124','e1e7aecc-96f9-452b-b60c-e9541c27ea3d','0',NULL,'2025-11-03 11:15:14'),
('50','124','f78f9246-48e3-4a9d-a5fb-1b70d4bc7d68','0',NULL,'2025-11-03 11:15:14'),
('51','125','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2025-11-03 11:16:27'),
('52','125','d84019a3-575f-403c-aa12-02482422bcfa','0',NULL,'2025-11-03 11:16:27'),
('53','125','e1e7aecc-96f9-452b-b60c-e9541c27ea3d','0',NULL,'2025-11-03 11:16:27'),
('54','125','f78f9246-48e3-4a9d-a5fb-1b70d4bc7d68','0',NULL,'2025-11-03 11:16:27'),
('81','112','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2025-11-03 00:26:25'),
('83','112','c18ce191-e34b-4ca7-b69b-6a78488d3de5','0',NULL,'2025-11-03 00:26:25'),
('84','113','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2025-11-03 00:26:31'),
('86','113','c18ce191-e34b-4ca7-b69b-6a78488d3de5','0',NULL,'2025-11-03 00:26:31'),
('87','116','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2025-11-03 10:27:21'),
('89','116','c18ce191-e34b-4ca7-b69b-6a78488d3de5','0',NULL,'2025-11-03 10:27:21'),
('90','127','3045985b-50f9-44e5-9adf-bc6879945272','1','2025-11-04 01:21:50','2025-11-03 23:49:08'),
('92','127','c18ce191-e34b-4ca7-b69b-6a78488d3de5','0',NULL,'2025-11-03 23:49:08'),
('96','121','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2025-11-03 10:46:13'),
('99','128','c18ce191-e34b-4ca7-b69b-6a78488d3de5','0',NULL,'2025-11-04 01:33:11'),
('101','130','c18ce191-e34b-4ca7-b69b-6a78488d3de5','0',NULL,'2025-11-04 01:34:18'),
('103','131','c18ce191-e34b-4ca7-b69b-6a78488d3de5','0',NULL,'2025-11-04 01:35:05'),
('105','132','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2025-11-04 01:38:58'),
('106','133','d84019a3-575f-403c-aa12-02482422bcfa','0',NULL,'2025-11-04 01:48:22'),
('107','133','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2025-11-04 01:48:22'),
('108','134','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2025-11-04 01:50:22'),
('109','135','d84019a3-575f-403c-aa12-02482422bcfa','0',NULL,'2025-11-04 01:51:45'),
('110','135','3045985b-50f9-44e5-9adf-bc6879945272','1','2025-11-04 01:58:39','2025-11-04 01:51:45'),
('111','136','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2025-12-02 00:09:31'),
('112','136','d84019a3-575f-403c-aa12-02482422bcfa','0',NULL,'2025-12-02 00:09:31'),
('113','137','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2025-12-02 00:14:35'),
('114','137','d84019a3-575f-403c-aa12-02482422bcfa','0',NULL,'2025-12-02 00:14:35'),
('115','138','d84019a3-575f-403c-aa12-02482422bcfa','0',NULL,'2025-12-02 00:39:20'),
('116','138','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2025-12-02 00:39:20'),
('117','140','d84019a3-575f-403c-aa12-02482422bcfa','0',NULL,'2025-12-02 00:50:30'),
('118','140','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2025-12-02 00:50:30'),
('119','141','d84019a3-575f-403c-aa12-02482422bcfa','0',NULL,'2025-12-02 01:04:42'),
('120','141','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2025-12-02 01:04:42'),
('121','142','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2025-12-02 01:47:55'),
('122','144','c18ce191-e34b-4ca7-b69b-6a78488d3de5','0',NULL,'2025-12-02 01:48:10'),
('123','144','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2025-12-02 01:48:10'),
('124','146','c18ce191-e34b-4ca7-b69b-6a78488d3de5','0',NULL,'2025-12-02 01:49:21'),
('125','146','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2025-12-02 01:49:21'),
('126','148','c18ce191-e34b-4ca7-b69b-6a78488d3de5','0',NULL,'2025-12-02 01:52:01'),
('127','148','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2025-12-02 01:52:01'),
('128','150','c18ce191-e34b-4ca7-b69b-6a78488d3de5','0',NULL,'2025-12-02 01:52:53'),
('129','150','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2025-12-02 01:52:53'),
('130','152','c18ce191-e34b-4ca7-b69b-6a78488d3de5','0',NULL,'2025-12-02 01:56:23'),
('131','152','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2025-12-02 01:56:23'),
('132','152','366b0b18-bf5c-4206-b1c6-65aa1c8c084a','0',NULL,'2025-12-02 01:56:23'),
('133','154','c18ce191-e34b-4ca7-b69b-6a78488d3de5','0',NULL,'2025-12-02 01:56:39'),
('134','154','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2025-12-02 01:56:39'),
('135','154','366b0b18-bf5c-4206-b1c6-65aa1c8c084a','0',NULL,'2025-12-02 01:56:39'),
('136','156','d84019a3-575f-403c-aa12-02482422bcfa','0',NULL,'2025-12-02 09:03:02'),
('137','156','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2025-12-02 09:03:02'),
('138','156','366b0b18-bf5c-4206-b1c6-65aa1c8c084a','0',NULL,'2025-12-02 09:03:02'),
('139','157','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2025-12-02 09:04:42'),
('140','157','366b0b18-bf5c-4206-b1c6-65aa1c8c084a','0',NULL,'2025-12-02 09:04:42'),
('141','157','d84019a3-575f-403c-aa12-02482422bcfa','0',NULL,'2025-12-02 09:04:42'),
('142','158','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2025-12-02 09:20:22'),
('143','158','366b0b18-bf5c-4206-b1c6-65aa1c8c084a','0',NULL,'2025-12-02 09:20:22'),
('144','160','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2025-12-02 09:21:44'),
('145','160','366b0b18-bf5c-4206-b1c6-65aa1c8c084a','0',NULL,'2025-12-02 09:21:44'),
('147','162','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2025-12-06 01:26:15'),
('148','162','366b0b18-bf5c-4206-b1c6-65aa1c8c084a','0',NULL,'2025-12-06 01:26:15'),
('149','164','d84019a3-575f-403c-aa12-02482422bcfa','0',NULL,'2026-01-02 00:15:10'),
('150','164','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2026-01-02 00:15:10'),
('151','164','366b0b18-bf5c-4206-b1c6-65aa1c8c084a','0',NULL,'2026-01-02 00:15:10'),
('152','165','d84019a3-575f-403c-aa12-02482422bcfa','0',NULL,'2026-01-02 00:16:31'),
('153','165','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2026-01-02 00:16:31'),
('154','165','366b0b18-bf5c-4206-b1c6-65aa1c8c084a','0',NULL,'2026-01-02 00:16:31'),
('155','168','c18ce191-e34b-4ca7-b69b-6a78488d3de5','0',NULL,'2026-01-02 01:14:16'),
('156','168','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2026-01-02 01:14:16'),
('157','168','366b0b18-bf5c-4206-b1c6-65aa1c8c084a','0',NULL,'2026-01-02 01:14:16'),
('158','170','c18ce191-e34b-4ca7-b69b-6a78488d3de5','0',NULL,'2026-01-02 01:15:43'),
('159','170','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2026-01-02 01:15:43'),
('160','170','366b0b18-bf5c-4206-b1c6-65aa1c8c084a','0',NULL,'2026-01-02 01:15:43'),
('161','172','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2026-01-02 01:17:13'),
('162','172','366b0b18-bf5c-4206-b1c6-65aa1c8c084a','0',NULL,'2026-01-02 01:17:13'),
('163','174','c18ce191-e34b-4ca7-b69b-6a78488d3de5','0',NULL,'2026-01-02 01:17:49'),
('164','174','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2026-01-02 01:17:49'),
('166','176','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2026-01-02 01:18:00'),
('168','178','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2026-01-02 01:19:59'),
('169','178','366b0b18-bf5c-4206-b1c6-65aa1c8c084a','0',NULL,'2026-01-02 01:19:59'),
('171','180','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2026-01-02 01:20:48'),
('172','180','366b0b18-bf5c-4206-b1c6-65aa1c8c084a','0',NULL,'2026-01-02 01:20:48'),
('174','182','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2026-01-02 01:21:43'),
('175','182','366b0b18-bf5c-4206-b1c6-65aa1c8c084a','0',NULL,'2026-01-02 01:21:43'),
('177','184','c18ce191-e34b-4ca7-b69b-6a78488d3de5','0',NULL,'2026-01-02 01:23:20'),
('178','184','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2026-01-02 01:23:20'),
('179','184','366b0b18-bf5c-4206-b1c6-65aa1c8c084a','0',NULL,'2026-01-02 01:23:20'),
('181','186','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2026-01-02 01:25:44'),
('182','186','366b0b18-bf5c-4206-b1c6-65aa1c8c084a','0',NULL,'2026-01-02 01:25:44'),
('184','188','c18ce191-e34b-4ca7-b69b-6a78488d3de5','0',NULL,'2026-01-02 01:28:05'),
('185','188','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2026-01-02 01:28:05'),
('186','188','366b0b18-bf5c-4206-b1c6-65aa1c8c084a','0',NULL,'2026-01-02 01:28:05'),
('188','190','c18ce191-e34b-4ca7-b69b-6a78488d3de5','0',NULL,'2026-01-02 01:29:27'),
('189','190','3045985b-50f9-44e5-9adf-bc6879945272','0',NULL,'2026-01-02 01:29:27'),
('190','190','366b0b18-bf5c-4206-b1c6-65aa1c8c084a','0',NULL,'2026-01-02 01:29:27');


-- Table structure for table `user_otps`
DROP TABLE IF EXISTS `user_otps`;
CREATE TABLE `user_otps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `otp` varchar(6) NOT NULL,
  `expires_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_otps_email` (`email`),
  KEY `idx_user_otps_phone` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=124 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `user_otps`
INSERT INTO `user_otps` VALUES
('103','moajmalnk@gmail.com',NULL,'255521','2025-11-02 17:26:03','2025-11-02 17:21:03'),
('104','moajmalnk@gmail.com',NULL,'451367','2025-11-02 17:31:29','2025-11-02 17:26:29'),
('105','moajmalnk@gmail.com',NULL,'732128','2025-11-02 17:33:29','2025-11-02 17:28:29'),
('106','moajmalnk@gmail.com',NULL,'906426','2025-11-02 17:33:54','2025-11-02 17:28:54'),
('107','moajmalnk@gmail.com',NULL,'551943','2025-11-02 17:34:20','2025-11-02 17:29:20'),
('108','moajmalnk@gmail.com',NULL,'156890','2025-11-02 17:34:52','2025-11-02 17:29:52'),
('109','moajmalnk@gmail.com',NULL,'630055','2025-11-02 17:35:32','2025-11-02 17:30:32'),
('110','moajmalnk@gmail.com',NULL,'645175','2025-11-02 17:36:00','2025-11-02 17:31:00'),
('111','moajmalnk@gmail.com',NULL,'625836','2025-11-02 17:37:08','2025-11-02 17:32:08'),
('112','moajmalnk@gmail.com',NULL,'099496','2025-11-02 17:37:44','2025-11-02 17:32:44'),
('113','moajmalnk@gmail.com',NULL,'196890','2025-11-02 17:40:44','2025-11-02 17:35:44'),
('114','moajmalnk@gmail.com',NULL,'293121','2025-11-02 17:41:07','2025-11-02 17:36:07'),
('115','moajmalnk@gmail.com',NULL,'451807','2025-11-02 17:41:35','2025-11-02 17:36:35'),
('116','moajmalnk@gmail.com',NULL,'270847','2025-11-02 17:41:52','2025-11-02 17:36:52'),
('117','moajmalnk@gmail.com',NULL,'599797','2025-11-02 17:42:32','2025-11-02 17:37:32'),
('118','moajmalnk@gmail.com',NULL,'497325','2025-11-02 17:42:49','2025-11-02 17:37:49'),
('119','moajmalnk@gmail.com',NULL,'901149','2025-11-02 17:45:44','2025-11-02 17:40:44'),
('120','moajmalnk@gmail.com',NULL,'969008','2025-11-02 17:46:00','2025-11-02 17:41:00'),
('121','moajmalnk@gmail.com',NULL,'348128','2025-11-02 17:46:10','2025-11-02 17:41:10'),
('122','moajmalnk@gmail.com',NULL,'852792','2025-11-02 17:48:22','2025-11-02 17:43:22'),
('123','moajmalnk@gmail.com',NULL,'033463','2025-11-02 17:49:23','2025-11-02 17:44:23');


-- Table structure for table `user_permissions`
DROP TABLE IF EXISTS `user_permissions`;
CREATE TABLE `user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(36) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `project_id` varchar(36) DEFAULT NULL,
  `granted` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_permission_project` (`user_id`,`permission_id`,`project_id`),
  KEY `idx_user_permissions_user` (`user_id`),
  KEY `idx_user_permissions_permission` (`permission_id`),
  KEY `idx_user_permissions_project` (`project_id`),
  KEY `idx_user_permissions_granted` (`granted`)
) ENGINE=InnoDB AUTO_INCREMENT=277 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Table structure for table `user_status`
DROP TABLE IF EXISTS `user_status`;
CREATE TABLE `user_status` (
  `id` varchar(36) NOT NULL,
  `user_id` varchar(36) NOT NULL,
  `media_type` enum('text','image','video') NOT NULL DEFAULT 'text',
  `media_url` varchar(500) DEFAULT NULL,
  `text_content` text DEFAULT NULL,
  `background_color` varchar(7) DEFAULT NULL COMMENT 'Hex color for text status',
  `expires_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT '24 hours from creation',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_status_user` (`user_id`),
  KEY `idx_user_status_expires` (`expires_at`),
  KEY `idx_user_status_created` (`created_at`),
  CONSTRAINT `user_status_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for table `user_tasks`
DROP TABLE IF EXISTS `user_tasks`;
CREATE TABLE `user_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(36) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `project_id` varchar(36) DEFAULT NULL,
  `priority` enum('low','medium','high') DEFAULT 'medium',
  `status` enum('todo','in_progress','done','blocked') DEFAULT 'todo',
  `due_date` date DEFAULT NULL,
  `period` enum('daily','weekly','monthly','yearly','custom') DEFAULT 'daily',
  `expected_hours` decimal(6,2) DEFAULT 0.00,
  `spent_hours` decimal(10,2) DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_project` (`project_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `user_tasks`
INSERT INTO `user_tasks` VALUES
('12','608dc9d1-26e0-441d-8144-45f74c53a846','dddd','sdsdsd',NULL,'high','done','2025-11-26','weekly','0.00','0.00','2025-11-03 01:28:14','2025-11-03 01:28:18'),
('13','e1e7aecc-96f9-452b-b60c-e9541c27ea3d','sdsdsdsd','sdsdsd',NULL,'medium','done','2025-11-27','daily','0.00','0.00','2025-11-03 01:47:11','2025-11-03 01:47:17');


-- Table structure for table `users`
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` varchar(36) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `google_sub` varchar(255) DEFAULT NULL COMMENT 'Google User ID (sub claim) from OAuth token',
  `phone` varchar(20) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `password_changed_at` timestamp NULL DEFAULT NULL,
  `role` enum('admin','developer','tester','user') NOT NULL DEFAULT 'user',
  `role_id` int(11) DEFAULT NULL,
  `is_online` tinyint(1) NOT NULL DEFAULT 0,
  `last_seen` timestamp NULL DEFAULT NULL,
  `profile_picture` varchar(500) DEFAULT NULL,
  `profile_picture_url` varchar(255) DEFAULT NULL COMMENT 'URL of user profile picture from Google',
  `status_message` varchar(255) DEFAULT NULL COMMENT 'WhatsApp-like status text',
  `show_online_status` tinyint(1) NOT NULL DEFAULT 1,
  `show_last_seen` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `last_login_at` datetime DEFAULT NULL COMMENT 'Timestamp of last successful login',
  `fcm_token` varchar(255) DEFAULT NULL,
  `last_active_at` datetime DEFAULT NULL COMMENT 'Timestamp of last heartbeat for presence tracking',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `id_2` (`id`),
  UNIQUE KEY `idx_users_phone_unique` (`phone`),
  UNIQUE KEY `idx_users_google_sub` (`google_sub`),
  KEY `idx_users_role` (`role`),
  KEY `idx_users_email` (`email`),
  KEY `idx_users_id_role` (`id`,`role`),
  KEY `idx_users_role_email` (`role`,`email`),
  KEY `idx_users_created_at` (`created_at`),
  KEY `idx_users_covering_profile` (`id`,`username`,`email`,`role`,`created_at`,`updated_at`),
  KEY `idx_users_fcm_token` (`fcm_token`),
  KEY `idx_users_phone` (`phone`),
  KEY `idx_users_is_online` (`is_online`),
  KEY `idx_users_last_seen` (`last_seen`),
  KEY `idx_users_last_login_at` (`last_login_at`),
  KEY `idx_users_last_active_at` (`last_active_at`),
  KEY `idx_users_role_id` (`role_id`),
  CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `users`
INSERT INTO `users` VALUES
('3045985b-50f9-44e5-9adf-bc6879945272','moajmalnk22','ajmalnk10091@gmail.com','107382277436991019043','+918075002575','$2y$10$/jLSjD3M2cY2qvyIGLP4I.Dm7UgXTQEWKTmABRyjI/rJAvmuGrRVm',NULL,'admin','1','0',NULL,NULL,'https://lh3.googleusercontent.com/a/ACg8ocL5Gzurn-8ct667yFWDaqLV-moFH-oEy-fDsPAGINR3dxqWI8IW=s96-c',NULL,'1','1','2025-11-03 10:58:37','2026-01-01 23:16:50','2026-01-01 23:16:50',NULL,'2026-01-01 23:16:50'),
('366b0b18-bf5c-4206-b1c6-65aa1c8c084a','lubaba','info.ajmaslnk@gmail.com',NULL,'+918848676627','$2y$10$y8Jgt2TW/X08PTakvZ9W0Oq.J4sXeXFAByleLMM/xrBuQ3DEJaFnG',NULL,'admin','1','0',NULL,NULL,NULL,NULL,'1','1','2025-12-02 01:53:57','2026-01-02 02:07:37',NULL,NULL,'2026-01-02 02:07:37'),
('608dc9d1-26e0-441d-8144-45f74c53a846','moajmalnk','moajmalnk@gmail.com',NULL,'+918848676626','$2y$10$1O1r92rttzz6gEpcqM/p0.NzH1EK3B5MsLXteU6aAmAmwYYZ9pQn.','2025-11-02 23:40:46','admin','1','0',NULL,NULL,NULL,NULL,'1','1','2025-04-10 17:52:47','2026-01-02 10:28:29','2025-10-24 11:51:32','chPPGnBoWVmGJ8jbwdLmKT:APA91bFlWKzNlVj6vQNfA0wXQHNT7GGbp0AzcGZOohzpiZNKkrBKw_OUXzBK2_DWdfy4A499j_s2-RBXFs26W_7aAu_4L-cDzlgyPEirS5--UH57M8zHi4Y','2026-01-02 10:28:29'),
('c18ce191-e34b-4ca7-b69b-6a78488d3de5','tester','hi.ajmalnk@gmail.com',NULL,'+918848344627','$2y$10$hE45Bi6zB5YT6tA6hvhqsuv80ms082Akpef1fcm7vpCO3Wsl6YRNm',NULL,'tester','3','0',NULL,NULL,NULL,NULL,'1','1','2025-08-22 23:27:27','2026-01-02 10:28:15','2025-09-10 18:42:52','ematIBhwKIzG-LIs87i8oT:APA91bFcsxXQMVrzbcbwE34nP_wl-8l8KoXu7ZATn7X5GJAI2ZPD-gfrk0esR4X9o8QKMh8vYKrSnYmurKnBL3jOwRdLUy9xu-DDePCq1MDWfQj3V-Sh8J8','2026-01-02 10:28:15'),
('d84019a3-575f-403c-aa12-02482422bcfa','developer','info.ajmalnk@gmail.com',NULL,'+918086995559','$2y$10$2eZYNi3hk3Am2waJAcfQuuD2m4WBRV74oJtB30oVXvMXag.93unkq',NULL,'developer','2','0',NULL,NULL,NULL,NULL,'1','1','2025-04-18 23:04:28','2026-01-02 10:28:15','2025-10-08 01:52:51','ematIBhwKIzG-LIs87i8oT:APA91bFcsxXQMVrzbcbwE34nP_wl-8l8KoXu7ZATn7X5GJAI2ZPD-gfrk0esR4X9o8QKMh8vYKrSnYmurKnBL3jOwRdLUy9xu-DDePCq1MDWfQj3V-Sh8J8','2026-01-02 10:28:15'),
('e1e7aecc-96f9-452b-b60c-e9541c27ea3d','dev','ajmalnk04@gmail.com',NULL,'+919526272123','$2y$10$jt4lNe54TPHD.Xv0BsMsvujfJ5s5swMb0GI4olz06.6u.APejMrfC',NULL,'developer','2','0',NULL,NULL,NULL,NULL,'1','1','2025-11-03 00:14:52','2026-01-02 01:18:05',NULL,'ematIBhwKIzG-LIs87i8oT:APA91bFcsxXQMVrzbcbwE34nP_wl-8l8KoXu7ZATn7X5GJAI2ZPD-gfrk0esR4X9o8QKMh8vYKrSnYmurKnBL3jOwRdLUy9xu-DDePCq1MDWfQj3V-Sh8J8','2026-01-02 01:18:05'),
('f78f9246-48e3-4a9d-a5fb-1b70d4bc7d68','aju','premium.codomail@gmail.com',NULL,'+918590961281','$2y$10$fpf02Va3Mlse4AIBaME6xesQaxIK5yKQ.xjntPE5HZEIYD6ehrMY2',NULL,'user','16','0',NULL,NULL,NULL,NULL,'1','1','2025-11-03 01:17:45','2025-12-02 01:20:56',NULL,NULL,NULL);


-- Table structure for table `voice_note_history`
DROP TABLE IF EXISTS `voice_note_history`;
CREATE TABLE `voice_note_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `voice_note_id` int(11) NOT NULL,
  `status` enum('sent','delivered','read','failed') NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`details`)),
  PRIMARY KEY (`id`),
  KEY `idx_voice_note_id` (`voice_note_id`),
  KEY `idx_status` (`status`),
  KEY `idx_timestamp` (`timestamp`),
  CONSTRAINT `voice_note_history_ibfk_1` FOREIGN KEY (`voice_note_id`) REFERENCES `voice_notes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for table `voice_notes`
DROP TABLE IF EXISTS `voice_notes`;
CREATE TABLE `voice_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phone` varchar(20) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `duration` int(11) NOT NULL DEFAULT 0,
  `sent_by` varchar(36) NOT NULL,
  `status` enum('sent','delivered','read','failed') DEFAULT 'sent',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_phone` (`phone`),
  KEY `idx_sent_by` (`sent_by`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_status` (`status`),
  CONSTRAINT `voice_notes_ibfk_1` FOREIGN KEY (`sent_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for table `work_sessions`
DROP TABLE IF EXISTS `work_sessions`;
CREATE TABLE `work_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(36) NOT NULL,
  `submission_date` date NOT NULL,
  `check_in_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `check_out_time` timestamp NULL DEFAULT NULL,
  `total_duration_seconds` int(11) DEFAULT 0,
  `net_duration_seconds` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `session_notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_date` (`user_id`,`submission_date`),
  KEY `idx_active` (`user_id`,`is_active`),
  KEY `idx_check_in` (`check_in_time`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for table `work_submissions`
DROP TABLE IF EXISTS `work_submissions`;
CREATE TABLE `work_submissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(36) NOT NULL,
  `submission_date` date NOT NULL,
  `start_time` time DEFAULT NULL,
  `check_in_time` timestamp NULL DEFAULT NULL,
  `planned_projects` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`planned_projects`)),
  `planned_work` text DEFAULT NULL,
  `planned_work_status` enum('not_started','in_progress','completed','blocked','cancelled') DEFAULT 'not_started' COMMENT 'Status of the planned work: not_started, in_progress, completed, blocked, or cancelled',
  `planned_work_notes` text DEFAULT NULL COMMENT 'Additional notes or comments about the planned work status',
  `hours_today` decimal(6,2) NOT NULL DEFAULT 0.00,
  `overtime_hours` decimal(6,2) DEFAULT 0.00,
  `total_working_days` int(11) DEFAULT NULL,
  `total_hours_cumulative` decimal(10,2) DEFAULT NULL,
  `completed_tasks` mediumtext DEFAULT NULL,
  `pending_tasks` mediumtext DEFAULT NULL,
  `ongoing_tasks` mediumtext DEFAULT NULL,
  `notes` mediumtext DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_user_day` (`user_id`,`submission_date`),
  KEY `idx_user_date` (`user_id`,`submission_date`)
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `work_submissions`
INSERT INTO `work_submissions` VALUES
('55','608dc9d1-26e0-441d-8144-45f74c53a846','2025-07-01','22:06:00',NULL,NULL,NULL,'not_started',NULL,'4.00','0.00',NULL,NULL,'dsdsd\nsds\nds\nds\ndsd','Sd\ns\nds\nd\nsd','d\nsd\nsd\ns\nds\nd','sd\nsd\ns\ndsd\ns','2025-11-02 22:07:04','2025-11-04 00:14:50'),
('57','d84019a3-575f-403c-aa12-02482422bcfa','2025-08-06','22:09:00',NULL,NULL,NULL,'not_started',NULL,'8.00','0.00',NULL,NULL,'sdsdds','dsdsd','sdsds','dsds','2025-11-02 22:09:36','2025-11-04 00:14:45'),
('59','608dc9d1-26e0-441d-8144-45f74c53a846','2025-10-30','22:54:00',NULL,NULL,NULL,'not_started',NULL,'24.00','16.00',NULL,NULL,'wdsds\nds\nds\nd\nsds₹','s\ndsds\nds\nds\nd\nsd','s\ncs\nds\nd\ns\nds','s\nds\ndas\nd\nsd\nasd','2025-11-02 22:55:02','2025-11-03 23:59:08'),
('66','d84019a3-575f-403c-aa12-02482422bcfa','2025-08-12','23:09:00',NULL,NULL,NULL,'not_started',NULL,'8.00','0.00',NULL,NULL,'c c c c ','c c c ','','','2025-11-02 23:09:38','2025-11-04 00:15:30'),
('67','608dc9d1-26e0-441d-8144-45f74c53a846','2025-09-30','00:01:00',NULL,NULL,NULL,'not_started',NULL,'12.00','4.00',NULL,NULL,'edfsdd','asasad\nadd','','','2025-11-04 00:01:08','2025-11-04 00:07:12'),
('70','608dc9d1-26e0-441d-8144-45f74c53a846','2025-08-19','00:07:00',NULL,NULL,NULL,'not_started',NULL,'12.00','4.00',NULL,NULL,'ddd','dd','','','2025-11-04 00:07:38','2025-11-04 00:15:59'),
('71','608dc9d1-26e0-441d-8144-45f74c53a846','2025-06-01','00:16:00',NULL,NULL,NULL,'not_started',NULL,'12.00','4.00',NULL,NULL,'sdsds','sdsds','','','2025-11-04 00:16:39','2025-11-04 00:17:02'),
('72','608dc9d1-26e0-441d-8144-45f74c53a846','2025-12-01','23:47:00',NULL,NULL,NULL,'not_started',NULL,'4.00','0.00',NULL,NULL,'dfghj','','','','2025-12-01 23:25:35','2025-12-01 23:47:30'),
('79','608dc9d1-26e0-441d-8144-45f74c53a846','2025-12-02',NULL,'2025-12-02 12:26:33','[\"63fe666d-82e2-4537-83fc-aa778ce17b08\"]','test','not_started',NULL,'0.00','0.00',NULL,NULL,NULL,NULL,NULL,NULL,'2025-12-02 11:55:17','2025-12-02 12:26:33'),
('80','d84019a3-575f-403c-aa12-02482422bcfa','2025-12-02',NULL,'2025-12-02 12:27:24','[\"83f0e57d-6905-49b6-99a4-2b3df2595644\"]','test\n','not_started',NULL,'0.00','0.00',NULL,NULL,NULL,NULL,NULL,NULL,'2025-12-02 12:11:00','2025-12-02 12:27:24'),
('81','608dc9d1-26e0-441d-8144-45f74c53a846','2025-12-31',NULL,'2026-01-01 10:22:33','[\"a5dd0abd-b5cc-43ff-a22e-652e30ab7d28\",\"63fe666d-82e2-4537-83fc-aa778ce17b08\",\"83f0e57d-6905-49b6-99a4-2b3df2595644\",\"291c8841-94a5-4cdb-9eb8-fef40709aee5\"]','','not_started',NULL,'4.00','0.00',NULL,NULL,'ddddd','','','','2026-01-01 10:22:33','2026-01-01 23:58:58'),
('82','608dc9d1-26e0-441d-8144-45f74c53a846','2026-01-01',NULL,'2026-01-02 00:13:30','[\"a5dd0abd-b5cc-43ff-a22e-652e30ab7d28\",\"291c8841-94a5-4cdb-9eb8-fef40709aee5\",\"63fe666d-82e2-4537-83fc-aa778ce17b08\",\"83f0e57d-6905-49b6-99a4-2b3df2595644\"]','test]\ntest\nsd\nsda\nd','not_started',NULL,'4.00','0.00',NULL,NULL,'','sdsd\nsd','','','2026-01-01 23:24:55','2026-01-02 00:13:30');

COMMIT;
